using Microsoft.UI.Dispatching;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Loader;
using Windows.Media;
using Windows.Media.Playback;

namespace Auris
{
    public sealed class PlatformServices : IDisposable
    {
        const uint NimAdd = 0;
        const uint NimDelete = 2;
        const uint NifMessage = 1;
        const uint NifIcon = 2;
        const uint NifTip = 4;
        const uint WmHotkey = 0x0312;
        const uint WmLButtonUp = 0x0202;
        const uint WmApp = 0x8000;

        readonly IntPtr _hwnd;
        readonly DispatcherQueue _queue;
        readonly SubclassProc _proc;
        readonly List<IPlayerPlugin> _plugins = new();
        MediaPlayer? _media;
        SystemMediaTransportControls? _smtc;
        bool _tray;
        bool _subclass;

        public PlatformServices(IntPtr hwnd, DispatcherQueue queue, Action<int> onHotkey, Action onTray)
        {
            _hwnd = hwnd;
            _queue = queue;
            _proc = (h, msg, w, l, id, data) =>
            {
                if (msg == WmHotkey)
                    _queue.TryEnqueue(() => onHotkey(w.ToInt32()));
                else if (msg == WmApp && (uint)l == WmLButtonUp)
                    _queue.TryEnqueue(() => onTray());
                return DefSubclassProc(h, msg, w, l, id, data);
            };
            _subclass = SetWindowSubclass(hwnd, _proc, 1, 0);
            if (_subclass)
            {
                RegisterHotKey(hwnd, 1, 0x4000, 0xB3);
                RegisterHotKey(hwnd, 2, 0x4000, 0xB0);
                RegisterHotKey(hwnd, 3, 0x4000, 0xB1);
                RegisterHotKey(hwnd, 4, 0x4000, 0xB2);
            }
            try
            {
                _media = new MediaPlayer();
                _media.CommandManager.IsEnabled = false;
                _smtc = _media.SystemMediaTransportControls;
                _smtc.IsEnabled = true;
                _smtc.IsPlayEnabled = true;
                _smtc.IsPauseEnabled = true;
                _smtc.IsNextEnabled = true;
                _smtc.IsPreviousEnabled = true;
                _smtc.IsStopEnabled = true;
                _smtc.ButtonPressed += (_, e) =>
                {
                    var button = e.Button;
                    _queue.TryEnqueue(() => onHotkey(button switch
                    {
                        SystemMediaTransportControlsButton.Play => 11,
                        SystemMediaTransportControlsButton.Pause => 12,
                        SystemMediaTransportControlsButton.Next => 2,
                        SystemMediaTransportControlsButton.Previous => 3,
                        SystemMediaTransportControlsButton.Stop => 4,
                        _ => 0
                    }));
                };
            }
            catch
            {
                _smtc = null;
            }
            LoadPlugins();
            _plugins.Insert(0, new NowPlayingFilePlugin());
        }

        public IReadOnlyList<IPlayerPlugin> Plugins => _plugins;
        public bool TrayVisible => _tray;

        public void ShowTray(string tip)
        {
            var data = new NotifyIconData
            {
                cbSize = Marshal.SizeOf<NotifyIconData>(),
                hwnd = _hwnd,
                uID = 1,
                uFlags = (int)(NifMessage | NifIcon | NifTip),
                uCallbackMessage = (int)WmApp,
                hIcon = LoadIcon(0, (IntPtr)32512),
                szTip = tip.Length > 120 ? tip[..120] : tip
            };
            _tray = Shell_NotifyIcon(NimAdd, ref data);
        }

        public void UpdateNowPlaying(Track? track, bool playing)
        {
            if (_smtc == null) return;
            try
            {
                _smtc.PlaybackStatus = playing ? MediaPlaybackStatus.Playing : MediaPlaybackStatus.Paused;
                _smtc.DisplayUpdater.Type = MediaPlaybackType.Music;
                _smtc.DisplayUpdater.MusicProperties.Title = track?.Display ?? "Auris";
                _smtc.DisplayUpdater.MusicProperties.Artist = track?.Artist ?? "";
                _smtc.DisplayUpdater.Update();
            }
            catch { }
            if (track == null) return;
        }

        public void Bind(IPlayerHost host)
        {
            foreach (var plugin in _plugins)
            {
                try { plugin.Attach(host); }
                catch { }
            }
        }

        public void Notify(string kind, string path, string title)
        {
            foreach (var plugin in _plugins)
            {
                try
                {
                    if (kind == "play") plugin.OnPlay(path, title);
                    else if (kind == "pause") plugin.OnPause();
                    else if (kind == "stop") plugin.OnStop();
                    else plugin.OnTrackChanged(path, title);
                }
                catch { }
            }
        }

        public void Dispose()
        {
            for (var i = 1; i <= 4; i++)
                UnregisterHotKey(_hwnd, i);
            if (_tray)
            {
                var data = new NotifyIconData
                {
                    cbSize = Marshal.SizeOf<NotifyIconData>(),
                    hwnd = _hwnd,
                    uID = 1
                };
                Shell_NotifyIcon(NimDelete, ref data);
            }
            if (_subclass)
                RemoveWindowSubclass(_hwnd, _proc, 1);
            _media?.Dispose();
        }

        void LoadPlugins()
        {
            var dir = Path.Combine(AppContext.BaseDirectory, "Plugins");
            Directory.CreateDirectory(dir);
            foreach (var dll in Directory.GetFiles(dir, "*.dll"))
            {
                try
                {
                    var asm = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(dll));
                    foreach (var type in asm.GetTypes())
                    {
                        if (type.IsAbstract || !typeof(IPlayerPlugin).IsAssignableFrom(type)) continue;
                        if (Activator.CreateInstance(type) is IPlayerPlugin plugin)
                            _plugins.Add(plugin);
                    }
                }
                catch { }
            }
        }

        delegate IntPtr SubclassProc(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam, IntPtr id, IntPtr data);

        sealed class NowPlayingFilePlugin : IPlayerPlugin
        {
            public string Name => "Jetzt gespielt";

            public void OnTrackChanged(string path, string title)
            {
                var file = Path.Combine(Library.DataDir, "jetzt.txt");
                File.WriteAllText(file, title + Environment.NewLine + path);
            }
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct NotifyIconData
        {
            public int cbSize;
            public IntPtr hwnd;
            public int uID;
            public int uFlags;
            public int uCallbackMessage;
            public IntPtr hIcon;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string szTip;
        }

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        static extern bool Shell_NotifyIcon(uint message, ref NotifyIconData data);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern IntPtr LoadIcon(IntPtr instance, IntPtr icon);

        [DllImport("user32.dll")]
        static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint vk);

        [DllImport("user32.dll")]
        static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("comctl32.dll")]
        static extern bool SetWindowSubclass(IntPtr hWnd, SubclassProc proc, IntPtr id, IntPtr data);

        [DllImport("comctl32.dll")]
        static extern bool RemoveWindowSubclass(IntPtr hWnd, SubclassProc proc, IntPtr id);

        [DllImport("comctl32.dll")]
        static extern IntPtr DefSubclassProc(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam, IntPtr id, IntPtr data);
    }
}
