using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using System;

namespace Auris
{
    public sealed partial class MiniWindow : Window
    {
        readonly MainWindow _main;
        readonly DispatcherTimer _timer;
        bool _drag;
        bool _volumeDrag;

        public MiniWindow(MainWindow main)
        {
            InitializeComponent();
            WindowChrome.Attach(this);
            _main = main;
            _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };
            _timer.Tick += (_, _) => UpdateSeek();
            if (AppWindow.Presenter is OverlappedPresenter presenter)
                presenter.IsAlwaysOnTop = true;
            AppWindow.Resize(new Windows.Graphics.SizeInt32(520, 180));
            AppWindow.Closing += (_, e) =>
            {
                e.Cancel = true;
                _timer.Stop();
                AppWindow.Hide();
            };
            SeekSlider.AddHandler(UIElement.PointerPressedEvent, new Microsoft.UI.Xaml.Input.PointerEventHandler((_, _) => _drag = true), true);
            SeekSlider.AddHandler(UIElement.PointerReleasedEvent, new Microsoft.UI.Xaml.Input.PointerEventHandler((_, _) =>
            {
                _drag = false;
                _main.Session.Seek(SeekSlider.Value);
            }), true);
            VolumeSlider.AddHandler(UIElement.PointerPressedEvent, new Microsoft.UI.Xaml.Input.PointerEventHandler((_, _) => _volumeDrag = true), true);
            VolumeSlider.AddHandler(UIElement.PointerReleasedEvent, new Microsoft.UI.Xaml.Input.PointerEventHandler((_, _) =>
            {
                _volumeDrag = false;
                _main.Session.SaveSettings();
            }), true);
            VolumeSlider.ValueChanged += (_, _) =>
            {
                if (_volumeDrag)
                    _main.Session.SetVolume((float)(VolumeSlider.Value / 100));
            };
        }

        public void ApplyLook(string theme)
        {
            var light = theme == "light";
            if (Content is FrameworkElement root)
                root.RequestedTheme = light ? ElementTheme.Light : ElementTheme.Dark;
            SystemBackdrop = theme == "acrylic" ? new DesktopAcrylicBackdrop() : new MicaBackdrop();
        }

        public void Refresh()
        {
            var session = _main.Session;
            var track = session.Current;
            TitleText.Text = track?.TitleText ?? "Auris";
            ArtistText.Text = track?.Artist ?? "";
            PlayButton.Content = session.IsPlaying ? "Pause" : "Play";
            if (!_volumeDrag)
                VolumeSlider.Value = session.Settings.Volume * 100;
            var path = track?.CoverPath;
            CoverImage.Source = string.IsNullOrWhiteSpace(path) ? null : new BitmapImage(new Uri(path));
            _timer.Start();
            UpdateSeek();
        }

        void UpdateSeek()
        {
            if (_drag) return;
            var engine = _main.Session.Engine;
            var duration = engine.DurationSeconds;
            SeekSlider.Maximum = duration > 0 ? duration : 1;
            SeekSlider.Value = duration > 0 ? Math.Clamp(engine.PositionSeconds, 0, duration) : 0;
        }

        void Play_Click(object sender, RoutedEventArgs e)
        {
            _main.Session.PlayPause();
            Refresh();
        }

        void Next_Click(object sender, RoutedEventArgs e) => _main.Session.Next(true);
        void Previous_Click(object sender, RoutedEventArgs e) => _main.Session.Previous();
    }
}
