using Microsoft.UI.Dispatching;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;

namespace Auris
{
    public sealed class PlayerSession
    {
        readonly DispatcherQueue _queue;
        readonly object _tagLock = new();
        readonly Queue<Track> _tagQueue = new();
        readonly Random _random = new();
        bool _tagging;
        int _saveTick;
        string? _resumePath;
        double _resumeSeconds;

        public PlayerSession(DispatcherQueue queue)
        {
            _queue = queue;
            Engine = new PlaybackEngine();
            Playlist = new ObservableCollection<Track>();
            Queue = new ObservableCollection<Track>();
            Bookmarks = new ObservableCollection<Bookmark>();
            Settings = LoadSettings();
            Engine.CrossfadeSeconds = Settings.Crossfade;
            Engine.ReplayGain = Settings.ReplayGain;
            Engine.SetMaster(Settings.Volume);
            Engine.SetOutputMode(Settings.Output);
            for (var i = 0; i < 10 && i < Settings.Eq.Length; i++)
                Engine.SetBand(i, Settings.Eq[i]);
            Repeat = Settings.Repeat;
            Shuffle = Settings.Shuffle;
            foreach (var mark in LoadBookmarks())
                Bookmarks.Add(mark);
            LoadPlays();
        }

        public PlaybackEngine Engine { get; }
        public ObservableCollection<Track> Playlist { get; }
        public ObservableCollection<Track> Queue { get; }
        public ObservableCollection<Bookmark> Bookmarks { get; }
        public AppSettings Settings { get; }
        public Track? Current { get; private set; }
        public string Status { get; private set; } = "Bereit";
        public string Repeat { get; private set; }
        public bool Shuffle { get; private set; }
        public bool IsPlaying => Engine.IsPlaying;
        public event Action? Changed;

        public void Reorder(IReadOnlyList<Track> order)
        {
            Playlist.Clear();
            foreach (var track in order)
                Playlist.Add(track);
            SaveSession();
        }

        public void AddPaths(IEnumerable<string> paths)
        {
            var count = 0;
            foreach (var path in paths)
            {
                if (string.IsNullOrWhiteSpace(path)) continue;
                var track = new Track(path);
                ApplyRating(track);
                Playlist.Add(track);
                lock (_tagLock)
                    _tagQueue.Enqueue(track);
                count++;
            }
            Status = count + " Datei(en) hinzugefügt";
            PumpTags();
            Changed?.Invoke();
        }

        public async Task AddFolderAsync(string folder)
        {
            try
            {
                var files = await Task.Run(() =>
                {
                    try { return Library.ListFolder(folder); }
                    catch { return new List<string>(); }
                });
                AddPaths(files);
                Settings.SmartFolder = folder;
                SaveSettings();
                Status = files.Count == 0
                    ? "Keine lesbaren Audiodateien. Gesperrte Ordner werden übersprungen."
                    : files.Count + " Titel aus Ordner";
            }
            catch (Exception ex)
            {
                Status = "Ordner offline oder nicht lesbar: " + ex.Message;
            }
            Changed?.Invoke();
        }

        public void LoadSmart()
        {
            if (!string.IsNullOrWhiteSpace(Settings.SmartFolder))
                _ = AddFolderAsync(Settings.SmartFolder);
        }

        List<(int Index, Track Track)>? _undo;

        public void RemoveMany(IEnumerable<Track> tracks)
        {
            var set = new HashSet<Track>(tracks);
            if (set.Count == 0) return;
            var undo = new List<(int Index, Track Track)>();
            for (var i = Playlist.Count - 1; i >= 0; i--)
            {
                if (!set.Contains(Playlist[i])) continue;
                undo.Add((i, Playlist[i]));
                Playlist.RemoveAt(i);
            }
            undo.Reverse();
            _undo = undo;
            Status = set.Count + " Titel entfernt";
            Changed?.Invoke();
        }

        public bool UndoRemove()
        {
            if (_undo == null || _undo.Count == 0) return false;
            foreach (var item in _undo)
            {
                var index = Math.Clamp(item.Index, 0, Playlist.Count);
                Playlist.Insert(index, item.Track);
            }
            Status = _undo.Count + " Titel zurückgeholt";
            _undo = null;
            Changed?.Invoke();
            return true;
        }

        readonly List<Track> _deck = new();
        public bool DeckHeld { get; private set; }

        public void HoldDeck()
        {
            if (DeckHeld) return;
            _deck.Clear();
            foreach (var track in Playlist)
                _deck.Add(track);
            DeckHeld = true;
        }

        public void ReleaseDeck()
        {
            DeckHeld = false;
            _deck.Clear();
        }

        public void RetargetCurrent()
        {
            if (Current == null) return;
            var found = Find(Current.Path);
            if (found != null)
                Current = found;
        }

        public void ReplaceView(IEnumerable<string> paths)
        {
            Playlist.Clear();
            foreach (var path in paths)
            {
                if (string.IsNullOrWhiteSpace(path)) continue;
                var track = new Track(path);
                ApplyRating(track);
                Playlist.Add(track);
                lock (_tagLock)
                    _tagQueue.Enqueue(track);
            }
            PumpTags();
            Changed?.Invoke();
        }

        public void Enqueue(Track track)
        {
            Queue.Add(track);
            Status = "In Warteschlange: " + track.Display;
            Changed?.Invoke();
        }

        public void PlayNext(IReadOnlyList<Track> tracks)
        {
            if (tracks.Count == 0) return;
            for (var i = tracks.Count - 1; i >= 0; i--)
                Queue.Insert(0, tracks[i]);
            Status = tracks.Count == 1 ? "Als Nächstes: " + tracks[0].Display : tracks.Count + " Titel als Nächstes";
            Changed?.Invoke();
        }

        public void ClearQueue()
        {
            Queue.Clear();
            Changed?.Invoke();
        }

        public void PlayPause()
        {
            if (Engine.IsPlaying)
            {
                Engine.Pause();
                Status = "Pause";
                Notice("pause");
                Changed?.Invoke();
                return;
            }
            if (Engine.CanResume)
            {
                Engine.Resume();
                Status = IsRadio ? RadioTitle : Current?.Display ?? "Play";
                Notice("play");
                Changed?.Invoke();
                return;
            }
            Play(Current ?? (Playlist.Count > 0 ? Playlist[0] : null), false);
        }

        public void Play(Track? track, bool crossfade)
        {
            if (track == null) return;
            IsRadio = false;
            var guard = 0;
            while (track != null && Unreachable(track))
            {
                track.SetOffline(true);
                guard++;
                if (guard > Playlist.Count + Queue.Count + 1)
                {
                    Stop();
                    Status = "Keine erreichbare Datei";
                    Changed?.Invoke();
                    return;
                }
                Current = track;
                track = Pick(1, false);
            }
            if (track == null)
            {
                Stop();
                Status = "Keine erreichbare Datei";
                Changed?.Invoke();
                return;
            }
            track.SetOffline(false);
            if (Current == null || !string.Equals(Current.Path, track.Path, StringComparison.OrdinalIgnoreCase))
                ResetLoop();
            if (string.IsNullOrEmpty(track.Title) && string.IsNullOrEmpty(track.Artist))
                track.Apply(Library.Read(track.Path));
            Current = track;
            try
            {
                Engine.Start(track.Path, track.ReplayGainDb, crossfade);
                if (_resumePath == track.Path && _resumeSeconds > 1)
                {
                    Engine.Seek(TimeSpan.FromSeconds(_resumeSeconds));
                    _resumePath = null;
                }
                Status = track.Display;
                NotePlay(track.Path);
                Notice("track");
                Notice("play");
            }
            catch (Exception ex)
            {
                Status = "Wiedergabe fehlgeschlagen: " + ex.Message;
            }
            SaveSession();
            Changed?.Invoke();
        }

        public void Stop()
        {
            IsRadio = false;
            Engine.Stop();
            Status = "Gestoppt";
            Notice("stop");
            SaveSession();
            Changed?.Invoke();
        }

        public bool IsRadio { get; private set; }
        public string RadioTitle { get; private set; } = "";
        public string RadioUrl { get; private set; } = "";
        public event Action<string, string, string>? PlaybackNotice;

        void Notice(string kind)
        {
            var path = IsRadio ? RadioUrl : Current?.Path ?? "";
            var title = IsRadio ? RadioTitle : Current?.Display ?? "";
            PlaybackNotice?.Invoke(kind, path, title);
        }

        public void PlayRadio(string name, string url)
        {
            IsRadio = true;
            RadioUrl = url;
            RadioTitle = string.IsNullOrWhiteSpace(name) ? url : name;
            ResetLoop();
            Current = null;
            try
            {
                Engine.StartRadio(url);
                Status = RadioTitle;
                Notice("track");
                Notice("play");
            }
            catch (Exception ex)
            {
                IsRadio = false;
                Status = "Stream fehlgeschlagen: " + ex.Message;
            }
            Changed?.Invoke();
        }

        public void Next(bool fromUser)
        {
            if (fromUser && Engine.PositionSeconds > 3 && !Shuffle && Queue.Count == 0)
            {
                // manual next always advances
            }
            var next = Pick(1, fromUser);
            if (next == null)
            {
                Stop();
                Status = "Ende";
                Changed?.Invoke();
                return;
            }
            Play(next, !fromUser && Engine.CrossfadeSeconds > 0 && Engine.IsPlaying);
        }

        public void Previous()
        {
            if (Engine.PositionSeconds > 3)
            {
                Engine.Seek(TimeSpan.Zero);
                Changed?.Invoke();
                return;
            }
            var index = Current == null ? 0 : Source().IndexOf(Current);
            var source = Source();
            if (source.Count == 0) return;
            var guard = 0;
            do
            {
                if (index <= 0) index = source.Count - 1;
                else index--;
                var track = source[index];
                if (!Unreachable(track))
                {
                    Play(track, false);
                    return;
                }
                track.SetOffline(true);
            }
            while (++guard < source.Count);
            Status = "Keine erreichbare Datei";
            Changed?.Invoke();
        }

        public void Seek(double seconds) => Engine.Seek(TimeSpan.FromSeconds(seconds));

        public void ToggleShuffle()
        {
            Shuffle = !Shuffle;
            Settings.Shuffle = Shuffle;
            SaveSettings();
            Changed?.Invoke();
        }

        public void CycleRepeat()
        {
            Repeat = Repeat switch
            {
                "off" => "all",
                "all" => "one",
                _ => "off"
            };
            Settings.Repeat = Repeat;
            SaveSettings();
            Changed?.Invoke();
        }

        public string RepeatLabel => Repeat switch
        {
            "all" => "Wiederholen: Alle",
            "one" => "Wiederholen: Titel",
            _ => "Wiederholen: Aus"
        };

        public void AddBookmark()
        {
            if (Current == null) return;
            var mark = new Bookmark
            {
                Path = Current.Path,
                Seconds = Engine.PositionSeconds,
                Label = Current.Display
            };
            Bookmarks.Add(mark);
            SaveBookmarks();
            Status = "Lesezeichen gesetzt";
            Changed?.Invoke();
        }

        public void PlayBookmark(Bookmark mark)
        {
            var track = Find(mark.Path) ?? new Track(mark.Path);
            if (!Playlist.Contains(track))
                Playlist.Add(track);
            _resumePath = mark.Path;
            _resumeSeconds = mark.Seconds;
            Play(track, false);
        }

        public void RememberWindow(int x, int y, int width, int height, bool maximized)
        {
            if (Settings.WindowX == x && Settings.WindowY == y && Settings.WindowW == width && Settings.WindowH == height && Settings.WindowMax == maximized)
                return;
            Settings.WindowX = x;
            Settings.WindowY = y;
            Settings.WindowW = width;
            Settings.WindowH = height;
            Settings.WindowMax = maximized;
            SaveSettings();
        }

        public void SetBalance(float balance)
        {
            Settings.Balance = Math.Clamp(balance, -1, 1);
            Engine.SetBalance(Settings.Balance);
            SaveSettings();
        }

        readonly Dictionary<string, int> _ratings = new(StringComparer.OrdinalIgnoreCase);

        void LoadRatings()
        {
            var data = Library.ReadJson<Dictionary<string, int>>(Path.Combine(Library.DataDir, "ratings.json"));
            if (data == null) return;
            foreach (var pair in data)
                _ratings[pair.Key] = Math.Clamp(pair.Value, 0, 5);
        }

        void SaveRatings()
        {
            try
            {
                Library.WriteSafe(Path.Combine(Library.DataDir, "ratings.json"), JsonSerializer.Serialize(_ratings));
            }
            catch { }
        }

        public void ApplyRating(Track track)
        {
            if (_ratings.TryGetValue(track.Path, out var stars))
                track.SetRating(stars);
        }

        public void SetRating(Track track, int stars)
        {
            stars = Math.Clamp(stars, 0, 5);
            track.SetRating(stars);
            if (stars <= 0)
                _ratings.Remove(track.Path);
            else
                _ratings[track.Path] = stars;
            SaveRatings();
        }

        public List<string> Favorites(int take)
        {
            var ranked = new List<KeyValuePair<string, int>>(_ratings);
            ranked.Sort((a, b) => b.Value.CompareTo(a.Value));
            var list = new List<string>();
            for (var i = 0; i < ranked.Count && list.Count < take; i++)
            {
                if (ranked[i].Value >= 4)
                    list.Add(ranked[i].Key);
            }
            return list;
        }

        public void SetVolume(float volume)
        {
            Settings.Volume = volume;
            Engine.SetMaster(volume);
        }

        public void SetCrossfade(double seconds)
        {
            Settings.Crossfade = seconds;
            Engine.CrossfadeSeconds = seconds;
            SaveSettings();
        }

        public void SetReplayGain(bool enabled)
        {
            Settings.ReplayGain = enabled;
            Engine.ReplayGain = enabled;
            SaveSettings();
        }

        public void SetOutput(string mode)
        {
            Settings.Output = mode;
            Engine.SetOutputMode(mode);
            if (!string.IsNullOrWhiteSpace(Engine.OutputError))
                Status = Engine.OutputError + " – WaveOut";
            else
                Status = "Ausgabe: " + Engine.OutputMode;
            SaveSettings();
            Changed?.Invoke();
        }

        public void SetBand(int index, float db)
        {
            if (Settings.Eq.Length != 10)
                Settings.Eq = new float[10];
            Settings.Eq[index] = db;
            Engine.SetBand(index, db);
            SaveSettings();
        }

        public void SetEq(float[] values)
        {
            if (values.Length != 10)
                return;
            Settings.Eq = (float[])values.Clone();
            for (var i = 0; i < 10; i++)
                Engine.SetBand(i, Settings.Eq[i]);
            SaveSettings();
        }

        public void SaveEqTemplate(string name)
        {
            Settings.EqTemplates ??= new Dictionary<string, float[]>();
            Settings.EqTemplates[name] = (float[])Settings.Eq.Clone();
            SaveSettings();
        }

        public void DeleteEqTemplate(string name)
        {
            if (Settings.EqTemplates == null || !Settings.EqTemplates.Remove(name))
                return;
            SaveSettings();
        }

        public void StartSleep(double minutes)
        {
            if (double.IsNaN(minutes) || minutes <= 0)
            {
                SleepEnds = null;
                Status = "Schlaf-Timer aus";
            }
            else
            {
                SleepEnds = DateTime.UtcNow.AddMinutes(minutes);
                Status = "Schlaf-Timer " + minutes.ToString("0") + " min";
            }
            Changed?.Invoke();
        }

        public double LoopA { get; private set; } = -1;
        public double LoopB { get; private set; } = -1;
        string? _loopPath;
        public string LoopLabel => LoopB > LoopA && LoopA >= 0 ? "A-B an" : LoopA >= 0 ? "A gesetzt" : "A-B";

        public void ArmLoop()
        {
            if (Current == null)
            {
                Status = "Kein Titel für A-B";
                Changed?.Invoke();
                return;
            }
            if (!string.Equals(_loopPath, Current.Path, StringComparison.OrdinalIgnoreCase))
                ResetLoop();
            _loopPath = Current.Path;
            if (LoopA < 0)
            {
                LoopA = Engine.PositionSeconds;
                Status = "Punkt A";
            }
            else if (LoopB < 0)
            {
                var mark = Engine.PositionSeconds;
                if (Math.Abs(mark - LoopA) < 0.4)
                    Status = "Punkt B liegt zu nah an A";
                else
                {
                    LoopB = mark;
                    if (LoopB < LoopA)
                    {
                        var swap = LoopA;
                        LoopA = LoopB;
                        LoopB = swap;
                    }
                    Status = "A-B Schleife";
                }
            }
            else
            {
                ResetLoop();
                Status = "A-B aus";
            }
            Changed?.Invoke();
        }

        void ResetLoop()
        {
            LoopA = -1;
            LoopB = -1;
            _loopPath = null;
        }

        public DateTime? SleepEnds { get; private set; }

        public void Tick()
        {
            Engine.Tick();
            TickSleep();
            if (IsRadio)
            {
                if (Engine.HasFault)
                {
                    IsRadio = false;
                    Engine.Stop();
                    Status = "Stream unterbrochen";
                    Changed?.Invoke();
                }
                return;
            }
            if (Engine.HasFault)
            {
                var broken = Current;
                NoteOutage(broken?.Path);
                Engine.Abandon();
                Track? next = null;
                var source = Source();
                var start = broken == null ? -1 : source.IndexOf(broken);
                for (var step = 1; step <= source.Count; step++)
                {
                    var index = start < 0 ? step - 1 : (start + step) % source.Count;
                    if (index < 0 || index >= source.Count) continue;
                    var candidate = source[index];
                    if (Unreachable(candidate))
                    {
                        candidate.SetOffline(true);
                        continue;
                    }
                    next = candidate;
                    break;
                }
                if (next == null)
                {
                    foreach (var track in source)
                        track.SetOffline(true);
                    Stop();
                    Status = "Keine erreichbare Datei";
                    Changed?.Invoke();
                    return;
                }
                Status = "Verbindung verloren, nächster Titel";
                Changed?.Invoke();
                Play(next, false);
                return;
            }
            if (Engine.IsPlaying && LoopA >= 0 && LoopB > LoopA && Current != null && string.Equals(Current.Path, _loopPath, StringComparison.OrdinalIgnoreCase))
            {
                if (Engine.PositionSeconds >= LoopB - 0.08)
                    Engine.Seek(TimeSpan.FromSeconds(LoopA));
                return;
            }
            if (Engine.IsPlaying && Repeat == "one" && Engine.RemainingSeconds < 0.15 && Engine.DurationSeconds > 1)
                Engine.Seek(TimeSpan.Zero);
            else if (Engine.NeedsHandoff)
            {
                var next = Repeat == "one" ? null : Pick(1, false);
                if (next != null)
                {
                    Engine.MarkHandoff();
                    Play(next, Engine.CrossfadeSeconds > 0);
                }
                else if (Engine.RemainingSeconds <= 0.1)
                {
                    Engine.MarkHandoff();
                    Stop();
                    Status = "Ende";
                    Changed?.Invoke();
                }
            }

            _saveTick++;
            if (_saveTick >= 25)
            {
                _saveTick = 0;
                SaveSession();
            }
        }

        public void SaveSession()
        {
            try
            {
                var dto = new SessionDto
                {
                    Playlist = Paths(Playlist),
                    Queue = Paths(Queue),
                    Current = Current?.Path,
                    Position = Engine.PositionSeconds
                };
                Library.WriteSafe(Path.Combine(Library.DataDir, "session.json"), JsonSerializer.Serialize(dto));
            }
            catch { }
        }

        public void RestoreSession()
        {
            try
            {
                var file = Path.Combine(Library.DataDir, "session.json");
                var dto = Library.ReadJson<SessionDto>(file);
                if (dto?.Playlist == null || dto.Playlist.Count == 0) return;
                AddPaths(dto.Playlist);
                if (dto.Queue != null)
                {
                    foreach (var path in dto.Queue)
                        Queue.Add(Find(path) ?? new Track(path));
                }
                Current = dto.Current == null ? null : Find(dto.Current);
                _resumePath = dto.Current;
                _resumeSeconds = dto.Position;
                Status = "Wiederhergestellt";
                ProbeTracks();
                Changed?.Invoke();
            }
            catch { }
        }

        readonly Dictionary<string, int> _plays = new(StringComparer.OrdinalIgnoreCase);

        void LoadPlays()
        {
            try
            {
                var data = Library.ReadJson<Dictionary<string, int>>(Path.Combine(Library.DataDir, "plays.json"));
                if (data == null) return;
                foreach (var pair in data)
                    _plays[pair.Key] = pair.Value;
            }
            catch { }
        }

        void NotePlay(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            _plays.TryGetValue(path, out var count);
            _plays[path] = count + 1;
            try
            {
                Library.WriteSafe(Path.Combine(Library.DataDir, "plays.json"), JsonSerializer.Serialize(_plays));
            }
            catch { }
        }

        public int PlayCount(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return 0;
            _plays.TryGetValue(path, out var count);
            return count;
        }

        public List<string> Unplayed(IEnumerable<string> paths, int take)
        {
            var list = new List<string>();
            foreach (var path in paths)
            {
                if (string.IsNullOrWhiteSpace(path) || _plays.ContainsKey(path))
                    continue;
                list.Add(path);
                if (list.Count >= take)
                    break;
            }
            return list;
        }

        public List<string> MostPlayed(int take)
        {
            var ranked = new List<KeyValuePair<string, int>>(_plays);
            ranked.Sort((a, b) => b.Value.CompareTo(a.Value));
            var list = new List<string>();
            for (var i = 0; i < ranked.Count && list.Count < take; i++)
                list.Add(ranked[i].Key);
            return list;
        }

        public void SaveSettings()
        {
            try
            {
                Library.WriteSafe(Path.Combine(Library.DataDir, "settings.json"), JsonSerializer.Serialize(Settings));
            }
            catch { }
        }

        public void SetTheme(string theme)
        {
            Settings.Theme = theme;
            SaveSettings();
        }

        public void SetAccent(string accent)
        {
            Settings.Accent = string.IsNullOrWhiteSpace(accent) ? "cyan" : accent;
            SaveSettings();
        }

        public void SetUpdateUrl(string url)
        {
            Settings.UpdateUrl = url;
            SaveSettings();
        }

        public void SetTray(bool enabled)
        {
            Settings.MinimizeToTray = enabled;
            SaveSettings();
        }

        void TickSleep()
        {
            if (SleepEnds == null)
            {
                Engine.SetMaster(Settings.Volume);
                return;
            }
            var left = (SleepEnds.Value - DateTime.UtcNow).TotalSeconds;
            if (left <= 0)
            {
                SleepEnds = null;
                Stop();
                Status = "Schlaf-Timer";
                Changed?.Invoke();
                return;
            }
            var factor = left < 10 ? (float)(left / 10) : 1f;
            Engine.SetMaster(Settings.Volume * factor);
        }

        readonly Dictionary<string, bool> _roots = new(StringComparer.OrdinalIgnoreCase);
        readonly HashSet<string> _badPlaces = new(StringComparer.OrdinalIgnoreCase);
        bool _probing;

        void NoteOutage(string? path)
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            var key = OutageKey(path);
            lock (_badPlaces) _badPlaces.Add(key);
            foreach (var track in Playlist)
            {
                if (string.Equals(OutageKey(track.Path), key, StringComparison.OrdinalIgnoreCase))
                    track.SetOffline(true);
            }
        }

        static string OutageKey(string path)
        {
            if (path.StartsWith(@"\\"))
            {
                var parts = path.Split('\\', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2)
                    return @"\\" + parts[0] + @"\" + parts[1];
            }
            return Path.GetDirectoryName(path) ?? path;
        }

        bool PlaceIsBad(string path)
        {
            var key = OutageKey(path);
            lock (_badPlaces) return _badPlaces.Contains(key);
        }

        public void ProbeTracks()
        {
            if (_probing) return;
            _probing = true;
            var snapshot = new List<Track>(Playlist);
            _ = Task.Run(() =>
            {
                foreach (var track in snapshot)
                {
                    var offline = MissingOnDisk(track);
                    _queue.TryEnqueue(() => track.SetOffline(offline));
                }
                _probing = false;
            });
        }

        bool MissingOnDisk(Track track)
        {
            if (PlaceIsBad(track.Path))
                return true;
            var root = ShareRoot(track.Path);
            if (root.Length > 0 && !RootUp(root))
                return true;
            try { return !File.Exists(track.Path); }
            catch { return true; }
        }

        bool Unreachable(Track track)
        {
            if (track.IsOffline || PlaceIsBad(track.Path))
                return true;
            var root = ShareRoot(track.Path);
            if (root.Length == 0)
                return false;
            lock (_roots)
                return _roots.TryGetValue(root, out var up) && !up;
        }

        static string ShareRoot(string path)
        {
            if (path.StartsWith(@"\\"))
            {
                var parts = path.Split('\\', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2)
                    return @"\\" + parts[0] + @"\" + parts[1];
            }
            var root = Path.GetPathRoot(path);
            return string.IsNullOrWhiteSpace(root) ? "" : root;
        }

        bool RootUp(string root)
        {
            lock (_roots)
            {
                if (_roots.TryGetValue(root, out var known))
                    return known;
            }
            bool reachable;
            try { reachable = Directory.Exists(root); }
            catch { reachable = false; }
            lock (_roots)
                _roots[root] = reachable;
            return reachable;
        }

        IList<Track> Source() => DeckHeld ? _deck : Playlist;

        Track? Pick(int direction, bool fromUser)
        {
            var source = Source();
            if (!fromUser && Queue.Count > 0)
            {
                var queued = Queue[0];
                Queue.RemoveAt(0);
                return queued;
            }
            if (source.Count == 0) return null;
            if (Shuffle)
            {
                if (source.Count == 1) return source[0];
                Track next;
                do next = source[_random.Next(source.Count)];
                while (next == Current && source.Count > 1);
                return next;
            }
            var index = Current == null ? -1 : source.IndexOf(Current);
            index += direction;
            if (index >= source.Count)
                return Repeat == "all" ? source[0] : null;
            if (index < 0)
                return source[^1];
            return source[index];
        }

        public Track? Find(string path)
        {
            foreach (var track in Playlist)
                if (track.Path == path) return track;
            return null;
        }

        static List<string> Paths(IEnumerable<Track> tracks)
        {
            var list = new List<string>();
            foreach (var track in tracks)
                list.Add(track.Path);
            return list;
        }

        void PumpTags()
        {
            if (_tagging) return;
            _tagging = true;
            _ = Task.Run(() =>
            {
                while (true)
                {
                    Track? track;
                    lock (_tagLock)
                        track = _tagQueue.Count > 0 ? _tagQueue.Dequeue() : null;
                    if (track == null)
                    {
                        lock (_tagLock)
                        {
                            if (_tagQueue.Count > 0)
                                continue;
                            _tagging = false;
                        }
                        break;
                    }
                    var meta = Library.Read(track.Path);
                    var local = track;
                    _queue.TryEnqueue(() => local.Apply(meta));
                }
            });
        }

        void SaveBookmarks()
        {
            try
            {
                Library.WriteSafe(Path.Combine(Library.DataDir, "bookmarks.json"), JsonSerializer.Serialize(Bookmarks));
            }
            catch { }
        }

        static List<Bookmark> LoadBookmarks()
        {
            try
            {
                return Library.ReadJson<List<Bookmark>>(Path.Combine(Library.DataDir, "bookmarks.json")) ?? new List<Bookmark>();
            }
            catch
            {
                return new List<Bookmark>();
            }
        }

        static AppSettings LoadSettings()
        {
            try
            {
                var settings = Library.ReadJson<AppSettings>(Path.Combine(Library.DataDir, "settings.json")) ?? new AppSettings();
                if (settings.Eq == null || settings.Eq.Length != 10)
                    settings.Eq = new float[10];
                settings.EqTemplates ??= new Dictionary<string, float[]>();
                return settings;
            }
            catch
            {
                return new AppSettings();
            }
        }

        sealed class SessionDto
        {
            public List<string>? Playlist { get; set; }
            public List<string>? Queue { get; set; }
            public string? Current { get; set; }
            public double Position { get; set; }
        }
    }
}
