using System;

namespace Auris
{
    public interface IPlayerHost
    {
        string CurrentPath { get; }
        string CurrentTitle { get; }
        bool IsPlaying { get; }
        void Play();
        void Pause();
        void Stop();
        void Next();
        void Enqueue(string path);
    }

    public interface IPlayerPlugin
    {
        string Name { get; }
        void Attach(IPlayerHost host) { }
        void OnTrackChanged(string path, string title) { }
        void OnPlay(string path, string title) { }
        void OnPause() { }
        void OnStop() { }
    }
}
