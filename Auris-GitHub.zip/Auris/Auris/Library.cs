using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Auris
{
    public static class Library
    {
        public static readonly string[] AudioExtensions = [".mp3", ".flac", ".wav", ".m4a", ".aac", ".wma", ".ogg", ".opus"];
        static readonly HttpClient Http = CreateHttp();

        static HttpClient CreateHttp()
        {
            var http = new HttpClient { Timeout = TimeSpan.FromSeconds(8) };
            http.DefaultRequestHeaders.UserAgent.ParseAdd("Auris/1.0");
            return http;
        }

        public static async Task<string> ResolveStreamAsync(string input)
        {
            var url = input.Trim();
            if (!url.StartsWith("http://", StringComparison.OrdinalIgnoreCase)
                && !url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Die URL muss mit http beginnen");
            var path = url.Split('?')[0];
            if (!path.EndsWith(".m3u", StringComparison.OrdinalIgnoreCase)
                && !path.EndsWith(".m3u8", StringComparison.OrdinalIgnoreCase)
                && !path.EndsWith(".pls", StringComparison.OrdinalIgnoreCase))
                return url;
            var text = await Http.GetStringAsync(url);
            foreach (var raw in text.Split('\n', '\r'))
            {
                var line = raw.Trim();
                if (line.StartsWith("http://", StringComparison.OrdinalIgnoreCase)
                    || line.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                    return line;
                if (line.StartsWith("File", StringComparison.OrdinalIgnoreCase) && line.Contains('='))
                {
                    var value = line[(line.IndexOf('=') + 1)..].Trim();
                    if (value.StartsWith("http://", StringComparison.OrdinalIgnoreCase)
                        || value.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                        return value;
                }
            }
            throw new InvalidOperationException("Keine Stream-URL in der Playlist");
        }

        public static async Task<List<RadioCountry>> RadioCountriesAsync()
        {
            var json = await Http.GetStringAsync("https://de1.api.radio-browser.info/json/countries");
            var list = JsonSerializer.Deserialize<List<RadioCountry>>(json) ?? new List<RadioCountry>();
            list.RemoveAll(item => item.Code.Length == 0 || item.Count <= 0);
            list.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.CurrentCultureIgnoreCase));
            return list;
        }

        public static async Task<List<RadioHit>> RadioStationsAsync(string countryCode, string name)
        {
            var url = "https://de1.api.radio-browser.info/json/stations/search?hidebroken=true&limit=40&order=votes&reverse=true&countrycode="
                + Uri.EscapeDataString(countryCode);
            if (!string.IsNullOrWhiteSpace(name))
                url += "&name=" + Uri.EscapeDataString(name.Trim());
            var json = await Http.GetStringAsync(url);
            var list = JsonSerializer.Deserialize<List<RadioHit>>(json) ?? new List<RadioHit>();
            list.RemoveAll(item => string.IsNullOrWhiteSpace(item.Url));
            return list;
        }

        public sealed class RadioCountry
        {
            [System.Text.Json.Serialization.JsonPropertyName("name")]
            public string Name { get; set; } = "";
            [System.Text.Json.Serialization.JsonPropertyName("iso_3166_1")]
            public string Code { get; set; } = "";
            [System.Text.Json.Serialization.JsonPropertyName("stationcount")]
            public int Count { get; set; }
            public string Display => Name + "  (" + Count + ")";
        }

        public sealed class RadioHit
        {
            [System.Text.Json.Serialization.JsonPropertyName("name")]
            public string Name { get; set; } = "";
            [System.Text.Json.Serialization.JsonPropertyName("url_resolved")]
            public string Url { get; set; } = "";
            [System.Text.Json.Serialization.JsonPropertyName("codec")]
            public string Codec { get; set; } = "";
            [System.Text.Json.Serialization.JsonPropertyName("bitrate")]
            public int Bitrate { get; set; }
            public string Display => Name + (Bitrate > 0 ? "   " + Bitrate + "  " + Codec : "");
        }

        public static string DataDir
        {
            get
            {
                var dir = Path.Combine(AppContext.BaseDirectory, "data");
                Directory.CreateDirectory(dir);
                return dir;
            }
        }

        public static TrackMeta Read(string path)
        {
            try
            {
                using var file = TagLib.File.Create(path);
                var tag = file.Tag;
                string? cover = null;
                if (tag.Pictures is { Length: > 0 })
                    cover = SaveCover(tag.Pictures[0].Data.Data, path);
                var gain = tag.ReplayGainTrackGain;
                return new TrackMeta(
                    tag.Title ?? "",
                    tag.FirstPerformer ?? "",
                    tag.Album ?? "",
                    tag.Lyrics ?? "",
                    gain,
                    file.Properties?.Duration.TotalSeconds ?? 0,
                    cover);
            }
            catch
            {
                return new TrackMeta("", "", "", "", double.NaN, 0, null);
            }
        }

        public static string? SaveCover(byte[] data, string key)
        {
            if (data.Length == 0) return null;
            var dir = Path.Combine(DataDir, "covers");
            Directory.CreateDirectory(dir);
            var hash = Convert.ToHexString(SHA1.HashData(Encoding.UTF8.GetBytes(key))).ToLowerInvariant();
            var file = Path.Combine(dir, hash + ".img");
            if (!File.Exists(file))
                File.WriteAllBytes(file, data);
            return file;
        }

        public static List<string> ListFolder(string folder)
        {
            var list = new List<string>();
            if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder))
                return list;
            var options = new EnumerationOptions
            {
                RecurseSubdirectories = true,
                IgnoreInaccessible = true,
                AttributesToSkip = FileAttributes.ReparsePoint
            };
            try
            {
                foreach (var file in Directory.EnumerateFiles(folder, "*.*", options))
                {
                    var ext = Path.GetExtension(file);
                    for (var i = 0; i < AudioExtensions.Length; i++)
                    {
                        if (!ext.Equals(AudioExtensions[i], StringComparison.OrdinalIgnoreCase))
                            continue;
                        list.Add(file);
                        break;
                    }
                }
            }
            catch { }
            list.Sort(StringComparer.OrdinalIgnoreCase);
            return list;
        }

        public static void SaveM3u(string file, IEnumerable<Track> tracks)
        {
            var sb = new StringBuilder();
            sb.AppendLine("#EXTM3U");
            foreach (var track in tracks)
            {
                var seconds = track.DurationSeconds > 0 ? ((int)track.DurationSeconds).ToString() : "-1";
                var label = string.IsNullOrWhiteSpace(track.Display) ? track.Name : track.Display;
                sb.Append("#EXTINF:").Append(seconds).Append(',').AppendLine(label);
                sb.AppendLine(track.Path);
            }
            WriteSafe(file, sb.ToString());
        }

        public static void WriteSafe(string file, string content)
        {
            var folder = Path.GetDirectoryName(file);
            if (!string.IsNullOrEmpty(folder))
                Directory.CreateDirectory(folder);
            var temp = file + ".tmp";
            File.WriteAllText(temp, content);
            if (File.Exists(file))
            {
                try { File.Copy(file, file + ".bak", true); }
                catch { }
            }
            File.Move(temp, file, true);
        }

        public static T? ReadJson<T>(string file) where T : class
        {
            foreach (var candidate in new[] { file, file + ".bak" })
            {
                try
                {
                    if (!File.Exists(candidate)) continue;
                    var value = JsonSerializer.Deserialize<T>(File.ReadAllText(candidate));
                    if (value != null) return value;
                }
                catch { }
            }
            return null;
        }

        public static string ReadTextSafe(string file)
        {
            foreach (var candidate in new[] { file, file + ".bak" })
            {
                try
                {
                    if (!File.Exists(candidate)) continue;
                    var text = File.ReadAllText(candidate);
                    if (!string.IsNullOrWhiteSpace(text)) return text;
                }
                catch { }
            }
            return "";
        }

        public static List<string> LoadPlaylist(string file)
        {
            try
            {
                return ReadPlaylist(file);
            }
            catch
            {
                if (file.EndsWith(".bak", StringComparison.OrdinalIgnoreCase))
                    return new List<string>();
                return LoadPlaylist(file + ".bak");
            }
        }

        static List<string> ReadPlaylist(string file)
        {
            var dir = Path.GetDirectoryName(file) ?? "";
            var list = new List<string>();
            foreach (var raw in File.ReadAllLines(file))
            {
                var line = raw.Trim();
                if (line.Length == 0 || line.StartsWith('#')) continue;
                if (line.StartsWith("File", StringComparison.OrdinalIgnoreCase) && line.Contains('='))
                    line = line[(line.IndexOf('=') + 1)..].Trim();
                if (!Path.IsPathRooted(line))
                    line = Path.GetFullPath(Path.Combine(dir, line));
                list.Add(line);
            }
            return list;
        }

        public static async Task<string?> FetchLyricsAsync(Track track)
        {
            var title = string.IsNullOrWhiteSpace(track.Title) ? Path.GetFileNameWithoutExtension(track.Name) : track.Title;
            title = title.Replace('_', ' ').Trim();
            if (title.Length == 0)
                return null;
            var artist = track.Artist.Replace('_', ' ').Trim();
            var album = track.Album.Replace('_', ' ').Trim();
            var duration = track.DurationSeconds > 0 ? "&duration=" + ((int)track.DurationSeconds).ToString() : "";
            var get = "https://lrclib.net/api/get?track_name=" + Uri.EscapeDataString(title)
                + "&artist_name=" + Uri.EscapeDataString(artist)
                + "&album_name=" + Uri.EscapeDataString(album)
                + duration;
            var fromGet = await ReadLyrics(get);
            if (!string.IsNullOrWhiteSpace(fromGet))
                return fromGet;
            var search = "https://lrclib.net/api/search?track_name=" + Uri.EscapeDataString(title);
            if (artist.Length > 0)
                search += "&artist_name=" + Uri.EscapeDataString(artist);
            return await ReadLyrics(search);
        }

        static async Task<string?> ReadLyrics(string url)
        {
            try
            {
                var json = await Http.GetStringAsync(url);
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.ValueKind == JsonValueKind.Array)
                {
                    if (doc.RootElement.GetArrayLength() == 0)
                        return null;
                    return TextFrom(doc.RootElement[0]);
                }
                return TextFrom(doc.RootElement);
            }
            catch
            {
                return null;
            }
        }

        static string? TextFrom(JsonElement element)
        {
            string? plain = null;
            string? synced = null;
            if (element.TryGetProperty("plainLyrics", out var plainElement))
                plain = plainElement.GetString();
            if (element.TryGetProperty("syncedLyrics", out var syncedElement))
                synced = syncedElement.GetString();
            if (!string.IsNullOrWhiteSpace(synced) && synced.Contains('['))
                return synced;
            if (!string.IsNullOrWhiteSpace(plain))
                return plain;
            return string.IsNullOrWhiteSpace(synced) ? null : synced;
        }

        public static async Task<string?> FetchCoverAsync(Track track)
        {
            var term = (track.Artist + " " + track.Album).Trim();
            if (term.Length == 0) return null;
            try
            {
                var url = "https://itunes.apple.com/search?term=" + Uri.EscapeDataString(term) + "&entity=album&limit=1";
                var json = await Http.GetStringAsync(url);
                using var doc = JsonDocument.Parse(json);
                if (!doc.RootElement.TryGetProperty("results", out var results) || results.GetArrayLength() == 0)
                    return null;
                var art = results[0].GetProperty("artworkUrl100").GetString();
                if (string.IsNullOrWhiteSpace(art)) return null;
                art = art.Replace("100x100bb", "600x600bb");
                var bytes = await Http.GetByteArrayAsync(art);
                return SaveCover(bytes, "web:" + term);
            }
            catch
            {
                return null;
            }
        }

        public static async Task<string?> FetchVersionAsync(string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return null;
            var body = await Http.GetStringAsync(url);
            var line = body.Trim().Split('\n', '\r')[0].Trim();
            return line.Length == 0 ? null : line;
        }
    }
}
