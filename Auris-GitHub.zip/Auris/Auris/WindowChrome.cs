using Microsoft.UI.Xaml;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Windows.UI.ViewManagement;
using WinRT.Interop;

namespace Auris
{
    public static class WindowChrome
    {
        const int CaptionColor = 35;
        const int TextColor = 36;
        const int DefaultColor = unchecked((int)0xFFFFFFFF);
        static readonly List<Window> Open = new();
        static UISettings? _watch;

        public static void Attach(Window window)
        {
            Open.Add(window);
            Apply(window);
            if (_watch != null) return;
            _watch = new UISettings();
            _watch.ColorValuesChanged += (_, _) =>
            {
                foreach (var item in Open.ToArray())
                    item.DispatcherQueue.TryEnqueue(() => Apply(item));
            };
        }

        public static void Apply(Window window)
        {
            var hwnd = WindowNative.GetWindowHandle(window);
            var light = AppsUseLightTheme();
            var dark = light ? 0 : 1;
            DwmSetWindowAttribute(hwnd, 20, ref dark, 4);
            var caption = Caption();
            DwmSetWindowAttribute(hwnd, CaptionColor, ref caption, 4);
            var text = caption == DefaultColor ? DefaultColor : Contrast(caption);
            DwmSetWindowAttribute(hwnd, TextColor, ref text, 4);
        }

        static bool AppsUseLightTheme()
        {
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
            return key?.GetValue("AppsUseLightTheme") is int light && light != 0;
        }

        static int Caption()
        {
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\DWM");
            if (key?.GetValue("ColorPrevalence") is not int on || on == 0)
                return DefaultColor;
            if (key.GetValue("ColorizationColor") is not int packed)
                return DefaultColor;
            var red = (packed >> 16) & 255;
            var green = (packed >> 8) & 255;
            var blue = packed & 255;
            return blue << 16 | green << 8 | red;
        }

        static int Contrast(int colorRef)
        {
            var red = colorRef & 255;
            var green = (colorRef >> 8) & 255;
            var blue = (colorRef >> 16) & 255;
            var bright = red * 0.299 + green * 0.587 + blue * 0.114;
            return bright > 150 ? 0x00111111 : 0x00FFFFFF;
        }

        [DllImport("dwmapi.dll")]
        static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);
    }
}
