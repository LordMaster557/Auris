using System;
using System.IO;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Microsoft.UI.Dispatching;
using Windows.Media;
using Windows.Media.Playback;
using Windows.Storage;
using Windows.Storage.Streams;

namespace Auris
{
    /// <summary>Registriert Auris bei den Windows System Media Transport Controls (SMTC).
    /// Die Session ist ueber GSMTC lesbar (GlobalSystemMediaTransportControlsSession) -
    /// genau diese API liest die Rainmeter-Plugin MediaPlayer.dll. Aufrerdem erscheint
    /// Auris damit in der Lautstaerke-Leiste, an den Hardware-Mediatasten
    /// und in der Voice-Control.
    /// API: Windows.Media.SystemMediaTransportControls (WinRT, SDK 26100).
    /// </summary>
    public sealed class GsmSession : IDisposable
    {
        readonly DispatcherQueue _queue;
        readonly nint _hwnd;
        MediaPlayer? _mediaPlayer;
        SystemMediaTransportControls? _smc;
        InMemoryRandomAccessStream? _silentStream;
        bool _disposed;
        bool _initialized;

        string? _lastTitle = "\0";
        string? _lastArtist = "\0";
        string? _lastAlbum = "\0";
        string? _lastCover = "\0";
        MediaPlaybackStatus _lastStatus = MediaPlaybackStatus.Closed;
        DateTime _lastTimelineUtc = DateTime.MinValue;
        bool _loggedNoSmc;
        bool _loggedFirstPush;
        bool _loggedTimeline;
        MediaPlaybackStatus _requested;
        bool _pendingPlayingReport;
        DateTime _lastInvariantUtc;
        MediaPlayerState _lastMpStateLogged;
        int _logErrors;

        /// <summary>Befehle an die Wiedergabe (1=PlayPause, 11=Play, 12=Pause, 2=Next, 3=Previous, 4=Stop).</summary>
        public Action<int>? OnCommand { get; set; }

        /// <summary>Seek-Request aus der Lautstaerke-Leiste / Voice-Control (Sekunden).</summary>
        public Action<double>? OnSeek { get; set; }

        public GsmSession(DispatcherQueue queue, nint hwnd)
        {
            _queue = queue ?? throw new ArgumentNullException(nameof(queue));
            _hwnd = hwnd;
        }

        static void Log(string msg)
        {
            try
            {
                var dir = Path.Combine(AppContext.BaseDirectory, "data");
                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, "gsm-debug.log"),
                    DateTime.Now.ToString("HH:mm:ss.fff") + " " + msg + Environment.NewLine);
            }
            catch { }
        }

        /// <summary>2 s Stille als WAV (16-Bit, Mono, 44.1 kHz) - unsichtbare, huerbare
        /// "Medienquelle" fuer den Session-MediaPlayer. Ohne Source registriert der
        /// MediaPlayer KEINE GSMTC-Session (per Probe bewiesen).</summary>
        static byte[] BuildSilentWav(int seconds = 2, int rate = 44100)
        {
            int dataLen = seconds * rate * 2;
            var b = new byte[44 + dataLen];
            void WStr(int o, string s) { for (int i = 0; i < s.Length; i++) b[o + i] = (byte)s[i]; }
            void WI(int o, int v) { b[o] = (byte)v; b[o + 1] = (byte)(v >> 8); b[o + 2] = (byte)(v >> 16); b[o + 3] = (byte)(v >> 24); }
            WStr(0, "RIFF"); WI(4, 36 + dataLen); WStr(8, "WAVE");
            WStr(12, "fmt "); WI(16, 16); WI(20, 1); WI(22, 1); WI(24, rate); WI(28, rate * 2); WI(32, 2); WI(34, 2);
            WStr(36, "data"); WI(40, dataLen);
            return b;
        }

        /// <summary>
        /// Initialisiert die SMTC-Session. GetForCurrentView() funktioniert in
        /// WinUI 3 (unverpackt) nicht (0x80070578) und GetForWindow erzeugt
        /// ein Objekt, das in GSMTC NICHT als Session sichtbar ist.
        /// Gepraefter Weg (WindowsAppSDK #6740): gedaeumter MediaPlayer,
        /// dessen SMTC an der Media-Session-Infrastruktur registriert ist.
        /// </summary>
        public Task InitAsync()
        {
            if (_queue.HasThreadAccess)
                return InitOnUi();
            var tcs = new TaskCompletionSource();
            _queue.TryEnqueue(() =>
            {
                var t = InitOnUi();
                t.ContinueWith(_ =>
                {
                    if (t.IsFaulted) tcs.TrySetException(t.Exception!);
                    else tcs.TrySetResult();
                });
            });
            return tcs.Task;
        }

        async Task InitOnUi()
        {
            if (_disposed || _initialized) return;
            try
            {
                _silentStream = new InMemoryRandomAccessStream();
                var bytes = BuildSilentWav();
                await _silentStream.WriteAsync(bytes.AsBuffer());
                _silentStream.Seek(0);

                _mediaPlayer = new MediaPlayer { AutoPlay = false, IsMuted = true, IsLoopingEnabled = true };
                _mediaPlayer.SetStreamSource(_silentStream);
                _smc = _mediaPlayer.SystemMediaTransportControls;
                Log("InitOnUi: MediaPlayer-SMTC -> " + (_smc == null ? "NULL" : "OK"));
                if (_smc == null) return;
                // Medientyp MUSS vor dem Zugriff auf MusicProperties gesetzt sein,
                // sonst E_NOT_SUPPORTED (0x80070032) "Medientyp nicht initialisiert".
                _smc.DisplayUpdater.Type = MediaPlaybackType.Music;
                _smc.ButtonPressed += OnButtonPressed;
                _smc.IsEnabled = true;
                _smc.PlaybackPositionChangeRequested += OnPositionChangeRequested;
                _mediaPlayer.MediaFailed += (_, e) =>
                {
                    var sb = new System.Text.StringBuilder("MP MediaFailed: ");
                    foreach (var p in e.Error.GetType().GetProperties())
                    {
                        try { sb.Append(p.Name).Append('=').Append(p.GetValue(e.Error)).Append(' '); } catch { }
                    }
                    Log(sb.ToString());
                };
                _mediaPlayer.MediaEnded += (_, _) => Log("MP MediaEnded");
                Log("InitOnUi: Type=Music, Events wired, IsEnabled=" + _smc.IsEnabled);

                // Registrierung: Play -> Pause. Die Source wird vom MediaPlayer
                // als "nicht unterstützt" verworfen (SourceNotSupported), das ist
                // WUNSCHWERT: der MediaPlayer landet im State "Closed"/"Paused",
                // und genau daraus lebt die GSMTC-Session (per Probe kartiert:
                //  - MP "Closed"  + gemeldeter Status "Playing"  -> Session sichtbar
                //  - MP "Paused"  + gemeldeter Status "Playing"  -> Session GELÖSCHT
                //  - MP "Paused"  + gemeldeter Status "Paused"   -> Session sichtbar
                //  - MP "Closed"  + gemeldeter Status "Paused"   -> Session GELÖSCHT
                // Der Status muss also stets zum MediaPlayer-State passen.
                _mediaPlayer.Play();
                await Task.Delay(1500);
                _mediaPlayer.Pause();
                _lastStatus = MediaPlaybackStatus.Paused;
                _initialized = true;   // erst jetzt: Pushes dürfen erst NACH der Registrierung
                Log("InitOnUi: Registrierung fertig, MP-State=" + _mediaPlayer.CurrentState);
            }
            catch (Exception ex)
            {
                Log("InitOnUi Exception: " + ex);
                _smc = null;
            }
        }

        void OnButtonPressed(SystemMediaTransportControls sender, SystemMediaTransportControlsButtonPressedEventArgs e)
        {
            int id = e.Button switch
            {
                SystemMediaTransportControlsButton.Play => 11,
                SystemMediaTransportControlsButton.Pause => 12,
                SystemMediaTransportControlsButton.Next => 2,
                SystemMediaTransportControlsButton.Previous => 3,
                SystemMediaTransportControlsButton.Stop => 4,
                _ => 0
            };
            if (id == 0) return;
            var cmd = OnCommand;
            if (cmd == null) return;
            if (_queue.HasThreadAccess) cmd(id);
            else _ = _queue.TryEnqueue(() => cmd(id));
        }

        void OnPositionChangeRequested(SystemMediaTransportControls sender, PlaybackPositionChangeRequestedEventArgs e)
        {
            var seek = OnSeek;
            if (seek == null) return;
            double sec = Math.Max(0, e.RequestedPlaybackPosition.TotalSeconds);
            if (_queue.HasThreadAccess) seek(sec);
            else _ = _queue.TryEnqueue(() => seek(sec));
        }

        /// <summary>
        /// Schickt die aktuellen Wiedergabedaten an SMTC. Duerf von jedem Thread kommen.
        /// Titel/Interpret/Album/Cover werden nur bei Aenderung gesetzt,
        /// die Timeline maximal zweimal pro Sekunde.
        /// </summary>
        public void Push(string title, string artist, string album, bool active, bool playing, double position, double duration, string? cover)
        {
            if (_disposed || !_initialized) return;
            var smc = _smc;
            if (smc == null)
            {
                if (!_loggedNoSmc)
                {
                    _loggedNoSmc = true;
                    Log("Push: kein SMTC-Objekt (Init lief nicht oder GetForCurrentView=NULL)");
                }
                return;
            }
            if (_queue.HasThreadAccess)
                PushOnUi(smc, title, artist, album, active, playing, position, duration, cover);
            else
                _ = _queue.TryEnqueue(() => PushOnUi(smc, title, artist, album, active, playing, position, duration, cover));
        }

        async void PushOnUi(SystemMediaTransportControls smc, string title, string artist, string album, bool active, bool playing, double position, double duration, string? cover)
        {
            try
            {
                if (!_loggedFirstPush)
                {
                    _loggedFirstPush = true;
                    Log($"PushOnUi#1: title=[{title}] artist=[{artist}] active={active} playing={playing} pos={position:F1} dur={duration:F1} cover=[{cover}]");
                }
                position = Math.Max(0, position);
                duration = Math.Max(0, duration);

                var status = playing
                    ? MediaPlaybackStatus.Playing
                    : MediaPlaybackStatus.Paused;
                _requested = status;
                var mp = _mediaPlayer;
                MediaPlayerState mpState = MediaPlayerState.Closed;
                if (mp != null)
                {
                    try { mpState = mp.CurrentState; } catch { }
                }
                if (mpState != _lastMpStateLogged)
                {
                    _lastMpStateLogged = mpState;
                    Log("MP-State: " + mpState);
                }

                bool statusChanged = status != _lastStatus;
                if (statusChanged)
                {
                    if (status == MediaPlaybackStatus.Playing)
                    {
                        // MediaPlayer muss in "Closed" (Play-Versuch mit der
                        // ungueltigen Source) oder tatsaechlich Playing sein,
                        // bevor "Playing" gemeldet werden darf - mit "Paused"
                        // loescht das OS die Session.
                        if (mp != null && mpState == MediaPlayerState.Paused)
                        {
                            // NEUE Source: Nach MediaFailed ist die alte
                            // Stream-Source ungueltig - Play() wirft dann oder
                            // der MP bleibt in Paused ("Paused-MP +
                            // Playing-Meldung" loescht die Session).
                            try
                            {
                                var s2 = new InMemoryRandomAccessStream();
                                await s2.WriteAsync(BuildSilentWav().AsBuffer());
                                s2.Seek(0);
                                mp.SetStreamSource(s2);
                            }
                            catch { }
                            try { mp.Play(); } catch { }
                        }
                        if (mpState == MediaPlayerState.Closed || mpState == MediaPlayerState.Playing)
                        {
                            // MP ist bereits kompatibel -> sofort melden.
                            smc.PlaybackStatus = MediaPlaybackStatus.Playing;
                            _lastStatus = MediaPlaybackStatus.Playing;
                            Log("PushOnUi: Status -> Playing");
                        }
                        else if (!_pendingPlayingReport)
                        {
                            // Play-Versuch laeuft (~300-400 ms); erst dann melden.
                            _pendingPlayingReport = true;
                            var captured = smc;
                            await Task.Delay(400);
                            _pendingPlayingReport = false;
                            if (!_disposed && _smc == captured
                                && _requested == MediaPlaybackStatus.Playing
                                && _lastStatus != MediaPlaybackStatus.Playing)
                            {
                                // Sicherheit: Nur melden, wenn der MP nicht
                                // (mehr) in Paused ist - sonst Session-Geloescht.
                                var st2 = MediaPlayerState.Closed;
                                try { st2 = mp.CurrentState; } catch { }
                                if (st2 == MediaPlayerState.Paused)
                                {
                                    Log("PushOnUi: MP immer noch Paused - Playing-Meldung unterlassen");
                                }
                                else
                                {
                                    captured.PlaybackStatus = MediaPlaybackStatus.Playing;
                                    _lastStatus = MediaPlaybackStatus.Playing;
                                    Log("PushOnUi: Status -> Playing (verzoegert)");
                                }
                            }
                        }
                    }
                    else
                    {
                        // MP in "Paused" setzen (Closed + Paused-Meldung wuerde
                        // die Session loeschen), dann melden.
                        if (mp != null && mpState != MediaPlayerState.Paused)
                        {
                            try { mp.Pause(); } catch { }
                        }
                        smc.PlaybackStatus = MediaPlaybackStatus.Paused;
                        _lastStatus = MediaPlaybackStatus.Paused;
                        Log("PushOnUi: Status -> Paused");
                    }
                }

                // Invariante bei jedem Push: Der MediaPlayer-State muss zum
                // gemeldeten Status passen, sonst entfernt das OS die Session.
                // Rate-limited, weil die State-Reads asynchron sein koennen.
                var nowInv = DateTime.UtcNow;
                if (_lastStatus == MediaPlaybackStatus.Paused && mp != null
                    && mpState == MediaPlayerState.Closed
                    && (nowInv - _lastInvariantUtc).TotalMilliseconds >= 500)
                {
                    _lastInvariantUtc = nowInv;
                    try { mp.Pause(); } catch { }
                    smc.PlaybackStatus = MediaPlaybackStatus.Paused;
                    Log("PushOnUi: Invariante MP->Paused, Session re-meldet");
                }

                bool infoChanged =
                    title != _lastTitle || artist != _lastArtist ||
                    album != _lastAlbum || cover != _lastCover;
                if (infoChanged)
                {
                    var media = smc.DisplayUpdater.MusicProperties;
                    media.Title = title ?? "";
                    media.Artist = artist ?? "";
                    media.AlbumTitle = album ?? "";
                    smc.DisplayUpdater.Update();
                    Log($"PushOnUi: Metadata -> [{title}] / [{artist}] / [{album}] cover=[{cover}]");
                    _lastTitle = title;
                    _lastArtist = artist;
                    _lastAlbum = album;
                    if (string.IsNullOrWhiteSpace(cover) || !File.Exists(cover))
                        _lastCover = cover;
                    else
                        _ = SetCoverAsync(smc, cover);
                }

                if (duration > 0)
                {
                    var now = DateTime.UtcNow;
                    // Bei Statuswechsel oder Infowechsel sofort neu setzen
                    // (Pause setzt die Timeline sonst auf 0 zurueck),
                    // sonst max. zweimal/s.
                    if (statusChanged || infoChanged || (now - _lastTimelineUtc).TotalMilliseconds >= 500)
                    {
                        _lastTimelineUtc = now;
                        var tl = new SystemMediaTransportControlsTimelineProperties
                        {
                            StartTime = TimeSpan.Zero,
                            Position = TimeSpan.FromSeconds(position),
                            EndTime = TimeSpan.FromSeconds(duration),
                            MinSeekTime = TimeSpan.Zero,
                            MaxSeekTime = TimeSpan.FromSeconds(duration)
                        };
                        smc.UpdateTimelineProperties(tl);
                        if (!_loggedTimeline)
                        {
                            _loggedTimeline = true;
                            Log($"PushOnUi: Timeline gesetzt pos={position:F1}s end={duration:F1}s");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // SMTC darf die Wiedergabe nie stoeren.
                if (_logErrors < 5)
                {
                    _logErrors++;
                    Log("PushOnUi Exception: " + ex);
                }
            }
        }

        async Task SetCoverAsync(SystemMediaTransportControls smc, string cover)
        {
            try
            {
                var file = await StorageFile.GetFileFromPathAsync(cover);
                if (_disposed) return;
                smc.DisplayUpdater.Thumbnail = RandomAccessStreamReference.CreateFromFile(file);
                smc.DisplayUpdater.Update();
                _lastCover = cover;
            }
            catch
            {
            }
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            var smc = _smc;
            _smc = null;
            if (smc == null) return;
            try
            {
                smc.ButtonPressed -= OnButtonPressed;
                smc.PlaybackPositionChangeRequested -= OnPositionChangeRequested;
                smc.DisplayUpdater.ClearAll();
                smc.PlaybackStatus = MediaPlaybackStatus.Closed;
            }
            catch
            {
            }
            try
            {
                _mediaPlayer?.Dispose();
            }
            catch
            {
            }
            _mediaPlayer = null;
        }
    }
}
