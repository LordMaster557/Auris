using System.Collections.Generic;

namespace Auris
{
    public static class Strings
    {
        public static string Code { get; private set; } = "de";

        static readonly Dictionary<string, string[]> Map = new()
        {
            ["playlist"] = ["Playlist", "Playlist", "プレイリスト", "播放列表"],
            ["library"] = ["Bibliothek", "Library", "ライブラリ", "资料库"],
            ["folders"] = ["Ordner", "Folders", "フォルダー", "文件夹"],
            ["search"] = ["Suche", "Search", "検索", "搜索"],
            ["radio"] = ["Radio", "Radio", "ラジオ", "电台"],
            ["queue"] = ["Warteschlange", "Queue", "キュー", "播放队列"],
            ["marks"] = ["Lesezeichen", "Bookmarks", "ブックマーク", "书签"],
            ["history"] = ["Verlauf", "History", "履歴", "历史"],
            ["eq"] = ["Equalizer", "Equalizer", "イコライザー", "均衡器"],
            ["lyrics"] = ["Songtext", "Lyrics", "歌詞", "歌词"],
            ["lists"] = ["Listen", "Listen", "スマート", "智能列表"],
            ["settings"] = ["Einstellungen", "Settings", "設定", "设置"],
            ["filter"] = ["Schnellsuche", "Quick search", "クイック検索", "快速搜索"],
            ["open"] = ["Öffnen", "Open", "開く", "打开"],
            ["save"] = ["Speichern", "Save", "保存", "保存"],
            ["remove"] = ["Löschen", "Delete", "削除", "删除"],
            ["more"] = ["Mehr", "More", "その他", "更多"],
            ["addFolder"] = ["Ordner hinzufügen", "Add folder", "フォルダーを追加", "添加文件夹"],
            ["loadList"] = ["Playlist laden", "Load playlist", "プレイリストを開く", "加载播放列表"],
            ["enqueue"] = ["In Warteschlange", "Add to queue", "キューに追加", "加入队列"],
            ["clearList"] = ["Playlist leeren", "Clear playlist", "プレイリストを空にする", "清空播放列表"],
            ["dupes"] = ["Doppelte suchen", "Find duplicates", "重複を探す", "查找重复"],
            ["offline"] = ["Offline entfernen", "Remove offline", "オフラインを削除", "移除离线"],
            ["jump"] = ["Zum laufenden Titel", "Go to current", "再生中の曲へ", "转到当前曲目"],
            ["bookmark"] = ["Lesezeichen setzen", "Add bookmark", "ブックマーク", "添加书签"],
            ["undo"] = ["Rückgängig", "Undo", "元に戻す", "撤销"],
            ["exit"] = ["Beenden", "Exit", "終了", "退出"],
            ["play"] = ["Abspielen", "Play", "再生", "播放"],
            ["playNext"] = ["Als Nächstes", "Play next", "次に再生", "下一首播放"],
            ["copyTitle"] = ["Titel kopieren", "Copy title", "タイトルをコピー", "复制标题"],
            ["copyPath"] = ["Pfad kopieren", "Copy path", "パスをコピー", "复制路径"],
            ["copyTo"] = ["In Playlist kopieren", "Copy to playlist", "プレイリストへコピー", "复制到播放列表"],
            ["moveTo"] = ["In Playlist verschieben", "Move to playlist", "プレイリストへ移動", "移动到播放列表"],
            ["removeItem"] = ["Entfernen", "Remove", "削除", "移除"],
            ["rate"] = ["Bewerten", "Rate", "評価", "评分"],
            ["info"] = ["Eigenschaften", "Properties", "プロパティ", "属性"],
            ["showExplorer"] = ["Im Explorer zeigen", "Show in Explorer", "エクスプローラーで表示", "在资源管理器中显示"],
            ["title"] = ["Titel", "Title", "タイトル", "标题"],
            ["artist"] = ["Interpret", "Artist", "アーティスト", "艺人"],
            ["album"] = ["Album", "Album", "アルバム", "专辑"],
            ["length"] = ["Länge", "Length", "長さ", "时长"],
            ["close"] = ["Schließen", "Close", "閉じる", "关闭"],
            ["clear"] = ["Leeren", "Clear", "クリア", "清空"],
            ["searchAll"] = ["In allen Playlists suchen", "Search all playlists", "すべてのプレイリストを検索", "搜索全部播放列表"],
            ["back"] = ["Zurück", "Back", "戻る", "返回"],
            ["up"] = ["Hoch", "Up", "上へ", "向上"],
            ["browse"] = ["Durchsuchen", "Browse", "参照", "浏览"],
            ["pathHint"] = ["Pfad oder \\\\Server\\Freigabe, Enter öffnet", "Path or \\\\server\\share, Enter opens", "パスまたは \\\\サーバー\\共有、Enterで開く", "路径或 \\\\服务器\\共享，回车打开"],
            ["findHere"] = ["In diesem Ordner suchen", "Search this folder", "このフォルダーを検索", "在此文件夹中搜索"],
            ["preset"] = ["Voreinstellung", "Preset", "プリセット", "预设"],
            ["templateName"] = ["Name der eigenen Vorlage", "Name for your preset", "プリセット名", "预设名称"],
            ["lyricsFetch"] = ["Bei lrclib.net suchen", "Search on lrclib.net", "lrclib.net で検索", "在 lrclib.net 搜索"],
            ["streamUrl"] = ["Stream-URL oder M3U/PLS", "Stream URL or M3U/PLS", "ストリームURLまたは M3U/PLS", "流地址或 M3U/PLS"],
            ["name"] = ["Name", "Name", "名前", "名称"],
            ["remember"] = ["Merken", "Save", "保存", "记住"],
            ["country"] = ["Land", "Country", "国", "国家"],
            ["stationQuery"] = ["Sendername, optional", "Station name, optional", "放送局名（任意）", "电台名称，可选"],
            ["stationSearch"] = ["Sender suchen", "Find stations", "放送局を検索", "搜索电台"],
            ["sleepHeader"] = ["Schlaf-Timer (Minuten)", "Sleep timer (minutes)", "スリープタイマー（分）", "睡眠定时（分钟）"],
            ["sleepStart"] = ["Schlaf-Timer starten", "Start sleep timer", "スリープタイマー開始", "启动睡眠定时"],
            ["smartHead"] = ["Smart-Listen", "Smart lists", "スマートリスト", "智能列表"],
            ["smartReload"] = ["Smart-Ordner neu laden", "Reload smart folder", "スマートフォルダーを再読込", "重新加载智能文件夹"],
            ["recent"] = ["Zuletzt hinzugefügt", "Recently added", "最近追加", "最近添加"],
            ["lastPlayed"] = ["Zuletzt gespielt", "Recently played", "最近再生", "最近播放"],
            ["popular"] = ["Meistgespielt", "Most played", "再生回数が多い", "播放最多"],
            ["unplayed"] = ["Nie gespielt", "Never played", "未再生", "从未播放"],
            ["favorites"] = ["Favoriten", "Favorites", "お気に入り", "收藏"],
            ["output"] = ["Audioausgabe", "Audio output", "音声出力", "音频输出"],
            ["look"] = ["Darstellung", "Appearance", "外観", "外观"],
            ["accent"] = ["Akzentfarbe", "Accent color", "アクセントカラー", "强调色"],
            ["skin"] = ["Skin", "Skin", "スキン", "皮肤"],
            ["skinHint"] = ["Eigene Farbdatei als JSON in den Ordner Skins neben der EXE. Eingebaut nutzt Darstellung und Akzent.", "Put a JSON color file in the Skins folder next to the EXE. Built-in uses appearance and accent.", "EXEの隣の Skins フォルダーに JSON の色ファイルを置けます。標準は外観とアクセントを使います。", "把 JSON 颜色文件放在 EXE 旁的 Skins 文件夹。内置使用外观和强调色。"],
            ["crossfade"] = ["Überblendung in Sekunden, 0 = lückenlos", "Crossfade in seconds, 0 = gapless", "クロスフェード（秒）。0 で隙間なし", "淡入淡出秒数，0 表示无间隙"],
            ["tray"] = ["Schließen minimiert ins Tray", "Close minimizes to the tray", "閉じるとトレイへ", "关闭时最小化到托盘"],
            ["pluginsLoaded"] = ["Plugins werden beim Start geladen.", "Plugins load at startup.", "プラグインは起動時に読み込まれます。", "插件在启动时加载。"],
            ["updateUrl"] = ["Update-URL (Textdatei mit Versionsnummer)", "Update URL (text file with a version)", "アップデートURL（バージョンのテキスト）", "更新地址（含版本号的文本）"],
            ["updateCheck"] = ["Update prüfen", "Check for update", "更新を確認", "检查更新"],
            ["pluginHint"] = ["Plugins: DLL nach Plugins neben der EXE. Ereignisse: Titel, Play, Pause, Stop.", "Plugins: put a DLL in Plugins next to the EXE. Events: track, play, pause, stop.", "プラグイン: EXE隣の Plugins に DLL。イベント: 曲、再生、一時停止、停止。", "插件：把 DLL 放到 EXE 旁的 Plugins。事件：曲目、播放、暂停、停止。"],
            ["ready"] = ["Bereit", "Ready", "準備完了", "就绪"],
            ["language"] = ["Sprache", "Language", "言語", "语言"],
            ["thisPc"] = ["Dieser PC", "This PC", "この PC", "此电脑"],
            ["drivesHint"] = ["Laufwerke. Netzwerkpfad oben eintippen.", "Drives. Type a network path above.", "ドライブ。上にネットワークパスを入力。", "驱动器。在上方输入网络路径。"],
            ["themeDarkGlass"] = ["Dunkles Glas", "Dark glass", "ダークガラス", "深色玻璃"],
            ["themeDarkAcrylic"] = ["Dunkles Acryl", "Dark acrylic", "ダークアクリル", "深色亚克力"],
            ["themeLight"] = ["Helles Glas", "Light glass", "ライトガラス", "浅色玻璃"],
            ["accentCyan"] = ["Cyan", "Cyan", "シアン", "青色"],
            ["accentBlue"] = ["Blau", "Blue", "青", "蓝色"],
            ["accentGreen"] = ["Grün", "Green", "緑", "绿色"],
            ["accentAmber"] = ["Amber", "Amber", "アンバー", "琥珀"],
            ["accentRed"] = ["Rot", "Red", "赤", "红色"],
            ["accentPurple"] = ["Lila", "Purple", "紫", "紫色"],
            ["builtin"] = ["Eingebaut", "Built-in", "標準", "内置"]
        };

        public static void Use(string code)
        {
            Code = code switch
            {
                "en" or "ja" or "zh" => code,
                _ => "de"
            };
        }

        public static string T(string key)
        {
            if (!Map.TryGetValue(key, out var row))
                return key;
            var index = Code switch { "en" => 1, "ja" => 2, "zh" => 3, _ => 0 };
            return row[index];
        }

        public static bool Is(string key, string value)
        {
            if (!Map.TryGetValue(key, out var row))
                return false;
            foreach (var item in row)
            {
                if (item == value)
                    return true;
            }
            return false;
        }
    }
}
