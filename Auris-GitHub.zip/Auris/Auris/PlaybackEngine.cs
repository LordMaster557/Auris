using NAudio.CoreAudioApi;
using NAudio.Dsp;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using System;
using System.Collections.Generic;
using System.Threading;

namespace Auris
{
    public sealed class PlaybackEngine : IDisposable
    {
        const int Rate = 44100;
        static readonly float[] Bands = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

        readonly MixingSampleProvider _mixer;
        readonly Equalizer _eq;
        readonly SpectrumTap _spectrum;
        readonly BalanceSampleProvider _balance;
        readonly VolumeSampleProvider _master;
        readonly List<Voice> _voices = new();
        IWavePlayer? _output;
        Voice? _current;
        Voice? _fadingIn;
        Voice? _fadingOut;
        DateTime _fadeStart;
        bool _paused;
        bool _handoffDone;

        public PlaybackEngine()
        {
            _mixer = new MixingSampleProvider(WaveFormat.CreateIeeeFloatWaveFormat(Rate, 2)) { ReadFully = true };
            _eq = new Equalizer(_mixer);
            _spectrum = new SpectrumTap(_eq);
            _balance = new BalanceSampleProvider(_spectrum);
            _master = new VolumeSampleProvider(_balance) { Volume = 0.8f };
            OutputMode = "WaveOut";
        }

        public string OutputMode { get; private set; }
        public double CrossfadeSeconds { get; set; }
        public bool ReplayGain { get; set; } = true;
        public string? OutputError { get; private set; }

        public bool IsPlaying => _output != null && !_paused && _current != null;
        public bool CanResume => _paused && _current != null;

        public double PositionSeconds => (_fadingIn ?? _current)?.Position ?? 0;
        public double DurationSeconds => (_fadingIn ?? _current)?.Duration ?? 0;

        public double RemainingSeconds
        {
            get
            {
                var voice = _fadingIn ?? _current;
                if (voice == null) return 0;
                return Math.Max(0, voice.Duration - voice.Position);
            }
        }

        public bool NeedsHandoff
        {
            get
            {
                var voice = _current;
                if (_paused || voice == null || _fadingIn != null || _handoffDone) return false;
                if (!voice.Ready || voice.Duration <= 1) return false;
                var threshold = Math.Max(CrossfadeSeconds, 0.08);
                return voice.Drained || RemainingSeconds <= threshold;
            }
        }

        public bool HasFault
        {
            get
            {
                if (_paused) return false;
                var voice = _fadingIn ?? _current;
                return voice != null && voice.Fault;
            }
        }

        public void MarkHandoff() => _handoffDone = true;

        public void CopySpectrum(float[] dest) => _spectrum.Copy(dest);

        public void SetMaster(float volume) => _master.Volume = Math.Clamp(volume, 0, 1);

        public void SetBalance(float balance) => _balance.Balance = Math.Clamp(balance, -1, 1);

        public void SetBand(int index, float db)
        {
            if (index >= 0 && index < 10)
                _eq.SetGain(index, db);
        }

        public void Start(string path, double replayGainDb, bool crossfade)
        {
            OutputError = null;
            _paused = false;
            var reader = new StreamedVoice(path);
            var volume = new VolumeSampleProvider(reader);
            var voice = new Voice(reader, volume, replayGainDb);
            var fade = crossfade && _current != null && CrossfadeSeconds > 0;
            volume.Volume = fade ? 0 : Gain(voice);

            if (!fade)
            {
                ClearVoices();
                _handoffDone = false;
                _current = voice;
            }
            else
            {
                _fadingOut = _current;
                _fadingIn = voice;
                _fadeStart = DateTime.UtcNow;
                _handoffDone = true;
            }

            _mixer.AddMixerInput(volume);
            _voices.Add(voice);
            EnsureOutput();
            _output?.Play();
        }

        public void StartRadio(string url)
        {
            OutputError = null;
            _paused = false;
            var reader = new RadioVoice(url);
            var volume = new VolumeSampleProvider(reader) { Volume = 1 };
            var voice = new Voice(reader, volume, double.NaN);
            ClearVoices();
            _handoffDone = false;
            _current = voice;
            _mixer.AddMixerInput(volume);
            _voices.Add(voice);
            EnsureOutput();
            _output?.Play();
        }

        public void Pause()
        {
            _paused = true;
            _output?.Pause();
        }

        public void Resume()
        {
            if (_output == null || _current == null) return;
            _paused = false;
            _output.Play();
        }

        public void Stop() => Shut(true);

        public void Abandon() => Shut(false);

        void Shut(bool stopOutput)
        {
            _paused = false;
            _handoffDone = false;
            ClearVoices();
            if (!stopOutput || _output == null) return;
            try { _output.Stop(); } catch { }
            try { _output.Dispose(); } catch { }
            _output = null;
        }

        public void Seek(TimeSpan position)
        {
            var voice = _fadingIn ?? _current;
            if (voice == null) return;
            if (position < TimeSpan.Zero) position = TimeSpan.Zero;
            voice.Reader.SeekSeconds(position.TotalSeconds);
            _handoffDone = false;
        }

        public void Tick()
        {
            if (_paused || _fadingIn == null || _fadingOut == null) return;
            var dur = Math.Max(CrossfadeSeconds, 0.05);
            var t = Math.Clamp((DateTime.UtcNow - _fadeStart).TotalSeconds / dur, 0, 1);
            _fadingOut.Volume.Volume = (float)((1 - t) * Gain(_fadingOut));
            _fadingIn.Volume.Volume = (float)(t * Gain(_fadingIn));
            if (t < 1) return;
            Remove(_fadingOut);
            _current = _fadingIn;
            _fadingIn = null;
            _fadingOut = null;
            _handoffDone = false;
        }

        public void SetOutputMode(string mode)
        {
            OutputMode = mode;
            var restart = _output != null;
            var paused = _paused;
            if (_output != null)
            {
                _output.Stop();
                _output.Dispose();
                _output = null;
            }
            if (!restart || _current == null) return;
            try
            {
                EnsureOutput();
                if (paused) Pause();
                else _output?.Play();
            }
            catch (Exception ex)
            {
                OutputError = ex.Message;
            }
        }

        public void Dispose() => Stop();

        void EnsureOutput()
        {
            if (_output != null) return;
            var created = CreateOutput();
            created.Init(new SampleToWaveProvider(_master));
            _output = created;
        }

        IWavePlayer CreateOutput()
        {
            try
            {
                if (OutputMode == "WASAPI")
                    return new WasapiOut(AudioClientShareMode.Shared, 100);
                if (OutputMode == "WASAPI Exclusive")
                    return new WasapiOut(AudioClientShareMode.Exclusive, 50);
                if (OutputMode == "ASIO")
                {
                    var names = AsioOut.GetDriverNames();
                    if (names.Length == 0)
                        throw new InvalidOperationException("Kein ASIO-Treiber");
                    return new AsioOut(names[0]);
                }
            }
            catch (Exception ex)
            {
                OutputError = ex.Message;
                OutputMode = "WaveOut";
            }
            return new WaveOutEvent();
        }

        float Gain(Voice voice)
        {
            if (!ReplayGain || double.IsNaN(voice.GainDb)) return 1f;
            return (float)Math.Clamp(Math.Pow(10, voice.GainDb / 20), 0.05, 2);
        }

        void ClearVoices()
        {
            foreach (var voice in _voices.ToArray())
                Remove(voice);
            _current = null;
            _fadingIn = null;
            _fadingOut = null;
        }

        void Remove(Voice voice)
        {
            voice.Reader.Cancel();
            try { _mixer.RemoveMixerInput(voice.Volume); } catch { }
            _voices.Remove(voice);
        }

        sealed class Voice
        {
            public Voice(IPlaybackClock reader, VolumeSampleProvider volume, double gainDb)
            {
                Reader = reader;
                Volume = volume;
                GainDb = gainDb;
            }

            public IPlaybackClock Reader { get; }
            public VolumeSampleProvider Volume { get; }
            public double GainDb { get; }
            public double Position => Reader.Position;
            public double Duration => Reader.Duration;
            public bool Ready => Reader.Ready;
            public bool Drained => Reader.Drained;
            public bool Fault => Reader.Fault;
        }

        interface IPlaybackClock : ISampleProvider
        {
            double Position { get; }
            double Duration { get; }
            bool Ready { get; }
            bool Drained { get; }
            bool Fault { get; }
            void Cancel();
            void SeekSeconds(double seconds);
        }

        sealed class StreamedVoice : IPlaybackClock
        {
            readonly object _gate = new();
            readonly float[] _ring;
            readonly long _bornTicks;
            int _write;
            int _count;
            long _positionTicks;
            long _durationTicks;
            long _lastTicks;
            int _stop;
            int _ready;
            int _ended;
            int _failed;
            long _seekTicks = -1;

            public StreamedVoice(string path)
            {
                WaveFormat = WaveFormat.CreateIeeeFloatWaveFormat(Rate, 2);
                _ring = new float[Rate * 2 * 3];
                _bornTicks = DateTime.UtcNow.Ticks;
                _lastTicks = _bornTicks;
                var thread = new Thread(() => Pump(path)) { IsBackground = true, Name = "audio-read" };
                thread.Start();
            }

            public WaveFormat WaveFormat { get; }
            public double Position => TimeSpan.FromTicks(Interlocked.Read(ref _positionTicks)).TotalSeconds;
            public double Duration => TimeSpan.FromTicks(Interlocked.Read(ref _durationTicks)).TotalSeconds;
            public bool Ready => Volatile.Read(ref _ready) == 1;
            public bool Drained => Volatile.Read(ref _ended) == 1 && Buffered == 0;

            int Buffered
            {
                get { lock (_gate) return _count; }
            }

            public bool Fault
            {
                get
                {
                    if (Volatile.Read(ref _failed) == 1) return true;
                    if (Volatile.Read(ref _ended) == 1) return false;
                    var now = DateTime.UtcNow.Ticks;
                    var silent = TimeSpan.FromTicks(now - Interlocked.Read(ref _lastTicks)).TotalSeconds;
                    if (Volatile.Read(ref _ready) == 0)
                        return TimeSpan.FromTicks(now - _bornTicks).TotalSeconds > 5;
                    var duration = Duration;
                    return silent > 5 && duration > 1 && Position + 1 < duration;
                }
            }

            public void Cancel() => Interlocked.Exchange(ref _stop, 1);

            public void SeekSeconds(double seconds)
            {
                Interlocked.Exchange(ref _seekTicks, TimeSpan.FromSeconds(Math.Max(0, seconds)).Ticks);
                Interlocked.Exchange(ref _lastTicks, DateTime.UtcNow.Ticks);
            }

            public int Read(float[] buffer, int offset, int count)
            {
                lock (_gate)
                {
                    var n = Math.Min(count, _count);
                    var capacity = _ring.Length;
                    var start = (_write - _count + capacity) % capacity;
                    for (var i = 0; i < n; i++)
                        buffer[offset + i] = _ring[(start + i) % capacity];
                    _count -= n;
                    if (n < count)
                        Array.Clear(buffer, offset + n, count - n);
                }
                return count;
            }

            void Pump(string path)
            {
                AudioFileReader? reader = null;
                try
                {
                    reader = new AudioFileReader(path);
                    ISampleProvider src = reader.ToSampleProvider();
                    if (src.WaveFormat.Channels == 1)
                        src = new MonoToStereoSampleProvider(src);
                    else if (src.WaveFormat.Channels != 2)
                        src = new MultiplexingSampleProvider(new[] { src }, 2);
                    if (src.WaveFormat.SampleRate != Rate)
                        src = new WdlResamplingSampleProvider(src, Rate);
                    Interlocked.Exchange(ref _durationTicks, reader.TotalTime.Ticks);
                    Volatile.Write(ref _ready, 1);
                    Touch();
                    var block = new float[2048];
                    while (Volatile.Read(ref _stop) == 0)
                    {
                        var seek = Interlocked.Exchange(ref _seekTicks, -1);
                        if (seek >= 0)
                        {
                            try { reader.CurrentTime = new TimeSpan(seek); }
                            catch
                            {
                                Volatile.Write(ref _failed, 1);
                                break;
                            }
                            lock (_gate) _count = 0;
                        }
                        var full = false;
                        lock (_gate) full = _count > _ring.Length - block.Length;
                        if (full)
                        {
                            Touch();
                            Thread.Sleep(12);
                            continue;
                        }
                        int read;
                        try { read = src.Read(block, 0, block.Length); }
                        catch
                        {
                            Volatile.Write(ref _failed, 1);
                            break;
                        }
                        if (read <= 0)
                        {
                            Volatile.Write(ref _ended, 1);
                            break;
                        }
                        lock (_gate)
                        {
                            for (var i = 0; i < read; i++)
                            {
                                _ring[_write] = block[i];
                                _write = (_write + 1) % _ring.Length;
                                if (_count < _ring.Length) _count++;
                            }
                        }
                        try { Interlocked.Exchange(ref _positionTicks, reader.CurrentTime.Ticks); }
                        catch { Volatile.Write(ref _failed, 1); break; }
                        Touch();
                    }
                }
                catch
                {
                    Volatile.Write(ref _failed, 1);
                }
                finally
                {
                    try { reader?.Dispose(); } catch { }
                }
            }

            void Touch() => Interlocked.Exchange(ref _lastTicks, DateTime.UtcNow.Ticks);
        }

        sealed class RadioVoice : IPlaybackClock
        {
            readonly object _gate = new();
            readonly float[] _ring;
            readonly long _bornTicks;
            int _write;
            int _count;
            long _played;
            int _stop;
            int _ready;
            int _ended;
            int _failed;
            long _lastTicks;

            public RadioVoice(string url)
            {
                WaveFormat = WaveFormat.CreateIeeeFloatWaveFormat(Rate, 2);
                _ring = new float[Rate * 2 * 6];
                _bornTicks = DateTime.UtcNow.Ticks;
                _lastTicks = _bornTicks;
                var thread = new Thread(() => Pump(url)) { IsBackground = true, Name = "radio-read" };
                thread.Start();
            }

            public WaveFormat WaveFormat { get; }
            public double Position => _played / (double)(Rate * 2);
            public double Duration => 0;
            public bool Ready => Volatile.Read(ref _ready) == 1;
            public bool Drained => Volatile.Read(ref _ended) == 1 && Buffered == 0;

            int Buffered
            {
                get { lock (_gate) return _count; }
            }

            public bool Fault
            {
                get
                {
                    if (Volatile.Read(ref _failed) == 1) return true;
                    if (Volatile.Read(ref _ended) == 1) return Buffered == 0;
                    var silent = TimeSpan.FromTicks(DateTime.UtcNow.Ticks - Interlocked.Read(ref _lastTicks)).TotalSeconds;
                    if (Volatile.Read(ref _ready) == 0)
                        return TimeSpan.FromTicks(DateTime.UtcNow.Ticks - _bornTicks).TotalSeconds > 12;
                    return silent > 20;
                }
            }

            public void Cancel() => Interlocked.Exchange(ref _stop, 1);
            public void SeekSeconds(double seconds) { }

            public int Read(float[] buffer, int offset, int count)
            {
                int n;
                lock (_gate)
                {
                    n = Math.Min(count, _count);
                    var capacity = _ring.Length;
                    var start = (_write - _count + capacity) % capacity;
                    for (var i = 0; i < n; i++)
                        buffer[offset + i] = _ring[(start + i) % capacity];
                    _count -= n;
                    if (n < count)
                        Array.Clear(buffer, offset + n, count - n);
                }
                Interlocked.Add(ref _played, n);
                return count;
            }

            void Pump(string url)
            {
                MediaFoundationReader? reader = null;
                try
                {
                    reader = new MediaFoundationReader(url);
                    ISampleProvider src = reader.ToSampleProvider();
                    if (src.WaveFormat.Channels == 1)
                        src = new MonoToStereoSampleProvider(src);
                    else if (src.WaveFormat.Channels != 2)
                        src = new MultiplexingSampleProvider(new[] { src }, 2);
                    if (src.WaveFormat.SampleRate != Rate)
                        src = new WdlResamplingSampleProvider(src, Rate);
                    Volatile.Write(ref _ready, 1);
                    Interlocked.Exchange(ref _lastTicks, DateTime.UtcNow.Ticks);
                    var block = new float[2048];
                    while (Volatile.Read(ref _stop) == 0)
                    {
                        var full = false;
                        lock (_gate) full = _count > _ring.Length - block.Length;
                        if (full)
                        {
                            Interlocked.Exchange(ref _lastTicks, DateTime.UtcNow.Ticks);
                            Thread.Sleep(12);
                            continue;
                        }
                        int read;
                        try { read = src.Read(block, 0, block.Length); }
                        catch
                        {
                            Volatile.Write(ref _failed, 1);
                            break;
                        }
                        if (read <= 0)
                        {
                            Volatile.Write(ref _ended, 1);
                            break;
                        }
                        lock (_gate)
                        {
                            for (var i = 0; i < read; i++)
                            {
                                _ring[_write] = block[i];
                                _write = (_write + 1) % _ring.Length;
                                if (_count < _ring.Length) _count++;
                            }
                        }
                        Interlocked.Exchange(ref _lastTicks, DateTime.UtcNow.Ticks);
                    }
                }
                catch
                {
                    Volatile.Write(ref _failed, 1);
                }
                finally
                {
                    try { reader?.Dispose(); } catch { }
                }
            }
        }

        sealed class SpectrumTap : ISampleProvider
        {
            public const int BarCount = 32;
            readonly ISampleProvider _source;
            readonly float[] _window = new float[1024];
            readonly Complex[] _fft = new Complex[1024];
            readonly float[] _bars = new float[BarCount];
            readonly object _gate = new();
            int _filled;

            public SpectrumTap(ISampleProvider source)
            {
                _source = source;
                WaveFormat = source.WaveFormat;
            }

            public WaveFormat WaveFormat { get; }

            public void Copy(float[] dest)
            {
                lock (_gate)
                    Array.Copy(_bars, dest, Math.Min(dest.Length, BarCount));
            }

            public int Read(float[] buffer, int offset, int count)
            {
                var read = _source.Read(buffer, offset, count);
                var channels = Math.Max(1, WaveFormat.Channels);
                for (var n = 0; n + channels - 1 < read; n += channels)
                {
                    float mono = 0;
                    for (var c = 0; c < channels; c++)
                        mono += buffer[offset + n + c];
                    _window[_filled++] = mono / channels;
                    if (_filled == _window.Length)
                    {
                        Compute();
                        _filled = 0;
                    }
                }
                return read;
            }

            void Compute()
            {
                for (var i = 0; i < _window.Length; i++)
                {
                    var w = 0.5f * (1f - (float)Math.Cos(2 * Math.PI * i / (_window.Length - 1)));
                    _fft[i].X = _window[i] * w;
                    _fft[i].Y = 0;
                }
                FastFourierTransform.FFT(true, 10, _fft);
                var next = new float[BarCount];
                for (var b = 0; b < BarCount; b++)
                {
                    var start = Math.Clamp((int)Math.Pow(511, b / (double)BarCount), 1, 511);
                    var end = Math.Clamp((int)Math.Pow(511, (b + 1) / (double)BarCount), start + 1, 512);
                    float mag = 0;
                    for (var i = start; i < end; i++)
                    {
                        var re = _fft[i].X;
                        var im = _fft[i].Y;
                        mag = Math.Max(mag, (float)Math.Sqrt(re * re + im * im));
                    }
                    var db = 20f * (float)Math.Log10(mag + 1e-8);
                    next[b] = Math.Clamp((db + 72f) / 48f, 0, 1);
                }
                lock (_gate)
                {
                    for (var b = 0; b < BarCount; b++)
                        _bars[b] = Math.Max(next[b], _bars[b] * 0.7f);
                }
            }
        }

        sealed class Equalizer : ISampleProvider
        {
            readonly ISampleProvider _source;
            readonly BiQuadFilter[] _left = new BiQuadFilter[10];
            readonly BiQuadFilter[] _right = new BiQuadFilter[10];
            readonly float[] _gain = new float[10];

            public Equalizer(ISampleProvider source)
            {
                _source = source;
                WaveFormat = source.WaveFormat;
                for (var i = 0; i < 10; i++)
                    Rebuild(i);
            }

            public WaveFormat WaveFormat { get; }

            public void SetGain(int index, float db)
            {
                _gain[index] = db;
                Rebuild(index);
            }

            public int Read(float[] buffer, int offset, int count)
            {
                var read = _source.Read(buffer, offset, count);
                var active = false;
                for (var i = 0; i < 10; i++)
                    active |= Math.Abs(_gain[i]) > 0.05f;
                if (!active) return read;

                for (var n = 0; n + 1 < read; n += 2)
                {
                    var l = buffer[offset + n];
                    var r = buffer[offset + n + 1];
                    for (var i = 0; i < 10; i++)
                    {
                        if (Math.Abs(_gain[i]) <= 0.05f) continue;
                        l = _left[i].Transform(l);
                        r = _right[i].Transform(r);
                    }
                    buffer[offset + n] = l;
                    buffer[offset + n + 1] = r;
                }
                return read;
            }

            void Rebuild(int index)
            {
                _left[index] = BiQuadFilter.PeakingEQ(Rate, Bands[index], 1.0f, _gain[index]);
                _right[index] = BiQuadFilter.PeakingEQ(Rate, Bands[index], 1.0f, _gain[index]);
            }
        }
    }

    sealed class BalanceSampleProvider : ISampleProvider
    {
        readonly ISampleProvider _source;

        public BalanceSampleProvider(ISampleProvider source) => _source = source;

        public float Balance { get; set; }
        public WaveFormat WaveFormat => _source.WaveFormat;

        public int Read(float[] buffer, int offset, int count)
        {
            var read = _source.Read(buffer, offset, count);
            var balance = Balance;
            if (Math.Abs(balance) < 0.02f || read < 2)
                return read;
            var left = balance < 0 ? 1f : 1f - balance;
            var right = balance > 0 ? 1f : 1f + balance;
            for (var i = 0; i + 1 < read; i += 2)
            {
                buffer[offset + i] *= left;
                buffer[offset + i + 1] *= right;
            }
            return read;
        }
    }
}
