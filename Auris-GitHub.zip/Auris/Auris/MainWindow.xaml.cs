using Microsoft.UI.Dispatching;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Windows.Storage.Pickers;
using WinRT.Interop;

namespace Auris
{
    public sealed partial class MainWindow : Window
    {
        readonly PlayerSession _session;
        readonly PlaylistColumns _columns;
        readonly ObservableCollection<LyricLine> _lyrics = new();
        string _lyricSource = "";
        int _lyricIndex = -1;
        readonly DispatcherTimer _timer;
        PlatformServices? _platform;
        GsmSession? _gsm;
        MiniWindow? _mini;
        Track? _watched;
        Track? _marked;
        readonly float[] _spectrum = new float[32];
        readonly float[] _shown = new float[32];
        readonly Border[] _bars = new Border[32];
        bool _ready;
        bool _skinBusy;
        bool _langBusy;
        string _sort = "";
        bool _sortDesc;
        bool _drag;
        bool _exit;
        bool _reordering;

        public MainWindow()
        {
            InitializeComponent();
            WindowChrome.Attach(this);
            var appIcon = Path.Combine(AppContext.BaseDirectory, "Assets", "Auris_Icon.ico");
            if (File.Exists(appIcon))
                AppWindow.SetIcon(appIcon);
            Root.Loaded += async (_, _) => await EnsureLanguage();
            NavShell.SizeChanged += (_, e) =>
            {
                NavShell.Clip = new RectangleGeometry
                {
                    Rect = new Windows.Foundation.Rect(0, 0, e.NewSize.Width, Math.Max(e.NewSize.Height, 1))
                };
            };
            _columns = (PlaylistColumns)Root.Resources["Columns"];
            if (Content is UIElement page)
                page.AddHandler(UIElement.KeyDownEvent, new KeyEventHandler(Window_KeyDown), true);
            PlaylistView.SelectionMode = ListViewSelectionMode.Multiple;
            PlaylistView.IsMultiSelectCheckBoxEnabled = true;
            PlaylistView.AddHandler(UIElement.DoubleTappedEvent, new DoubleTappedEventHandler(Playlist_DoubleTapped), true);
            LyricsView.ItemsSource = _lyrics;
            _session = new PlayerSession(DispatcherQueue.GetForCurrentThread());
            _session.PlaybackNotice += (kind, path, title) => _platform?.Notify(kind, path, title);
            LoadColumnWidths();
            _session.Changed += Refresh;
            _session.Playlist.CollectionChanged += OnPlaylistChanged;
            QueueView.ItemsSource = _session.Queue;
            BookmarkView.ItemsSource = _session.Bookmarks;
            BuildEq();
            BuildSpectrum();
            FillBoxes();
            ApplyTheme(_session.Settings.Theme);
            _session.RestoreSession();
            RestoreWindow();
            ScheduleFilter();
            VolumeSlider.Value = _session.Settings.Volume * 100;
            CrossfadeSlider.Value = _session.Settings.Crossfade;
            VolumeSlider.ValueChanged += (_, _) => _session.SetVolume((float)(VolumeSlider.Value / 100));
            VolumeSlider.PointerCaptureLost += (_, _) => _session.SaveSettings();
            BalanceSlider.Value = _session.Settings.Balance * 100;
            _session.Engine.SetBalance(_session.Settings.Balance);
            BalanceSlider.ValueChanged += (_, _) =>
            {
                _session.Settings.Balance = (float)(BalanceSlider.Value / 100);
                _session.Engine.SetBalance(_session.Settings.Balance);
            };
            BalanceSlider.PointerCaptureLost += (_, _) => _session.SaveSettings();
            CrossfadeSlider.ValueChanged += (_, _) => _session.SetCrossfade(CrossfadeSlider.Value);
            SeekSlider.AddHandler(UIElement.PointerPressedEvent, new PointerEventHandler((_, _) => _drag = true), true);
            SeekSlider.AddHandler(UIElement.PointerReleasedEvent, new PointerEventHandler((_, _) =>
            {
                _drag = false;
                _session.Seek(SeekSlider.Value);
            }), true);
            _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(33) };
            _timer.Tick += (_, _) =>
            {
                _session.Tick();
                UpdateClock();
                PushNowPlaying();
                if (_windowDirty && ++_windowTick > 45)
                {
                    _windowTick = 0;
                    _windowDirty = false;
                    RememberWindow();
                }
            };
            _timer.Start();
            Activated += (_, _) => EnsurePlatform();
            Root.Loaded += (_, _) => EnsurePlatform();
            AppWindow.Closing += (_, e) =>
            {
                if (_exit || _platform?.TrayVisible != true || !_session.Settings.MinimizeToTray)
                    return;
                e.Cancel = true;
                AppWindow.Hide();
            };
            Closed += (_, _) =>
            {
                _timer.Stop();
                RememberWindow();
                SaveActiveList();
                _session.SaveSession();
                _session.SaveSettings();
                _platform?.Dispose();
                _gsm?.Dispose();
                _session.Engine.Dispose();
                _mini?.Close();
            };
            AppWindow.Changed += (_, args) =>
            {
                if (args.DidPositionChange || args.DidSizeChange || args.DidPresenterChange)
                    _windowDirty = true;
            };
            Refresh();
            EnsureLists();
            LoadHistory();
            MarkNav("playlist");
        }

        sealed class PlayerBridge : IPlayerHost
        {
            readonly PlayerSession _session;
            public PlayerBridge(PlayerSession session) => _session = session;
            public string CurrentPath => _session.IsRadio ? _session.RadioUrl : _session.Current?.Path ?? "";
            public string CurrentTitle => _session.IsRadio ? _session.RadioTitle : _session.Current?.Display ?? "";
            public bool IsPlaying => _session.IsPlaying;
            public void Play() { if (!_session.IsPlaying) _session.PlayPause(); }
            public void Pause() { if (_session.IsPlaying) _session.PlayPause(); }
            public void Stop() => _session.Stop();
            public void Next() => _session.Next(true);
            public void Enqueue(string path)
            {
                if (!string.IsNullOrWhiteSpace(path))
                    _session.Enqueue(new Track(path));
            }
        }

        public PlayerSession Session => _session;

        void EnsurePlatform()
        {
            if (_platform != null) return;
            var hwnd = WindowNative.GetWindowHandle(this);
            _platform = new PlatformServices(hwnd, DispatcherQueue.GetForCurrentThread(), OnCommand, () =>
            {
                AppWindow.Show();
                Activate();
            });
            _platform.ShowTray("Auris");
            _platform.Bind(new PlayerBridge(_session));
            if (_gsm == null)
            {
                _gsm = new GsmSession(DispatcherQueue.GetForCurrentThread(), hwnd);
                _gsm.OnCommand = OnCommand;
                _gsm.OnSeek = sec => _session.Seek(Math.Max(0, sec));
                _ = _gsm.InitAsync();
            }
            PushNowPlaying();
            var names = new List<string>();
            foreach (var plugin in _platform.Plugins)
                names.Add(plugin.Name);
            PluginText.Text = "Plugins: " + string.Join(", ", names) + ". DLL nach Plugins legen. Beispielprojekt: PluginBeispiel. Log: data/plugin-log.txt.";
        }

        void OnCommand(int id)
        {
            switch (id)
            {
                case 1: _session.PlayPause(); break;
                case 11: if (!_session.IsPlaying) _session.PlayPause(); break;
                case 12: if (_session.IsPlaying) _session.PlayPause(); break;
                case 2: _session.Next(true); break;
                case 3: _session.Previous(); break;
                case 4: _session.Stop(); break;
            }
        }

        readonly Slider[] _eqSliders = new Slider[10];
        bool _eqBusy;

        static readonly Dictionary<string, float[]> EqPresets = new()
        {
            ["Flach"] = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
            ["Classic"] = new float[] { 4, 3, 2, 1, 0, 0, 1, 2, 3, 4 },
            ["Pop"] = new float[] { -1, 2, 4, 5, 3, 0, -1, -1, 1, 2 },
            ["Rock"] = new float[] { 5, 4, 3, 1, -1, -1, 1, 3, 4, 5 },
            ["Vocal"] = new float[] { -2, -1, 0, 2, 4, 4, 3, 1, 0, -1 },
            ["Jazz"] = new float[] { 3, 2, 1, 2, -1, -1, 0, 1, 2, 3 },
            ["Bass"] = new float[] { 6, 5, 4, 2, 1, 0, 0, 0, 0, 0 },
            ["Elektronisch"] = new float[] { 5, 4, 1, 0, -2, 0, 1, 2, 4, 5 }
        };

        void BuildEq()
        {
            var labels = new[] { "31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k" };
            EqPanel.ColumnDefinitions.Clear();
            EqPanel.RowDefinitions.Clear();
            EqPanel.Children.Clear();
            EqPanel.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            EqPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            for (var i = 0; i < 10; i++)
            {
                var index = i;
                EqPanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                var slider = new Slider
                {
                    Orientation = Orientation.Vertical,
                    Minimum = -12,
                    Maximum = 12,
                    Height = 180,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Value = _session.Settings.Eq.Length > i ? _session.Settings.Eq[i] : 0
                };
                slider.ValueChanged += (_, _) =>
                {
                    if (_eqBusy || !_ready)
                        return;
                    _session.SetBand(index, (float)slider.Value);
                };
                Grid.SetColumn(slider, i);
                Grid.SetRow(slider, 0);
                EqPanel.Children.Add(slider);
                var label = new TextBlock { Text = labels[i], HorizontalAlignment = HorizontalAlignment.Center };
                Grid.SetColumn(label, i);
                Grid.SetRow(label, 1);
                EqPanel.Children.Add(label);
                _eqSliders[i] = slider;
            }
            FillEqPresets();
        }

        void FillEqPresets()
        {
            var selected = EqPresetBox.SelectedItem as string;
            _eqBusy = true;
            EqPresetBox.Items.Clear();
            foreach (var name in EqPresets.Keys)
                EqPresetBox.Items.Add(name);
            if (_session.Settings.EqTemplates != null)
            {
                foreach (var name in _session.Settings.EqTemplates.Keys)
                {
                    if (!EqPresetBox.Items.Contains(name))
                        EqPresetBox.Items.Add(name);
                }
            }
            if (selected != null && EqPresetBox.Items.Contains(selected))
                EqPresetBox.SelectedItem = selected;
            _eqBusy = false;
        }

        void ApplyEq(float[] values)
        {
            _eqBusy = true;
            for (var i = 0; i < 10; i++)
                _eqSliders[i].Value = values[i];
            _eqBusy = false;
            _session.SetEq(values);
        }

        void EqPreset_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_eqBusy || !_ready)
                return;
            if (EqPresetBox.SelectedItem is not string name)
                return;
            if (EqPresets.TryGetValue(name, out var builtIn))
            {
                ApplyEq(builtIn);
                return;
            }
            if (_session.Settings.EqTemplates != null && _session.Settings.EqTemplates.TryGetValue(name, out var saved) && saved.Length == 10)
                ApplyEq(saved);
        }

        void EqSave_Click(object sender, RoutedEventArgs e)
        {
            var name = EqTemplateBox.Text.Trim();
            if (name.Length == 0)
            {
                StatusText.Text = "Name für die Equalizer-Vorlage fehlt";
                return;
            }
            _session.SaveEqTemplate(name);
            FillEqPresets();
            _eqBusy = true;
            EqPresetBox.SelectedItem = name;
            _eqBusy = false;
            StatusText.Text = "Equalizer-Vorlage gespeichert: " + name;
        }

        void EqDelete_Click(object sender, RoutedEventArgs e)
        {
            if (EqPresetBox.SelectedItem is not string name || EqPresets.ContainsKey(name))
            {
                StatusText.Text = "Nur eigene Vorlagen können gelöscht werden";
                return;
            }
            _session.DeleteEqTemplate(name);
            FillEqPresets();
            StatusText.Text = "Vorlage gelöscht: " + name;
        }

        void FillBoxes()
        {
            OutputBox.Items.Add("WaveOut");
            OutputBox.Items.Add("WASAPI");
            OutputBox.Items.Add("WASAPI Exclusive");
            OutputBox.Items.Add("ASIO");
            ThemeBox.Items.Add("Dunkles Glas");
            ThemeBox.Items.Add("Dunkles Acryl");
            ThemeBox.Items.Add("Helles Glas");
            AccentBox.Items.Add("Cyan");
            AccentBox.Items.Add("Blau");
            AccentBox.Items.Add("Grün");
            AccentBox.Items.Add("Amber");
            AccentBox.Items.Add("Rot");
            AccentBox.Items.Add("Lila");
            ReplayGainBox.IsOn = _session.Settings.ReplayGain;
            TrayBox.IsOn = _session.Settings.MinimizeToTray;
            UpdateBox.Text = _session.Settings.UpdateUrl;
            OutputBox.SelectedItem = _session.Settings.Output;
            ThemeBox.SelectedIndex = _session.Settings.Theme switch
            {
                "acrylic" => 1,
                "light" => 2,
                _ => 0
            };
            AccentBox.SelectedIndex = _session.Settings.Accent switch
            {
                "blue" => 1,
                "green" => 2,
                "amber" => 3,
                "red" => 4,
                "lila" => 5,
                _ => 0
            };
            ApplyAccent(_session.Settings.Accent);
            FillSkins();
            _ready = true;
        }

        void FillSkins()
        {
            SkinBox.Items.Clear();
            SkinBox.Items.Add(Strings.T("builtin"));
            var dir = Path.Combine(AppContext.BaseDirectory, "Skins");
            Directory.CreateDirectory(dir);
            foreach (var file in Directory.GetFiles(dir, "*.json"))
                SkinBox.Items.Add(Path.GetFileNameWithoutExtension(file));
            var saved = _session.Settings.Skin;
            SkinBox.SelectedItem = string.IsNullOrEmpty(saved) ? Strings.T("builtin") : saved;
            if (SkinBox.SelectedIndex < 0)
                SkinBox.SelectedIndex = 0;
        }

        async Task EnsureLanguage()
        {
            if (string.IsNullOrWhiteSpace(_session.Settings.Language))
            {
                var chosen = new TaskCompletionSource<string>();
                var panel = new StackPanel { Spacing = 8 };
                void Add(string code, string label)
                {
                    var button = new Button { Content = label, HorizontalAlignment = HorizontalAlignment.Stretch };
                    button.Click += (_, _) => chosen.TrySetResult(code);
                    panel.Children.Add(button);
                }
                Add("de", "Deutsch");
                Add("en", "English");
                Add("ja", "日本語");
                Add("zh", "简体中文");
                var dialog = new ContentDialog
                {
                    Title = "Auris",
                    Content = panel,
                    XamlRoot = Root.XamlRoot
                };
                dialog.Closing += (_, args) =>
                {
                    if (!chosen.Task.IsCompleted)
                        args.Cancel = true;
                };
                var shown = dialog.ShowAsync();
                var code = await chosen.Task;
                _session.Settings.Language = code;
                _session.SaveSettings();
                dialog.Hide();
                try { await shown; } catch { }
            }
            Strings.Use(_session.Settings.Language);
            ApplyLanguage();
        }

        void Language_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_langBusy || !_ready || LanguageBox.SelectedIndex < 0) return;
            var code = LanguageBox.SelectedIndex switch
            {
                1 => "en",
                2 => "ja",
                3 => "zh",
                _ => "de"
            };
            if (code == Strings.Code && _session.Settings.Language == code) return;
            _session.Settings.Language = code;
            _session.SaveSettings();
            Strings.Use(code);
            ApplyLanguage();
        }

        void ApplyLanguage()
        {
            _langBusy = true;
            NavPlaylist.Text = Strings.T("playlist");
            NavLibrary.Text = Strings.T("library");
            NavFolders.Text = Strings.T("folders");
            NavSearch.Text = Strings.T("search");
            NavRadio.Text = Strings.T("radio");
            NavQueue.Text = Strings.T("queue");
            NavMarks.Text = Strings.T("marks");
            NavHistory.Text = Strings.T("history");
            NavEq.Text = Strings.T("eq");
            NavLyrics.Text = Strings.T("lyrics");
            NavLists.Text = Strings.T("lists");
            NavSettings.Text = Strings.T("settings");
            FilterBox.PlaceholderText = Strings.T("filter");
            OpenButton.Content = Strings.T("open");
            SaveButton.Content = Strings.T("save");
            RemoveButton.Content = Strings.T("remove");
            MoreButton.Content = Strings.T("more");
            TranslateMenu(MoreMenu);
            TranslateMenu(TrackMenu);
            TitleSort.Content = Strings.T("title");
            ArtistSort.Content = Strings.T("artist");
            AlbumSort.Content = Strings.T("album");
            LengthSort.Content = Strings.T("length");
            CloseSideButton.Content = Strings.T("close");
            ClearQueueButton.Content = Strings.T("clear");
            SearchAllBox.PlaceholderText = Strings.T("searchAll");
            FolderBackButton.Content = Strings.T("back");
            FolderUpButton.Content = Strings.T("up");
            FolderBrowseButton.Content = Strings.T("browse");
            FolderAddButton.Content = Strings.T("addFolder");
            FolderPathBox.PlaceholderText = Strings.T("pathHint");
            FolderFindBox.PlaceholderText = Strings.T("findHere");
            if (Strings.Is("thisPc", FolderPathBox.Text))
                FolderPathBox.Text = Strings.T("thisPc");
            EqPresetBox.Header = Strings.T("preset");
            EqTemplateBox.PlaceholderText = Strings.T("templateName");
            EqSaveButton.Content = Strings.T("save");
            EqDeleteButton.Content = Strings.T("remove");
            LyricsFetchButton.Content = Strings.T("lyricsFetch");
            RadioUrlBox.PlaceholderText = Strings.T("streamUrl");
            RadioNameBox.PlaceholderText = Strings.T("name");
            RadioPlayButton.Content = Strings.T("play");
            RadioSaveButton.Content = Strings.T("remember");
            RadioRemoveButton.Content = Strings.T("removeItem");
            RadioCountryBox.PlaceholderText = Strings.T("country");
            RadioQueryBox.PlaceholderText = Strings.T("stationQuery");
            RadioSearchButton.Content = Strings.T("stationSearch");
            SleepBox.Header = Strings.T("sleepHeader");
            SleepButton.Content = Strings.T("sleepStart");
            SmartHead.Text = Strings.T("smartHead");
            SmartReloadButton.Content = Strings.T("smartReload");
            RecentButton.Content = Strings.T("recent");
            LastPlayedButton.Content = Strings.T("lastPlayed");
            PopularButton.Content = Strings.T("popular");
            UnplayedButton.Content = Strings.T("unplayed");
            FavoritesButton.Content = Strings.T("favorites");
            LanguageBox.Header = Strings.T("language");
            OutputBox.Header = Strings.T("output");
            ThemeBox.Header = Strings.T("look");
            AccentBox.Header = Strings.T("accent");
            SkinBox.Header = Strings.T("skin");
            SkinHint.Text = Strings.T("skinHint");
            CrossfadeHint.Text = Strings.T("crossfade");
            ReplayGainBox.Header = "ReplayGain";
            TrayBox.Header = Strings.T("tray");
            PluginText.Text = Strings.T("pluginsLoaded");
            UpdateBox.Header = Strings.T("updateUrl");
            UpdateButton.Content = Strings.T("updateCheck");
            PluginHint.Text = Strings.T("pluginHint");
            if (string.IsNullOrWhiteSpace(StatusText.Text) || Strings.Is("ready", StatusText.Text))
                StatusText.Text = Strings.T("ready");
            if (_side != null)
                SideTitle.Text = Strings.T(_side);
            RefillChoice(ThemeBox, "themeDarkGlass", "themeDarkAcrylic", "themeLight");
            RefillChoice(AccentBox, "accentCyan", "accentBlue", "accentGreen", "accentAmber", "accentRed", "accentPurple");
            FillLanguages();
            FillSkins();
            _langBusy = false;
        }

        static void TranslateMenu(MenuFlyout menu)
        {
            foreach (var item in menu.Items)
            {
                if (item is MenuFlyoutItem entry && entry.Tag is string key)
                    entry.Text = Strings.T(key);
                else if (item is MenuFlyoutSubItem sub && sub.Tag is string subKey)
                    sub.Text = Strings.T(subKey);
            }
        }

        static void RefillChoice(ComboBox box, params string[] keys)
        {
            var index = box.SelectedIndex;
            box.Items.Clear();
            foreach (var key in keys)
                box.Items.Add(Strings.T(key));
            box.SelectedIndex = index >= 0 && index < box.Items.Count ? index : 0;
        }

        void FillLanguages()
        {
            var index = Strings.Code switch { "en" => 1, "ja" => 2, "zh" => 3, _ => 0 };
            if (LanguageBox.Items.Count != 4)
            {
                LanguageBox.Items.Clear();
                LanguageBox.Items.Add("Deutsch");
                LanguageBox.Items.Add("English");
                LanguageBox.Items.Add("日本語");
                LanguageBox.Items.Add("简体中文");
            }
            LanguageBox.SelectedIndex = index;
        }

        void PushNowPlaying()
        {
            var gsm = _gsm;
            if (gsm == null) return;
            var pos = _session.Engine.PositionSeconds;
            var dur = _session.Engine.DurationSeconds;
            if (dur <= 0)
                dur = _session.Current?.DurationSeconds ?? 0;
            var active = _session.IsPlaying || _session.Engine.CanResume;
            if (_session.IsRadio)
                gsm.Push(_session.RadioTitle, "Internetradio", "", active, _session.IsPlaying, pos, dur, null);
            else if (_session.Current != null)
            {
                var track = _session.Current;
                gsm.Push(track.TitleText, track.Artist, track.Album, active, _session.IsPlaying, pos, dur, track.CoverPath);
            }
            else
                gsm.Push("Auris", "", "", false, false, 0, 0, null);
        }

        void Refresh()
        {
            ShuffleButton.IsChecked = _session.Shuffle;
            PaintChrome();
            StatusText.Text = _session.Status;
            UpdateStats();
            PaintChrome();
            var track = _session.Current;
            TitleText.Text = _session.IsRadio ? _session.RadioTitle : track?.TitleText ?? "Auris";
            ArtistText.Text = _session.IsRadio ? "Internetradio" : track?.Artist ?? "";
            AlbumText.Text = _session.IsRadio ? "" : track?.Album ?? "";
            if (!ReferenceEquals(_watched, track))
            {
                if (_watched != null) _watched.PropertyChanged -= TrackChanged;
                _watched = track;
                if (track != null)
                {
                    track.PropertyChanged += TrackChanged;
                    if (string.IsNullOrWhiteSpace(track.CoverPath))
                        _ = LoadCoverAsync(track);
                    _ = LoadLyricsAsync(track, false);
                }
            }
            if (!ReferenceEquals(_marked, track))
            {
                if (_marked != null)
                    _marked.IsCurrent = false;
                _marked = track;
                if (track != null)
                {
                    track.IsCurrent = true;
                    if (_session.Playlist.Contains(track))
                    {
                        PlaylistView.ScrollIntoView(track);
                        Remember(track);
                    }
                }
            }
            else if (track != null)
                track.IsCurrent = true;
            LyricsBoxShow(track?.Lyrics ?? "");
            ShowCover();
            if (track != null && _session.Playlist.Contains(track) && PlaylistView.SelectedItems.Count <= 1)
                PlaylistView.SelectedItem = track;
            PushNowPlaying();
            _mini?.Refresh();
        }

        void TrackChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Track.CoverPath))
                ShowCover();
            else if (e.PropertyName == nameof(Track.Lyrics) && sender is Track lyrics)
                LyricsBoxShow(lyrics.Lyrics);
            else if (sender is Track track)
            {
                TitleText.Text = track.TitleText;
                ArtistText.Text = track.Artist;
                AlbumText.Text = track.Album;
            }
        }

        void ShowCover()
        {
            var path = _session.Current?.CoverPath;
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                CoverImage.Source = null;
                return;
            }
            CoverImage.Source = new BitmapImage(new Uri(path));
        }

        async Task LoadCoverAsync(Track track)
        {
            var path = await Library.FetchCoverAsync(track);
            if (path == null || !ReferenceEquals(_session.Current, track)) return;
            track.SetCover(path);
        }

        void UpdateClock()
        {
            var duration = _session.Engine.DurationSeconds;
            var position = _session.Engine.PositionSeconds;
            if (_session.IsRadio)
            {
                SeekSlider.IsEnabled = false;
                TimeText.Text = "Live  " + Format(position);
            }
            else
            {
                SeekSlider.IsEnabled = true;
                if (!_drag && duration > 0)
                {
                    SeekSlider.Maximum = duration;
                    SeekSlider.Value = Math.Clamp(position, 0, duration);
                }
                TimeText.Text = Format(position) + " / " + Format(duration);
            }
            var play = _session.IsPlaying ? "\uE769" : "\uE768";
            if (PlayGlyph.Glyph != play)
                PlayGlyph.Glyph = play;
            FollowLyrics();
            UpdateSpectrum();
        }

        void BuildSpectrum()
        {
            SpectrumHost.ColumnDefinitions.Clear();
            var brush = Root.Resources["AccentBrush"] as SolidColorBrush
                ?? new SolidColorBrush(Windows.UI.Color.FromArgb(255, 80, 220, 255));
            for (var i = 0; i < _bars.Length; i++)
            {
                SpectrumHost.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                var bar = new Border
                {
                    Background = brush,
                    Margin = new Thickness(1, 0, 1, 0),
                    VerticalAlignment = VerticalAlignment.Bottom,
                    Height = 2,
                    CornerRadius = new CornerRadius(1)
                };
                Grid.SetColumn(bar, i);
                SpectrumHost.Children.Add(bar);
                _bars[i] = bar;
            }
        }

        void UpdateSpectrum()
        {
            if (_session.IsPlaying)
                _session.Engine.CopySpectrum(_spectrum);
            else
            {
                for (var i = 0; i < _spectrum.Length; i++)
                    _spectrum[i] *= 0.82f;
            }
            var height = SpectrumHost.ActualHeight;
            if (height < 8) height = 138;
            for (var i = 0; i < _bars.Length; i++)
            {
                _shown[i] += (_spectrum[i] - _shown[i]) * 0.55f;
                _bars[i].Height = Math.Max(2, _shown[i] * height);
            }
        }

        static string Format(double seconds)
        {
            if (seconds < 0 || double.IsNaN(seconds)) seconds = 0;
            var time = TimeSpan.FromSeconds(seconds);
            return time.Hours > 0 ? time.ToString(@"h\:mm\:ss") : time.ToString(@"mm\:ss");
        }

        void ApplyFilter()
        {
            var text = FilterBox.Text.Trim();
            var view = new List<Track>();
            foreach (var track in _session.Playlist)
            {
                if (_artistFilter.Length > 0
                    && !string.Equals(track.Artist, _artistFilter, StringComparison.OrdinalIgnoreCase))
                    continue;
                if (_albumFilter.Length > 0
                    && !string.Equals(track.Album, _albumFilter, StringComparison.OrdinalIgnoreCase))
                    continue;
                if (text.Length == 0
                    || track.Display.Contains(text, StringComparison.OrdinalIgnoreCase)
                    || track.TitleText.Contains(text, StringComparison.OrdinalIgnoreCase)
                    || track.Album.Contains(text, StringComparison.OrdinalIgnoreCase)
                    || track.Name.Contains(text, StringComparison.OrdinalIgnoreCase)
                    || track.Path.Contains(text, StringComparison.OrdinalIgnoreCase))
                    view.Add(track);
            }
            if (_sort.Length > 0)
            {
                view.Sort((a, b) =>
                {
                    var cmp = _sort switch
                    {
                        "artist" => string.Compare(a.Artist, b.Artist, StringComparison.OrdinalIgnoreCase),
                        "album" => string.Compare(a.Album, b.Album, StringComparison.OrdinalIgnoreCase),
                        "length" => a.DurationSeconds.CompareTo(b.DurationSeconds),
                        "rating" => a.Rating.CompareTo(b.Rating),
                        _ => string.Compare(a.TitleText, b.TitleText, StringComparison.OrdinalIgnoreCase)
                    };
                    return _sortDesc ? -cmp : cmp;
                });
            }
            PlaylistView.ItemsSource = view;
            PlaylistView.SelectedItem = _session.Current;
        }

        void SortTitle_Click(object sender, RoutedEventArgs e) => ToggleSort("title");
        void SortArtist_Click(object sender, RoutedEventArgs e) => ToggleSort("artist");
        void SortAlbum_Click(object sender, RoutedEventArgs e) => ToggleSort("album");
        void SortLength_Click(object sender, RoutedEventArgs e) => ToggleSort("length");
        void SortRating_Click(object sender, RoutedEventArgs e) => ToggleSort("rating");

        void ToggleSort(string key)
        {
            if (_sort == key) _sortDesc = !_sortDesc;
            else
            {
                _sort = key;
                _sortDesc = false;
            }
            ApplyFilter();
            PaintSort();
        }

        void PaintSort()
        {
            var accent = Root.Resources["AccentBrush"] as Brush;
            var muted = Root.Resources["MutedBrush"] as Brush;
            string Mark(string key, string label) => _sort == key ? label + (_sortDesc ? "  ↓" : "  ↑") : label;
            TitleSort.Content = Mark("title", "Titel");
            ArtistSort.Content = Mark("artist", "Interpret");
            AlbumSort.Content = Mark("album", "Album");
            LengthSort.Content = Mark("length", "Länge");
            RatingSort.Content = Mark("rating", "★");
            TitleSort.Foreground = _sort == "title" ? accent : muted;
            ArtistSort.Foreground = _sort == "artist" ? accent : muted;
            AlbumSort.Foreground = _sort == "album" ? accent : muted;
            LengthSort.Foreground = _sort == "length" ? accent : muted;
            RatingSort.Foreground = _sort == "rating" ? accent : muted;
        }

        void PaintChrome()
        {
            var accent = Root.Resources["AccentBrush"] as Brush;
            var muted = Root.Resources["MutedBrush"] as Brush;
            PlayGlyph.Glyph = _session.IsPlaying ? "\uE769" : "\uE768";
            ShuffleGlyph.Foreground = _session.Shuffle ? accent : muted;
            RepeatGlyph.Glyph = _session.Repeat == "one" ? "\uE8ED" : "\uE8EE";
            RepeatGlyph.Foreground = _session.Repeat == "off" ? muted : accent;
            LoopGlyph.Foreground = _session.LoopLabel == "A-B" ? muted : accent;
        }

        void ApplyTheme(string theme)
        {
            var light = theme == "light";
            Root.RequestedTheme = light ? ElementTheme.Light : ElementTheme.Dark;
            SystemBackdrop = theme == "acrylic" ? new DesktopAcrylicBackdrop() : new MicaBackdrop();
            if (Root.Resources["PanelBrush"] is SolidColorBrush panel)
                panel.Color = light
                    ? Windows.UI.Color.FromArgb(28, 0, 0, 0)
                    : Windows.UI.Color.FromArgb(20, 255, 255, 255);
            if (Root.Resources["MutedBrush"] is SolidColorBrush muted)
                muted.Color = light
                    ? Windows.UI.Color.FromArgb(160, 0, 0, 0)
                    : Windows.UI.Color.FromArgb(179, 255, 255, 255);
            if (Root.Resources["LineBrush"] is SolidColorBrush line)
                line.Color = light
                    ? Windows.UI.Color.FromArgb(40, 0, 0, 0)
                    : Windows.UI.Color.FromArgb(32, 255, 255, 255);
            _mini?.ApplyLook(theme);
        }

        bool ApplySkin(string name)
        {
            var file = Path.Combine(AppContext.BaseDirectory, "Skins", name + ".json");
            if (!File.Exists(file)) return false;
            SkinFile? skin;
            try
            {
                skin = JsonSerializer.Deserialize<SkinFile>(File.ReadAllText(file), new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });
            }
            catch { return false; }
            if (skin == null) return false;
            Root.RequestedTheme = skin.Light ? ElementTheme.Light : ElementTheme.Dark;
            SystemBackdrop = skin.Backdrop == "acrylic" ? new DesktopAcrylicBackdrop() : new MicaBackdrop();
            SetBrush("AccentBrush", skin.Accent);
            SetBrush("PanelBrush", skin.Panel);
            SetBrush("LineBrush", skin.Line);
            SetBrush("MutedBrush", skin.Muted);
            SetBrush("InkBrush", skin.Ink);
            _mini?.ApplyLook(skin.Light ? "light" : skin.Backdrop == "acrylic" ? "acrylic" : "mica");
            PaintChrome();
            return true;
        }

        void SetBrush(string key, string hex)
        {
            if (Root.Resources[key] is not SolidColorBrush brush) return;
            if (!TryHex(hex, out var color)) return;
            brush.Color = color;
        }

        static bool TryHex(string hex, out Windows.UI.Color color)
        {
            color = default;
            if (string.IsNullOrWhiteSpace(hex)) return false;
            hex = hex.Trim();
            if (hex.StartsWith('#')) hex = hex[1..];
            if (hex.Length != 6 && hex.Length != 8) return false;
            if (!uint.TryParse(hex, System.Globalization.NumberStyles.HexNumber, null, out var value)) return false;
            if (hex.Length == 6) value |= 0xFF000000;
            color = Windows.UI.Color.FromArgb(
                (byte)((value >> 24) & 255),
                (byte)((value >> 16) & 255),
                (byte)((value >> 8) & 255),
                (byte)(value & 255));
            return true;
        }

        void ApplyAccent(string accent)
        {
            if (Root.Resources["AccentBrush"] is not SolidColorBrush brush)
                return;
            brush.Color = accent switch
            {
                "blue" => Windows.UI.Color.FromArgb(255, 76, 141, 255),
                "green" => Windows.UI.Color.FromArgb(255, 61, 220, 132),
                "amber" => Windows.UI.Color.FromArgb(255, 255, 176, 32),
                "red" => Windows.UI.Color.FromArgb(255, 225, 6, 0),
                "lila" => Windows.UI.Color.FromArgb(255, 154, 107, 255),
                _ => Windows.UI.Color.FromArgb(255, 80, 220, 255)
            };
        }

        IntPtr Hwnd => WindowNative.GetWindowHandle(this);

        async void Open_Click(object sender, RoutedEventArgs e)
        {
            var picker = new FileOpenPicker();
            InitializeWithWindow.Initialize(picker, Hwnd);
            foreach (var ext in Library.AudioExtensions)
                picker.FileTypeFilter.Add(ext);
            var files = await picker.PickMultipleFilesAsync();
            if (files == null) return;
            var paths = new List<string>();
            foreach (var file in files)
                paths.Add(file.Path);
            _session.AddPaths(paths);
        }

        async void BrowseDisk_Click(object sender, RoutedEventArgs e)
        {
            if (_side == "folders")
                CloseSide();
            var picker = new FileOpenPicker();
            InitializeWithWindow.Initialize(picker, Hwnd);
            picker.SuggestedStartLocation = PickerLocationId.MusicLibrary;
            picker.ViewMode = PickerViewMode.List;
            foreach (var ext in Library.AudioExtensions)
                picker.FileTypeFilter.Add(ext);
            var files = await picker.PickMultipleFilesAsync();
            if (files == null || files.Count == 0) return;
            var paths = new List<string>();
            foreach (var file in files)
                paths.Add(file.Path);
            var dir = Path.GetDirectoryName(paths[0]);
            if (!string.IsNullOrWhiteSpace(dir))
            {
                _session.Settings.BrowserFolder = dir;
                _session.SaveSettings();
            }
            _session.AddPaths(paths);
        }

        async void Folder_Click(object sender, RoutedEventArgs e)
        {
            var picker = new FolderPicker();
            InitializeWithWindow.Initialize(picker, Hwnd);
            picker.FileTypeFilter.Add("*");
            var folder = await picker.PickSingleFolderAsync();
            if (folder != null)
                await _session.AddFolderAsync(folder.Path);
            Refresh();
        }

        void Play_Click(object sender, RoutedEventArgs e)
        {
            if (_session.DeckHeld)
            {
                var picked = PlaylistView.SelectedItem as Track;
                if (picked == null && _session.Playlist.Count > 0)
                    picked = _session.Playlist[0];
                if (picked == null)
                {
                    _session.PlayPause();
                    return;
                }
                PlayHere(picked);
                return;
            }
            if (!_session.IsPlaying && PlaylistView.SelectedItem is Track track)
                PlayHere(track);
            else
                _session.PlayPause();
        }

        void PlayHere(Track track)
        {
            _playingList = _activeList;
            _session.ReleaseDeck();
            _session.Play(track, false);
            RenderTabs();
        }

        bool _windowDirty;
        int _windowTick;

        void RestoreWindow()
        {
            var settings = _session.Settings;
            if (settings.WindowW < 640 || settings.WindowH < 480)
                return;
            var area = DisplayArea.GetFromPoint(new Windows.Graphics.PointInt32(settings.WindowX + 48, settings.WindowY + 48), DisplayAreaFallback.Nearest);
            var work = area.WorkArea;
            var width = Math.Clamp(settings.WindowW, 960, Math.Max(960, work.Width));
            var height = Math.Clamp(settings.WindowH, 640, Math.Max(640, work.Height));
            var x = Math.Clamp(settings.WindowX, work.X, Math.Max(work.X, work.X + work.Width - 320));
            var y = Math.Clamp(settings.WindowY, work.Y, Math.Max(work.Y, work.Y + work.Height - 120));
            AppWindow.Move(new Windows.Graphics.PointInt32(x, y));
            AppWindow.Resize(new Windows.Graphics.SizeInt32(width, height));
            if (settings.WindowMax && AppWindow.Presenter is OverlappedPresenter overlapped)
                overlapped.Maximize();
        }

        void RememberWindow()
        {
            var overlapped = AppWindow.Presenter as OverlappedPresenter;
            if (overlapped != null && overlapped.State == OverlappedPresenterState.Minimized)
                return;
            var maximized = overlapped != null && overlapped.State == OverlappedPresenterState.Maximized;
            var position = AppWindow.Position;
            var size = AppWindow.Size;
            var width = maximized ? Math.Max(_session.Settings.WindowW, 1280) : size.Width;
            var height = maximized ? Math.Max(_session.Settings.WindowH, 800) : size.Height;
            _session.RememberWindow(position.X, position.Y, width, height, maximized);
        }

        void LoadColumnWidths()
        {
            var settings = _session.Settings;
            if (settings.ColTitle >= 80) _columns.TitleWidth = settings.ColTitle;
            if (settings.ColArtist >= 80) _columns.ArtistWidth = settings.ColArtist;
            if (settings.ColAlbum >= 80) _columns.AlbumWidth = settings.ColAlbum;
            if (settings.ColLength >= 64) _columns.LengthWidth = settings.ColLength;
            if (settings.ColStars >= 96) _columns.StarsWidth = settings.ColStars;
        }

        void Column_Drag(object sender, Microsoft.UI.Xaml.Controls.Primitives.DragDeltaEventArgs e)
        {
            if (sender is not Thumb { Tag: string key }) return;
            var width = key switch
            {
                "title" => _columns.TitleWidth,
                "artist" => _columns.ArtistWidth,
                "album" => _columns.AlbumWidth,
                "length" => _columns.LengthWidth,
                _ => _columns.StarsWidth
            };
            var min = key switch
            {
                "length" => 64,
                "stars" => 96,
                _ => 80
            };
            width = Math.Clamp(width + e.HorizontalChange, min, 900);
            switch (key)
            {
                case "title": _columns.TitleWidth = width; break;
                case "artist": _columns.ArtistWidth = width; break;
                case "album": _columns.AlbumWidth = width; break;
                case "length": _columns.LengthWidth = width; break;
                default: _columns.StarsWidth = width; break;
            }
        }

        void Column_Save(object sender, Microsoft.UI.Xaml.Controls.Primitives.DragCompletedEventArgs e)
        {
            _session.Settings.ColTitle = _columns.TitleWidth;
            _session.Settings.ColArtist = _columns.ArtistWidth;
            _session.Settings.ColAlbum = _columns.AlbumWidth;
            _session.Settings.ColLength = _columns.LengthWidth;
            _session.Settings.ColStars = _columns.StarsWidth;
            _session.SaveSettings();
        }

        void Loop_Click(object sender, RoutedEventArgs e) => _session.ArmLoop();

        void UpdateStats()
        {
            double seconds = 0;
            foreach (var track in _session.Playlist)
            {
                if (track.DurationSeconds > 0)
                    seconds += track.DurationSeconds;
            }
            var time = TimeSpan.FromSeconds(seconds);
            var clock = time.Hours > 0 ? time.ToString(@"h\:mm\:ss") : time.ToString(@"mm\:ss");
            PlaylistStats.Text = _session.Playlist.Count + " Titel · " + clock;
        }

        void Stop_Click(object sender, RoutedEventArgs e) => _session.Stop();
        void Next_Click(object sender, RoutedEventArgs e) => _session.Next(true);
        void Previous_Click(object sender, RoutedEventArgs e) => _session.Previous();
        void Shuffle_Click(object sender, RoutedEventArgs e) => _session.ToggleShuffle();
        void Repeat_Click(object sender, RoutedEventArgs e) => _session.CycleRepeat();

        Track? _menuTrack;

        void Window_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (Microsoft.UI.Xaml.Input.FocusManager.GetFocusedElement(Content.XamlRoot) is TextBox)
                return;
            var control = Microsoft.UI.Input.InputKeyboardSource.GetKeyStateForCurrentThread(Windows.System.VirtualKey.Control);
            if (e.Key == Windows.System.VirtualKey.Z && control.HasFlag(Windows.UI.Core.CoreVirtualKeyStates.Down))
            {
                Undo_Click(this, e);
                e.Handled = true;
                return;
            }
            if (e.Key == Windows.System.VirtualKey.Space)
            {
                _session.PlayPause();
                e.Handled = true;
                return;
            }
            if (e.Key == Windows.System.VirtualKey.Left || e.Key == Windows.System.VirtualKey.Right)
            {
                var step = e.Key == Windows.System.VirtualKey.Right ? 5 : -5;
                var duration = _session.Engine.DurationSeconds;
                var next = Math.Clamp(_session.Engine.PositionSeconds + step, 0, duration > 0 ? duration : 0);
                _session.Seek(next);
                e.Handled = true;
                return;
            }
            if (e.Key == Windows.System.VirtualKey.Up || e.Key == Windows.System.VirtualKey.Down)
            {
                var step = e.Key == Windows.System.VirtualKey.Up ? 0.05 : -0.05;
                var volume = Math.Clamp(_session.Settings.Volume + step, 0, 1);
                VolumeSlider.Value = volume * 100;
                _session.SetVolume((float)volume);
                _session.SaveSettings();
                e.Handled = true;
                return;
            }
            var stars = e.Key switch
            {
                Windows.System.VirtualKey.Number0 or Windows.System.VirtualKey.NumberPad0 => 0,
                Windows.System.VirtualKey.Number1 or Windows.System.VirtualKey.NumberPad1 => 1,
                Windows.System.VirtualKey.Number2 or Windows.System.VirtualKey.NumberPad2 => 2,
                Windows.System.VirtualKey.Number3 or Windows.System.VirtualKey.NumberPad3 => 3,
                Windows.System.VirtualKey.Number4 or Windows.System.VirtualKey.NumberPad4 => 4,
                Windows.System.VirtualKey.Number5 or Windows.System.VirtualKey.NumberPad5 => 5,
                _ => -1
            };
            if (stars >= 0)
            {
                var picked = PlaylistView.SelectedItem as Track ?? _session.Current;
                if (picked != null)
                {
                    _session.SetRating(picked, stars);
                    StatusText.Text = stars == 0 ? "Bewertung gelöscht" : "Bewertung " + picked.RatingText;
                }
                e.Handled = true;
            }
        }

        bool _filterPosted;
        bool _tabMove;

        void ScheduleFilter()
        {
            if (_reordering || _filterPosted)
                return;
            _filterPosted = true;
            DispatcherQueue.GetForCurrentThread().TryEnqueue(() =>
            {
                _filterPosted = false;
                ApplyFilter();
                if (LibraryPanel.Visibility == Visibility.Visible)
                    FillLibrary();
            });
        }

        void OnPlaylistChanged(object? sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (!_reordering)
                ScheduleFilter();
        }

        void Playlist_DragStarting(object sender, DragItemsStartingEventArgs e)
        {
            var paths = new List<string>();
            foreach (var item in e.Items)
            {
                if (item is Track track && track.Path.Length > 0)
                    paths.Add(track.Path);
            }
            e.Data.SetText(string.Join("\n", paths));
            e.Data.RequestedOperation = Windows.ApplicationModel.DataTransfer.DataPackageOperation.Move;
        }

        void Tab_DragOver(object sender, DragEventArgs e)
        {
            if (sender is not Button { Tag: string name } || name == _activeList)
                return;
            e.AcceptedOperation = Windows.ApplicationModel.DataTransfer.DataPackageOperation.Move;
            e.DragUIOverride.Caption = "Nach " + name;
            e.Handled = true;
        }

        async void Tab_Drop(object sender, DragEventArgs e)
        {
            if (sender is not Button { Tag: string name } || name == _activeList)
                return;
            if (!e.DataView.Contains(Windows.ApplicationModel.DataTransfer.StandardDataFormats.Text))
                return;
            var text = await e.DataView.GetTextAsync();
            var wanted = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var line in text.Split('\n', StringSplitOptions.RemoveEmptyEntries))
                wanted.Add(line.Trim());
            var tracks = new List<Track>();
            foreach (var track in _session.Playlist)
            {
                if (wanted.Contains(track.Path))
                    tracks.Add(track);
            }
            if (tracks.Count == 0)
                return;
            AppendToList(name, tracks);
            _tabMove = true;
            _session.RemoveMany(tracks);
            StatusText.Text = tracks.Count + " Titel nach " + name + " gezogen";
            e.Handled = true;
        }

        void Playlist_Reordered(ListViewBase sender, DragItemsCompletedEventArgs args)
        {
            if (_tabMove)
            {
                _tabMove = false;
                return;
            }
            if (FilterBox.Text.Trim().Length > 0 || _sort.Length > 0)
            {
                StatusText.Text = "Suche oder Sortierung zuerst aufheben";
                ApplyFilter();
                return;
            }
            var order = new List<Track>();
            foreach (var item in PlaylistView.Items)
            {
                if (item is Track track)
                    order.Add(track);
            }
            _reordering = true;
            _session.Reorder(order);
            _reordering = false;
        }

        void Root_DragOver(object sender, DragEventArgs e)
        {
            e.AcceptedOperation = Windows.ApplicationModel.DataTransfer.DataPackageOperation.Copy;
            e.Handled = true;
        }

        async void Root_Drop(object sender, DragEventArgs e)
        {
            if (!e.DataView.Contains(Windows.ApplicationModel.DataTransfer.StandardDataFormats.StorageItems))
                return;
            var items = await e.DataView.GetStorageItemsAsync();
            var paths = new List<string>();
            foreach (var item in items)
            {
                if (item is Windows.Storage.StorageFile file && IsAudio(file.Path))
                    paths.Add(file.Path);
                else if (item is Windows.Storage.StorageFolder folder)
                {
                    try { paths.AddRange(Library.ListFolder(folder.Path)); }
                    catch { }
                }
            }
            if (paths.Count > 0)
                _session.AddPaths(paths);
        }

        static bool IsAudio(string path)
        {
            var ext = Path.GetExtension(path);
            foreach (var known in Library.AudioExtensions)
            {
                if (ext.Equals(known, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        void PlaylistMenu_Opening(object sender, object e)
        {
            FillListMenu(CopyMenu, CopyToList_Click);
            FillListMenu(MoveMenu, MoveToList_Click);
        }

        void FillListMenu(MenuFlyoutSubItem menu, RoutedEventHandler handler)
        {
            menu.Items.Clear();
            foreach (var name in _listNames)
            {
                if (name == _activeList)
                    continue;
                var item = new MenuFlyoutItem { Text = name, Tag = name };
                item.Click += handler;
                menu.Items.Add(item);
            }
            if (menu.Items.Count == 0)
                menu.Items.Add(new MenuFlyoutItem { Text = "Keine weitere Playlist", IsEnabled = false });
        }

        List<Track> ChosenTracks()
        {
            var tracks = new List<Track>();
            if (_menuTrack != null && !PlaylistView.SelectedItems.Contains(_menuTrack))
                tracks.Add(_menuTrack);
            else
            {
                foreach (var item in PlaylistView.SelectedItems)
                {
                    if (item is Track track)
                        tracks.Add(track);
                }
                if (tracks.Count == 0 && _menuTrack != null)
                    tracks.Add(_menuTrack);
            }
            return tracks;
        }

        int AppendToList(string name, IReadOnlyList<Track> tracks)
        {
            var file = Path.Combine(ListsDir, SafeListName(name) + ".m3u8");
            var existing = File.Exists(file) ? Library.LoadPlaylist(file) : new List<string>();
            var added = 0;
            var builder = new System.Text.StringBuilder();
            if (!File.Exists(file))
                builder.AppendLine("#EXTM3U");
            foreach (var track in tracks)
            {
                if (existing.Contains(track.Path))
                    continue;
                var seconds = track.DurationSeconds > 0 ? ((int)track.DurationSeconds).ToString() : "-1";
                builder.Append("#EXTINF:").Append(seconds).Append(',').AppendLine(track.Display);
                builder.AppendLine(track.Path);
                added++;
            }
            if (added == 0)
                return 0;
            if (File.Exists(file))
                File.AppendAllText(file, builder.ToString());
            else
                File.WriteAllText(file, builder.ToString());
            return added;
        }

        void CopyToList_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not MenuFlyoutItem { Tag: string name })
                return;
            var tracks = ChosenTracks();
            if (tracks.Count == 0)
                return;
            var added = AppendToList(name, tracks);
            StatusText.Text = added == 0 ? "Schon in " + name : added + " Titel nach " + name + " kopiert";
        }

        void MoveToList_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not MenuFlyoutItem { Tag: string name })
                return;
            var tracks = ChosenTracks();
            if (tracks.Count == 0)
                return;
            AppendToList(name, tracks);
            _session.RemoveMany(tracks);
            StatusText.Text = tracks.Count + " Titel nach " + name + " verschoben";
        }

        async void Duplicates_Click(object sender, RoutedEventArgs e)
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var dupes = new List<Track>();
            foreach (var track in _session.Playlist)
            {
                if (!seen.Add(track.Path))
                    dupes.Add(track);
            }
            if (dupes.Count == 0)
            {
                StatusText.Text = "Keine doppelten Titel";
                return;
            }
            var dialog = new ContentDialog
            {
                Title = "Doppelte Titel",
                Content = dupes.Count + " Wiederholungen gefunden. Die ersten Einträge bleiben.",
                PrimaryButtonText = "Entfernen",
                CloseButtonText = "Nur anzeigen",
                XamlRoot = Content.XamlRoot
            };
            var result = await dialog.ShowAsync();
            if (result != ContentDialogResult.Primary)
            {
                StatusText.Text = dupes.Count + " doppelte Titel gefunden";
                return;
            }
            _session.RemoveMany(dupes);
            StatusText.Text = dupes.Count + " doppelte Titel entfernt";
        }

        void Playlist_RightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            _menuTrack = TrackUnder(e.OriginalSource as DependencyObject);
        }

        void ContextPlay_Click(object sender, RoutedEventArgs e)
        {
            var track = _menuTrack ?? PlaylistView.SelectedItem as Track;
            if (track != null)
                PlayHere(track);
        }

        void ContextEnqueue_Click(object sender, RoutedEventArgs e)
        {
            var track = _menuTrack ?? PlaylistView.SelectedItem as Track;
            if (track != null)
                _session.Enqueue(track);
        }

        void ContextNext_Click(object sender, RoutedEventArgs e)
        {
            var tracks = MenuTracks();
            if (tracks.Count > 0)
                _session.PlayNext(tracks);
        }

        void ContextCopyTitle_Click(object sender, RoutedEventArgs e) => CopyText(TitleLine());

        void ContextCopyPath_Click(object sender, RoutedEventArgs e) => CopyText(PathLine());

        List<Track> MenuTracks()
        {
            var tracks = new List<Track>();
            if (_menuTrack != null && PlaylistView.SelectedItems.Contains(_menuTrack))
            {
                foreach (var item in PlaylistView.SelectedItems)
                {
                    if (item is Track track)
                        tracks.Add(track);
                }
            }
            else if (_menuTrack != null)
                tracks.Add(_menuTrack);
            else if (PlaylistView.SelectedItem is Track selected)
                tracks.Add(selected);
            return tracks;
        }

        string TitleLine()
        {
            var lines = new List<string>();
            foreach (var track in MenuTracks())
                lines.Add(track.Display);
            return string.Join(Environment.NewLine, lines);
        }

        string PathLine()
        {
            var lines = new List<string>();
            foreach (var track in MenuTracks())
                lines.Add(track.Path);
            return string.Join(Environment.NewLine, lines);
        }

        void CopyText(string text)
        {
            if (text.Length == 0) return;
            var package = new Windows.ApplicationModel.DataTransfer.DataPackage();
            package.SetText(text);
            Windows.ApplicationModel.DataTransfer.Clipboard.SetContent(package);
            StatusText.Text = "Kopiert";
        }

        void Undo_Click(object sender, RoutedEventArgs e)
        {
            if (!_session.UndoRemove())
                StatusText.Text = "Nichts zum Rückgängigmachen";
        }

        void ContextRemove_Click(object sender, RoutedEventArgs e)
        {
            if (_menuTrack == null)
            {
                RemoveSelected();
                return;
            }
            if (!PlaylistView.SelectedItems.Contains(_menuTrack))
                _session.RemoveMany(new[] { _menuTrack });
            else
                RemoveSelected();
        }

        void ContextExplorer_Click(object sender, RoutedEventArgs e)
        {
            var track = _menuTrack ?? PlaylistView.SelectedItem as Track;
            if (track == null || !File.Exists(track.Path))
                return;
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "explorer.exe",
                Arguments = "/select,\"" + track.Path + "\"",
                UseShellExecute = true
            });
        }

        readonly List<HistoryItem> _history = new();

        void LoadHistory()
        {
            try
            {
                var items = Library.ReadJson<List<HistoryItem>>(Path.Combine(Library.DataDir, "history.json"));
                if (items != null)
                    _history.AddRange(items);
            }
            catch { }
            HistoryView.ItemsSource = _history;
        }

        void Remember(Track track)
        {
            if (_history.Count > 0 && string.Equals(_history[0].Path, track.Path, StringComparison.OrdinalIgnoreCase))
                return;
            _history.Insert(0, new HistoryItem { Path = track.Path, Label = track.Display });
            while (_history.Count > 80)
                _history.RemoveAt(_history.Count - 1);
            HistoryView.ItemsSource = null;
            HistoryView.ItemsSource = _history;
            try
            {
                Directory.CreateDirectory(Library.DataDir);
                var json = System.Text.Json.JsonSerializer.Serialize(_history);
                Library.WriteSafe(Path.Combine(Library.DataDir, "history.json"), json);
            }
            catch { }
        }

        void RemoveOffline_Click(object sender, RoutedEventArgs e)
        {
            var gone = new List<Track>();
            foreach (var track in _session.Playlist)
            {
                if (track.IsOffline)
                    gone.Add(track);
            }
            if (gone.Count == 0)
            {
                StatusText.Text = "Keine Offline-Titel in dieser Playlist";
                return;
            }
            _session.RemoveMany(gone);
            StatusText.Text = gone.Count + " Offline-Titel entfernt";
        }

        void Jump_Click(object sender, RoutedEventArgs e)
        {
            var track = _session.Current;
            if (track == null || !_session.Playlist.Contains(track))
            {
                StatusText.Text = "Der laufende Titel steht nicht in dieser Playlist";
                return;
            }
            PlaylistView.SelectedItem = track;
            PlaylistView.ScrollIntoView(track);
        }

        string _folder = "";
        int _folderToken;
        bool _folderBusy;
        readonly List<string> _folderBack = new();
        List<FolderEntry> _folderRows = new();

        async Task ShowFolder(string path, bool remember = true)
        {
            path = path.Trim().Trim('"');
            if (path.Length == 0 || Strings.Is("thisPc", path))
            {
                ShowDrives();
                return;
            }
            var token = ++_folderToken;
            StatusText.Text = "Ordner wird gelesen…";
            List<FolderEntry>? rows;
            try
            {
                rows = await Task.Run(() => Directory.Exists(path) ? ReadFolder(path) : null);
            }
            catch (Exception ex)
            {
                if (token != _folderToken) return;
                StatusText.Text = "Ordner nicht lesbar: " + ex.Message;
                return;
            }
            if (token != _folderToken) return;
            if (rows == null)
            {
                StatusText.Text = "Ordner nicht gefunden";
                return;
            }
            if (remember && _folder.Length > 0 && !string.Equals(_folder, path, StringComparison.OrdinalIgnoreCase))
                _folderBack.Add(_folder);
            _folder = path;
            _session.Settings.BrowserFolder = path;
            _session.SaveSettings();
            _folderBusy = true;
            FolderPathBox.Text = path;
            FolderFindBox.Text = "";
            _folderBusy = false;
            _folderRows = rows;
            FolderView.ItemsSource = rows;
            StatusText.Text = rows.Count + " Einträge";
        }

        void ShowDrives()
        {
            var rows = new List<FolderEntry>();
            foreach (var drive in DriveInfo.GetDrives())
            {
                try
                {
                    if (drive.DriveType == DriveType.Network)
                    {
                        rows.Add(new FolderEntry("Netzlaufwerk   " + drive.Name.TrimEnd('\\'), drive.Name, true));
                        continue;
                    }
                    if (drive.DriveType != DriveType.Fixed && drive.DriveType != DriveType.Removable)
                        continue;
                    if (!drive.IsReady) continue;
                    var label = "";
                    try { label = drive.VolumeLabel; } catch { }
                    var name = string.IsNullOrWhiteSpace(label) ? drive.Name.TrimEnd('\\') : label + "   " + drive.Name.TrimEnd('\\');
                    rows.Add(new FolderEntry(name, drive.Name, true));
                }
                catch { }
            }
            _folder = "";
            _folderBusy = true;
            FolderPathBox.Text = Strings.T("thisPc");
            FolderFindBox.Text = "";
            _folderBusy = false;
            _folderRows = rows;
            FolderView.ItemsSource = rows;
            StatusText.Text = rows.Count + " " + Strings.T("drivesHint");
        }

        static List<FolderEntry> ReadFolder(string path)
        {
            var rows = new List<FolderEntry>();
            var options = new EnumerationOptions
            {
                IgnoreInaccessible = true,
                AttributesToSkip = FileAttributes.ReparsePoint
            };
            foreach (var dir in Directory.EnumerateDirectories(path, "*", options))
                rows.Add(new FolderEntry(Path.GetFileName(dir), dir, true));
            rows.Sort((a, b) => string.Compare(a.Label, b.Label, StringComparison.OrdinalIgnoreCase));
            var files = new List<FolderEntry>();
            foreach (var file in Directory.EnumerateFiles(path, "*", options))
            {
                var ext = Path.GetExtension(file);
                foreach (var known in Library.AudioExtensions)
                {
                    if (!ext.Equals(known, StringComparison.OrdinalIgnoreCase))
                        continue;
                    files.Add(new FolderEntry(Path.GetFileName(file), file, false));
                    break;
                }
            }
            files.Sort((a, b) => string.Compare(a.Label, b.Label, StringComparison.OrdinalIgnoreCase));
            rows.AddRange(files);
            return rows;
        }

        async void FolderRoot_Click(object sender, RoutedEventArgs e)
        {
            var picker = new FolderPicker();
            InitializeWithWindow.Initialize(picker, Hwnd);
            picker.FileTypeFilter.Add("*");
            var folder = await picker.PickSingleFolderAsync();
            if (folder != null)
                await ShowFolder(folder.Path);
        }

        async void FolderUp_Click(object sender, RoutedEventArgs e)
        {
            if (_folder.Length == 0)
            {
                ShowDrives();
                return;
            }
            var parent = Directory.GetParent(_folder);
            if (parent == null)
            {
                ShowDrives();
                return;
            }
            await ShowFolder(parent.FullName);
        }

        async void FolderBack_Click(object sender, RoutedEventArgs e)
        {
            if (_folderBack.Count == 0)
            {
                StatusText.Text = "Kein vorheriger Ordner";
                return;
            }
            var previous = _folderBack[^1];
            _folderBack.RemoveAt(_folderBack.Count - 1);
            await ShowFolder(previous, false);
        }

        async void FolderPath_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (e.Key != Windows.System.VirtualKey.Enter) return;
            e.Handled = true;
            await ShowFolder(FolderPathBox.Text.Trim());
        }

        void FolderFind_Changed(object sender, TextChangedEventArgs e)
        {
            if (_folderBusy) return;
            var query = FolderFindBox.Text.Trim();
            if (query.Length == 0)
            {
                FolderView.ItemsSource = _folderRows;
                return;
            }
            FolderView.ItemsSource = _folderRows.Where(row =>
                row.Label.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        async void FolderFind_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (e.Key != Windows.System.VirtualKey.Enter) return;
            e.Handled = true;
            var query = FolderFindBox.Text.Trim();
            if (query.Length == 0 || _folder.Length == 0) return;
            var root = Path.GetPathRoot(_folder);
            if (root != null && string.Equals(Path.TrimEndingDirectorySeparator(_folder), Path.TrimEndingDirectorySeparator(root), StringComparison.OrdinalIgnoreCase))
            {
                StatusText.Text = "Bitte einen Ordner öffnen, nicht das ganze Laufwerk";
                return;
            }
            var token = ++_folderToken;
            StatusText.Text = "Suche läuft…";
            List<FolderEntry> rows;
            try
            {
                rows = await Task.Run(() => SearchFolder(_folder, query, 200));
            }
            catch (Exception ex)
            {
                if (token != _folderToken) return;
                StatusText.Text = "Suche fehlgeschlagen: " + ex.Message;
                return;
            }
            if (token != _folderToken) return;
            FolderView.ItemsSource = rows;
            StatusText.Text = rows.Count + " Treffer";
        }

        async void FolderAdd_Click(object sender, RoutedEventArgs e)
        {
            if (_folder.Length == 0) return;
            await _session.AddFolderAsync(_folder);
            StatusText.Text = _session.Status;
        }

        async void Folder_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            if (FolderView.SelectedItem is not FolderEntry entry) return;
            if (entry.IsDir)
            {
                await ShowFolder(entry.Path);
                return;
            }
            var track = _session.Find(entry.Path);
            if (track == null || !_session.Playlist.Contains(track))
            {
                _session.AddPaths(new[] { entry.Path });
                track = _session.Find(entry.Path);
            }
            if (track != null)
                PlayHere(track);
        }

        sealed class FolderEntry
        {
            public FolderEntry(string label, string path, bool isDir)
            {
                Label = label;
                Path = path;
                IsDir = isDir;
            }

            public string Label { get; }
            public string Path { get; }
            public bool IsDir { get; }
            public string Glyph => IsDir ? "\uE8B7" : "\uE189";
        }

        static List<FolderEntry> SearchFolder(string root, string query, int limit)
        {
            var rows = new List<FolderEntry>();
            var pending = new Stack<string>();
            pending.Push(root);
            var seen = 0;
            while (pending.Count > 0 && rows.Count < limit && seen < 4000)
            {
                var dir = pending.Pop();
                seen++;
                try
                {
                    foreach (var sub in Directory.EnumerateDirectories(dir))
                    {
                        if (Path.GetFileName(sub).Contains(query, StringComparison.OrdinalIgnoreCase))
                            rows.Add(new FolderEntry(Path.GetRelativePath(root, sub), sub, true));
                        pending.Push(sub);
                        if (rows.Count >= limit) return rows;
                    }
                }
                catch { }
                try
                {
                    foreach (var file in Directory.EnumerateFiles(dir))
                    {
                        var ext = Path.GetExtension(file);
                        var audio = false;
                        foreach (var known in Library.AudioExtensions)
                        {
                            if (ext.Equals(known, StringComparison.OrdinalIgnoreCase))
                            {
                                audio = true;
                                break;
                            }
                        }
                        if (!audio) continue;
                        if (!Path.GetFileName(file).Contains(query, StringComparison.OrdinalIgnoreCase)) continue;
                        rows.Add(new FolderEntry(Path.GetRelativePath(root, file), file, false));
                        if (rows.Count >= limit) return rows;
                    }
                }
                catch { }
            }
            return rows;
        }

        void SearchAll_Changed(object sender, TextChangedEventArgs e) => FillSearch();

        void FillSearch()
        {
            var query = SearchAllBox.Text.Trim();
            var hits = new List<SearchHit>();
            if (query.Length == 0)
            {
                SearchView.ItemsSource = hits;
                return;
            }
            void Add(string list, string path, string label)
            {
                if (hits.Count >= 80) return;
                if (!label.Contains(query, StringComparison.OrdinalIgnoreCase)
                    && !path.Contains(query, StringComparison.OrdinalIgnoreCase))
                    return;
                hits.Add(new SearchHit(list, path, list + "  ·  " + label));
            }
            foreach (var track in _session.Playlist)
                Add(_activeList, track.Path, track.Display);
            if (Directory.Exists(ListsDir))
            {
                foreach (var file in Directory.GetFiles(ListsDir, "*.m3u8"))
                {
                    var name = Path.GetFileNameWithoutExtension(file);
                    if (string.Equals(name, SafeListName(_activeList), StringComparison.OrdinalIgnoreCase))
                        continue;
                    foreach (var path in Library.LoadPlaylist(file))
                        Add(name, path, Path.GetFileNameWithoutExtension(path));
                }
            }
            SearchView.ItemsSource = hits;
            StatusText.Text = hits.Count + " Treffer";
        }

        void Search_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            if (SearchView.SelectedItem is not SearchHit hit) return;
            var list = hit.List;
            foreach (var name in _listNames)
            {
                if (string.Equals(SafeListName(name), list, StringComparison.OrdinalIgnoreCase) || string.Equals(name, list, StringComparison.OrdinalIgnoreCase))
                {
                    list = name;
                    break;
                }
            }
            if (!string.Equals(list, _activeList, StringComparison.OrdinalIgnoreCase) && _listNames.Contains(list))
                OpenList(list);
            var track = _session.Find(hit.Path);
            if (track == null)
            {
                _session.AddPaths(new[] { hit.Path });
                track = _session.Find(hit.Path);
            }
            if (track != null)
                PlayHere(track);
        }

        sealed class SearchHit
        {
            public SearchHit(string list, string path, string display)
            {
                List = list;
                Path = path;
                Display = display;
            }

            public string List { get; }
            public string Path { get; }
            public string Display { get; }
        }

        void History_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            if (HistoryView.SelectedItem is not HistoryItem item)
                return;
            Track? track = null;
            foreach (var entry in _session.Playlist)
            {
                if (string.Equals(entry.Path, item.Path, StringComparison.OrdinalIgnoreCase))
                {
                    track = entry;
                    break;
                }
            }
            track ??= new Track(item.Path);
            if (!File.Exists(track.Path))
            {
                StatusText.Text = "Offline: " + item.Label;
                return;
            }
            if (!_session.Playlist.Contains(track))
                _session.Playlist.Add(track);
            PlayHere(track);
        }

        string? _side;

        void ShowSide_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button { Tag: string key })
                return;
            if (_side == key)
            {
                CloseSide();
                return;
            }
            ShowSide(key);
        }

        void ShowSide(string key)
        {
            _side = key;
            SidePanel.Visibility = Visibility.Visible;
            SideTitle.Text = Strings.T(key switch
            {
                "queue" => "queue",
                "marks" => "marks",
                "eq" => "eq",
                "library" => "library",
                "history" => "history",
                "search" => "search",
                "radio" => "radio",
                "lyrics" => "lyrics",
                "folders" => "folders",
                "lists" => "lists",
                _ => "settings"
            });
            QueuePanel.Visibility = key == "queue" ? Visibility.Visible : Visibility.Collapsed;
            BookmarkView.Visibility = key == "marks" ? Visibility.Visible : Visibility.Collapsed;
            EqWrap.Visibility = key == "eq" ? Visibility.Visible : Visibility.Collapsed;
            LibraryPanel.Visibility = key == "library" ? Visibility.Visible : Visibility.Collapsed;
            HistoryView.Visibility = key == "history" ? Visibility.Visible : Visibility.Collapsed;
            SearchPanel.Visibility = key == "search" ? Visibility.Visible : Visibility.Collapsed;
            RadioPanel.Visibility = key == "radio" ? Visibility.Visible : Visibility.Collapsed;
            LyricsPanel.Visibility = key == "lyrics" ? Visibility.Visible : Visibility.Collapsed;
            ListsPanel.Visibility = key == "lists" ? Visibility.Visible : Visibility.Collapsed;
            FolderPanel.Visibility = key == "folders" ? Visibility.Visible : Visibility.Collapsed;
            SettingsPanel.Visibility = key == "settings" ? Visibility.Visible : Visibility.Collapsed;
            MarkNav(key);
            if (key == "library")
                FillLibrary();
            if (key == "radio")
                EnsureRadio();
            if (key == "folders" && _folder.Length == 0)
                ShowDrives();
        }

        void CloseSide_Click(object sender, RoutedEventArgs e) => CloseSide();

        void CloseSide()
        {
            _side = null;
            SidePanel.Visibility = Visibility.Collapsed;
            MarkNav("playlist");
        }

        bool _navOpen = true;

        void NavToggle_Click(object sender, RoutedEventArgs e)
        {
            _navOpen = !_navOpen;
            var target = _navOpen ? 176d : 56d;
            var anim = new Microsoft.UI.Xaml.Media.Animation.DoubleAnimation
            {
                From = NavShell.ActualWidth,
                To = target,
                Duration = new Duration(TimeSpan.FromMilliseconds(180)),
                EnableDependentAnimation = true,
                EasingFunction = new Microsoft.UI.Xaml.Media.Animation.CubicEase
                {
                    EasingMode = Microsoft.UI.Xaml.Media.Animation.EasingMode.EaseOut
                }
            };
            Microsoft.UI.Xaml.Media.Animation.Storyboard.SetTarget(anim, NavShell);
            Microsoft.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(anim, "Width");
            var board = new Microsoft.UI.Xaml.Media.Animation.Storyboard();
            board.Children.Add(anim);
            board.Completed += (_, _) => NavShell.Width = target;
            board.Begin();
        }

        void Nav_Click(object sender, RoutedEventArgs e) => CloseSide();

        void MarkNav(string key)
        {
            foreach (var child in NavPanel.Children)
            {
                if (child is not Grid grid) continue;
                var on = (grid.Tag as string) == key;
                if (grid.Children.Count > 0 && grid.Children[0] is Border bar)
                    bar.Opacity = on ? 1 : 0;
                if (grid.Children.Count > 1 && grid.Children[1] is Button button)
                    button.FontWeight = Microsoft.UI.Text.FontWeights.Normal;
            }
        }

        void ToggleLyrics_Click(object sender, RoutedEventArgs e)
        {
            if (_side == "lyrics")
            {
                CloseSide();
                return;
            }
            ShowSide("lyrics");
            if (_lyrics.Count == 0 && _session.Current != null)
                _ = LoadLyricsAsync(_session.Current, false);
        }

        void Playlist_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            var fromRow = TrackUnder(e.OriginalSource as DependencyObject);
            var fromHit = TrackAt(e.GetPosition(Content));
            var track = fromRow;
            if (fromHit != null && !ReferenceEquals(fromHit, _session.Current))
                track = fromHit;
            if (fromRow != null && !ReferenceEquals(fromRow, _session.Current))
                track = fromRow;
            track ??= fromHit ?? fromRow;
            if (track == null)
                return;
            e.Handled = true;
            PlayHere(track);
        }

        Track? TrackUnder(DependencyObject? node)
        {
            while (node != null && node != PlaylistView)
            {
                if (node is FrameworkElement { DataContext: Track track })
                    return track;
                node = VisualTreeHelper.GetParent(node);
            }
            return null;
        }

        Track? TrackAt(Windows.Foundation.Point point)
        {
            if (Content is not UIElement root)
                return null;
            foreach (var hit in VisualTreeHelper.FindElementsInHostCoordinates(point, root))
            {
                if (hit is FrameworkElement { DataContext: Track track })
                    return track;
            }
            return null;
        }

        void Enqueue_Click(object sender, RoutedEventArgs e)
        {
            if (PlaylistView.SelectedItem is Track track)
                _session.Enqueue(track);
        }

        void Remove_Click(object sender, RoutedEventArgs e) => RemoveSelected();

        void Playlist_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (e.Key != Windows.System.VirtualKey.Delete) return;
            RemoveSelected();
            e.Handled = true;
        }

        void RemoveSelected()
        {
            var selected = new List<Track>();
            foreach (var item in PlaylistView.SelectedItems)
            {
                if (item is Track track)
                    selected.Add(track);
            }
            _session.RemoveMany(selected);
        }

        void ClearQueue_Click(object sender, RoutedEventArgs e) => _session.ClearQueue();

        void ClearPlaylist_Click(object sender, RoutedEventArgs e)
        {
            HoldIfLeaving();
            var all = new List<Track>(_session.Playlist);
            _session.RemoveMany(all);
        }

        void Bookmark_Click(object sender, RoutedEventArgs e) => _session.AddBookmark();

        void Bookmark_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            if (BookmarkView.SelectedItem is Bookmark mark)
                _session.PlayBookmark(mark);
        }

        async void Load_Click(object sender, RoutedEventArgs e)
        {
            var picker = new FileOpenPicker();
            InitializeWithWindow.Initialize(picker, Hwnd);
            picker.FileTypeFilter.Add(".m3u");
            picker.FileTypeFilter.Add(".m3u8");
            picker.FileTypeFilter.Add(".pls");
            var file = await picker.PickSingleFileAsync();
            if (file == null) return;
            HoldIfLeaving();
            _session.ReplaceView(Library.LoadPlaylist(file.Path));
            Refresh();
        }

        async void Save_Click(object sender, RoutedEventArgs e)
        {
            var picker = new FileSavePicker();
            InitializeWithWindow.Initialize(picker, Hwnd);
            picker.SuggestedFileName = "playlist";
            picker.FileTypeChoices.Add("M3U", new List<string> { ".m3u8" });
            var file = await picker.PickSaveFileAsync();
            if (file == null) return;
            Library.SaveM3u(file.Path, _session.Playlist);
            StatusText.Text = "Playlist gespeichert";
        }

        readonly List<string> _listNames = new();
        string _activeList = "Playlist 1";
        string _playingList = "";

        string ListsDir => Path.Combine(Library.DataDir, "lists");

        void EnsureLists()
        {
            Directory.CreateDirectory(ListsDir);
            var index = Path.Combine(ListsDir, "index.txt");
            var indexText = Library.ReadTextSafe(index);
            if (indexText.Length > 0)
            {
                foreach (var line in indexText.Split('\n'))
                {
                    var name = line.Trim();
                    if (name.Length > 0 && !_listNames.Contains(name))
                        _listNames.Add(name);
                }
            }
            if (_listNames.Count == 0)
                _listNames.Add("Playlist 1");
            var active = Library.ReadTextSafe(Path.Combine(ListsDir, "active.txt")).Trim();
            if (_listNames.Contains(active))
                _activeList = active;
            else if (_listNames.Count > 0)
                _activeList = _listNames[0];
            SaveActiveList();
            RenderTabs();
        }

        static string SafeListName(string name)
        {
            foreach (var c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }

        void SaveActiveList()
        {
            try
            {
                Directory.CreateDirectory(ListsDir);
                Library.SaveM3u(Path.Combine(ListsDir, SafeListName(_activeList) + ".m3u8"), _session.Playlist);
                Library.WriteSafe(Path.Combine(ListsDir, "index.txt"), string.Join("\n", _listNames));
                Library.WriteSafe(Path.Combine(ListsDir, "active.txt"), _activeList);
            }
            catch { }
        }

        void RenderTabs()
        {
            PlaylistTabs.Children.Clear();
            foreach (var name in _listNames)
            {
                var label = name;
                var open = new Button
                {
                    Content = label == _playingList && label != _activeList ? label + "  ♪" : label,
                    Tag = label,
                    FontWeight = label == _activeList ? Microsoft.UI.Text.FontWeights.SemiBold : Microsoft.UI.Text.FontWeights.Normal
                };
                open.Click += (_, _) => OpenList(label);
                open.AllowDrop = true;
                open.DragOver += Tab_DragOver;
                open.Drop += Tab_Drop;
                open.DoubleTapped += (_, e) =>
                {
                    e.Handled = true;
                    _ = RenameList(label);
                };
                var close = new Button { Content = "×", Tag = label, Padding = new Thickness(8, 4, 8, 4) };
                close.Click += (_, _) => CloseList(label);
                var bar = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 2 };
                bar.Children.Add(open);
                bar.Children.Add(close);
                PlaylistTabs.Children.Add(bar);
            }
            var add = new Button { Content = "+" };
            add.Click += (_, _) => AddList();
            PlaylistTabs.Children.Add(add);
        }

        async Task RenameList(string name)
        {
            var box = new TextBox { Text = name };
            var dialog = new ContentDialog
            {
                Title = "Playlist umbenennen",
                Content = box,
                PrimaryButtonText = "Speichern",
                CloseButtonText = "Abbrechen",
                XamlRoot = Content.XamlRoot
            };
            if (await dialog.ShowAsync() != ContentDialogResult.Primary)
                return;
            var next = box.Text.Trim();
            if (next.Length == 0 || next == name || _listNames.Contains(next))
                return;
            var oldFile = Path.Combine(ListsDir, SafeListName(name) + ".m3u8");
            var newFile = Path.Combine(ListsDir, SafeListName(next) + ".m3u8");
            if (File.Exists(oldFile))
                File.Move(oldFile, newFile, true);
            var index = _listNames.IndexOf(name);
            if (index >= 0)
                _listNames[index] = next;
            if (_activeList == name)
                _activeList = next;
            if (_playingList == name)
                _playingList = next;
            SaveActiveList();
            RenderTabs();
        }

        bool _fillLibrary;
        string _artistFilter = "";
        string _albumFilter = "";

        void FillLibrary()
        {
            var artists = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var track in _session.Playlist)
            {
                if (!string.IsNullOrWhiteSpace(track.Artist))
                    artists.Add(track.Artist);
            }
            var items = new List<string> { "Alle" };
            items.AddRange(artists);
            _fillLibrary = true;
            LibraryView.ItemsSource = items;
            LibraryView.SelectedItem = _artistFilter.Length == 0 ? "Alle" : _artistFilter;
            _fillLibrary = false;
            FillAlbums();
        }

        void FillAlbums()
        {
            var albums = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var track in _session.Playlist)
            {
                if (_artistFilter.Length > 0
                    && !string.Equals(track.Artist, _artistFilter, StringComparison.OrdinalIgnoreCase))
                    continue;
                if (!string.IsNullOrWhiteSpace(track.Album))
                    albums.Add(track.Album);
            }
            var items = new List<string> { "Alle Alben" };
            items.AddRange(albums);
            _fillLibrary = true;
            AlbumView.ItemsSource = items;
            AlbumView.SelectedItem = _albumFilter.Length == 0 ? "Alle Alben" : _albumFilter;
            _fillLibrary = false;
        }

        void Library_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_fillLibrary)
                return;
            var pick = LibraryView.SelectedItem as string ?? "Alle";
            var next = pick == "Alle" ? "" : pick;
            if (!string.Equals(next, _artistFilter, StringComparison.OrdinalIgnoreCase))
                _albumFilter = "";
            _artistFilter = next;
            FillAlbums();
            ApplyFilter();
        }

        void Album_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_fillLibrary)
                return;
            var pick = AlbumView.SelectedItem as string ?? "Alle Alben";
            _albumFilter = pick == "Alle Alben" ? "" : pick;
            ApplyFilter();
        }

        void OpenList(string name)
        {
            if (name == _activeList || !_listNames.Contains(name))
                return;
            var file = Path.Combine(ListsDir, SafeListName(name) + ".m3u8");
            var paths = File.Exists(file) ? Library.LoadPlaylist(file) : new List<string>();
            SwapView(name, paths);
        }

        void AddList()
        {
            var n = 1;
            string name;
            do
            {
                name = "Playlist " + n++;
            }
            while (_listNames.Contains(name));
            SwapView(name, new List<string>());
        }

        void HoldIfLeaving()
        {
            if (_session.Current == null && !_session.Engine.CanResume)
                return;
            if (_playingList.Length == 0)
                _playingList = _activeList;
            if (_activeList == _playingList)
                _session.HoldDeck();
        }

        void SwapView(string name, IReadOnlyList<string> paths)
        {
            if (name != _activeList)
                SaveActiveList();
            var wasHeld = _session.DeckHeld;
            HoldIfLeaving();
            var kept = !wasHeld && _session.DeckHeld;
            if (!_listNames.Contains(name))
                _listNames.Add(name);
            _activeList = name;
            _session.ReplaceView(paths);
            if (!kept && name == _playingList)
            {
                _session.ReleaseDeck();
                _session.RetargetCurrent();
            }
            SaveActiveList();
            RenderTabs();
            Refresh();
        }

        void CloseList(string name)
        {
            if (_listNames.Count < 2 || !_listNames.Contains(name))
                return;
            if (name == _activeList)
            {
                var index = _listNames.IndexOf(name);
                var next = _listNames[index == 0 ? 1 : index - 1];
                OpenList(next);
            }
            _listNames.Remove(name);
            var file = Path.Combine(ListsDir, SafeListName(name) + ".m3u8");
            if (File.Exists(file))
                File.Delete(file);
            SaveActiveList();
            RenderTabs();
        }

        void Filter_Changed(object sender, TextChangedEventArgs e) => ApplyFilter();

        void Output_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_ready || OutputBox.SelectedItem is not string mode) return;
            _session.SetOutput(mode);
        }

        void Theme_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_ready || _skinBusy || _langBusy || ThemeBox.SelectedIndex < 0) return;
            LeaveSkin();
            var theme = ThemeBox.SelectedIndex switch
            {
                1 => "acrylic",
                2 => "light",
                _ => "mica"
            };
            _session.SetTheme(theme);
            ApplyTheme(theme);
            ApplyAccent(_session.Settings.Accent);
        }

        void Accent_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_ready || _skinBusy || _langBusy || AccentBox.SelectedIndex < 0) return;
            LeaveSkin();
            var accent = AccentBox.SelectedIndex switch
            {
                1 => "blue",
                2 => "green",
                3 => "amber",
                4 => "red",
                5 => "lila",
                _ => "cyan"
            };
            _session.SetAccent(accent);
            ApplyTheme(_session.Settings.Theme);
            ApplyAccent(accent);
        }

        void Skin_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_ready || _skinBusy || _langBusy) return;
            var name = SkinBox.SelectedItem as string ?? Strings.T("builtin");
            if (Strings.Is("builtin", name))
            {
                _session.Settings.Skin = "";
                _session.SaveSettings();
                ApplyTheme(_session.Settings.Theme);
                ApplyAccent(_session.Settings.Accent);
                return;
            }
            if (!ApplySkin(name))
            {
                StatusText.Text = "Skin nicht lesbar: " + name;
                return;
            }
            _session.Settings.Skin = name;
            _session.SaveSettings();
        }

        void LeaveSkin()
        {
            if (string.IsNullOrEmpty(_session.Settings.Skin)) return;
            _session.Settings.Skin = "";
            _skinBusy = true;
            SkinBox.SelectedIndex = 0;
            _skinBusy = false;
        }

        void ReplayGain_Toggled(object sender, RoutedEventArgs e)
        {
            if (_ready) _session.SetReplayGain(ReplayGainBox.IsOn);
        }

        void Tray_Toggled(object sender, RoutedEventArgs e)
        {
            if (_ready) _session.SetTray(TrayBox.IsOn);
        }

        void Sleep_Click(object sender, RoutedEventArgs e) => _session.StartSleep(SleepBox.Value);

        void Smart_Click(object sender, RoutedEventArgs e)
        {
            HoldIfLeaving();
            _session.Playlist.Clear();
            _session.LoadSmart();
            Refresh();
        }

        async Task LoadLyricsAsync(Track track, bool forceOnline)
        {
            if (!forceOnline && !string.IsNullOrWhiteSpace(track.Lyrics) && track.Lyrics.Contains('['))
            {
                ShowLyrics(track.Lyrics, "Songtext aus der Datei");
                return;
            }
            StatusText.Text = "Songtext wird bei lrclib.net gesucht…";
            var text = await Library.FetchLyricsAsync(track);
            if (!ReferenceEquals(_session.Current, track))
                return;
            if (string.IsNullOrWhiteSpace(text))
            {
                LyricsBoxShow(track.Lyrics ?? "");
                StatusText.Text = string.IsNullOrWhiteSpace(track.Lyrics)
                    ? "Kein Songtext: weder in der Datei noch bei lrclib.net"
                    : "Songtext aus der Datei, online nichts Neues";
                if (!string.IsNullOrWhiteSpace(track.Lyrics))
                    ShowLyrics(track.Lyrics, StatusText.Text);
                return;
            }
            track.SetLyrics(text);
            ShowLyrics(text, "Songtext von lrclib.net");
        }

        void ShowLyrics(string text, string status)
        {
            LyricsBoxShow(text);
            StatusText.Text = status;
        }

        void LyricsBoxShow(string text)
        {
            if (text == _lyricSource)
                return;
            _lyricSource = text;
            _lyrics.Clear();
            _lyricIndex = -1;
            foreach (var line in SplitLyrics(text))
                _lyrics.Add(line);
        }

        static List<LyricLine> SplitLyrics(string text)
        {
            var lines = new List<LyricLine>();
            var synced = false;
            foreach (var raw in text.Replace("\r", "").Split('\n'))
            {
                var rest = raw;
                double? stamp = null;
                while (rest.Length > 3 && rest[0] == '[')
                {
                    var end = rest.IndexOf(']');
                    if (end <= 1 || !TryStamp(rest[1..end], out var seconds))
                        break;
                    stamp = seconds;
                    rest = rest[(end + 1)..];
                    synced = true;
                }
                lines.Add(new LyricLine(stamp ?? -1, rest.Trim()));
            }
            if (!synced)
            {
                for (var i = 0; i < lines.Count; i++)
                    lines[i] = new LyricLine(-1, lines[i].Text.Trim());
            }
            return lines;
        }

        static bool TryStamp(string value, out double seconds)
        {
            seconds = 0;
            var parts = value.Split(':');
            if (parts.Length < 2 || !int.TryParse(parts[0], out var minutes))
                return false;
            var clock = parts[1].Replace(',', '.');
            if (!double.TryParse(clock, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var secs))
                return false;
            seconds = minutes * 60 + secs;
            return true;
        }

        void FollowLyrics()
        {
            if (_side != "lyrics" || _lyrics.Count == 0)
                return;
            var position = _session.Engine.PositionSeconds;
            var index = -1;
            for (var i = 0; i < _lyrics.Count; i++)
            {
                if (_lyrics[i].Seconds < 0)
                    continue;
                if (_lyrics[i].Seconds <= position + 0.2)
                    index = i;
                else
                    break;
            }
            if (index < 0 || index == _lyricIndex)
                return;
            if (_lyricIndex >= 0 && _lyricIndex < _lyrics.Count)
                _lyrics[_lyricIndex].IsCurrent = false;
            _lyricIndex = index;
            _lyrics[index].IsCurrent = true;
            LyricsView.ScrollIntoView(_lyrics[index]);
        }

        async void Lyrics_Click(object sender, RoutedEventArgs e)
        {
            var track = _session.Current;
            if (track == null)
            {
                StatusText.Text = "Kein Titel für den Songtext";
                return;
            }
            await LoadLyricsAsync(track, true);
        }

        async void Update_Click(object sender, RoutedEventArgs e)
        {
            _session.SetUpdateUrl(UpdateBox.Text.Trim());
            try
            {
                var remote = await Library.FetchVersionAsync(_session.Settings.UpdateUrl);
                StatusText.Text = remote == null
                    ? "Keine Update-URL"
                    : remote == "0.3.0" ? "Aktuell (0.3.0)" : "Verfügbar: " + remote + " – installiert ist 0.3.0";
            }
            catch (Exception ex)
            {
                StatusText.Text = "Update-Prüfung fehlgeschlagen: " + ex.Message;
            }
        }

        void Recent_Click(object sender, RoutedEventArgs e)
        {
            var found = new List<(DateTime time, string path)>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            void Consider(string path)
            {
                if (!seen.Add(path)) return;
                try
                {
                    if (!File.Exists(path)) return;
                    found.Add((File.GetLastWriteTimeUtc(path), path));
                }
                catch { }
            }
            foreach (var track in _session.Playlist)
                Consider(track.Path);
            if (Directory.Exists(ListsDir))
            {
                foreach (var file in Directory.GetFiles(ListsDir, "*.m3u8"))
                {
                    foreach (var path in Library.LoadPlaylist(file))
                        Consider(path);
                }
            }
            found.Sort((a, b) => b.time.CompareTo(a.time));
            var paths = new List<string>();
            for (var i = 0; i < found.Count && paths.Count < 40; i++)
                paths.Add(found[i].path);
            OpenSmart("Zuletzt hinzugefügt", paths);
        }

        void Popular_Click(object sender, RoutedEventArgs e)
        {
            OpenSmart("Meistgespielt", _session.MostPlayed(40));
        }

        void LastPlayed_Click(object sender, RoutedEventArgs e)
        {
            var paths = new List<string>();
            foreach (var item in _history)
            {
                if (paths.Count >= 40)
                    break;
                paths.Add(item.Path);
            }
            OpenSmart("Zuletzt gespielt", paths);
        }

        void Unplayed_Click(object sender, RoutedEventArgs e)
        {
            OpenSmart("Nie gespielt", _session.Unplayed(KnownPaths(), 40));
        }

        void Favorites_Click(object sender, RoutedEventArgs e)
        {
            OpenSmart("Favoriten", _session.Favorites(40));
        }

        List<string> KnownPaths()
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var paths = new List<string>();
            void Add(string path)
            {
                if (path.Length == 0 || !seen.Add(path))
                    return;
                paths.Add(path);
            }
            foreach (var track in _session.Playlist)
                Add(track.Path);
            foreach (var item in _history)
                Add(item.Path);
            if (Directory.Exists(ListsDir))
            {
                foreach (var file in Directory.GetFiles(ListsDir, "*.m3u8"))
                {
                    foreach (var path in Library.LoadPlaylist(file))
                        Add(path);
                }
            }
            return paths;
        }

        void ContextRate_Click(object sender, RoutedEventArgs e)
        {
            var track = _menuTrack ?? PlaylistView.SelectedItem as Track;
            if (track == null) return;
            var next = track.Rating >= 5 ? 0 : track.Rating + 1;
            _session.SetRating(track, next);
            StatusText.Text = next == 0 ? "Bewertung gelöscht" : "Bewertung " + track.RatingText;
        }

        void ContextInfo_Click(object sender, RoutedEventArgs e)
        {
            var track = _menuTrack ?? PlaylistView.SelectedItem as Track;
            if (track == null)
                return;
            var text = track.Display
                + "\n\n" + track.Path
                + "\nLänge: " + (track.LengthText.Length == 0 ? "unbekannt" : track.LengthText)
                + "\nReplayGain: " + track.ReplayGainDb.ToString("0.0") + " dB"
                + "\nGehört: " + _session.PlayCount(track.Path);
            var dialog = new ContentDialog
            {
                Title = "Eigenschaften",
                Content = new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true },
                CloseButtonText = "Schließen",
                XamlRoot = Content.XamlRoot
            };
            _ = dialog.ShowAsync();
        }

        void OpenSmart(string name, IReadOnlyList<string> paths)
        {
            if (paths.Count == 0)
            {
                StatusText.Text = "Nichts für " + name;
                return;
            }
            if (!_listNames.Contains(name))
                _listNames.Add(name);
            SwapView(name, paths);
            StatusText.Text = paths.Count + " Titel in " + name;
        }

        readonly List<SavedRadio> _radios = new();
        bool _radioReady;

        void EnsureRadio()
        {
            if (_radioReady) return;
            _radioReady = true;
            var saved = Library.ReadJson<List<SavedRadio>>(Path.Combine(Library.DataDir, "radios.json"));
            if (saved != null)
                _radios.AddRange(saved);
            RadioSavedView.ItemsSource = _radios;
            FitRadioList();
            _ = LoadRadioCountries();
        }

        async Task LoadRadioCountries()
        {
            try
            {
                var countries = await Library.RadioCountriesAsync();
                RadioCountryBox.ItemsSource = countries;
                RadioCountryBox.DisplayMemberPath = "Display";
                foreach (var country in countries)
                {
                    if (country.Code == "DE")
                    {
                        RadioCountryBox.SelectedItem = country;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                StatusText.Text = "Länderliste nicht erreichbar: " + ex.Message;
            }
        }

        void SaveRadios()
        {
            try
            {
                Library.WriteSafe(Path.Combine(Library.DataDir, "radios.json"), System.Text.Json.JsonSerializer.Serialize(_radios));
            }
            catch { }
        }

        async void RadioPlay_Click(object sender, RoutedEventArgs e)
        {
            await PlayRadioUrl(RadioNameBox.Text.Trim(), RadioUrlBox.Text);
        }

        async void RadioSave_Click(object sender, RoutedEventArgs e)
        {
            var url = RadioUrlBox.Text.Trim();
            if (url.Length == 0) return;
            var name = RadioNameBox.Text.Trim();
            if (name.Length == 0) name = url;
            _radios.Insert(0, new SavedRadio { Name = name, Url = url });
            RadioSavedView.ItemsSource = null;
            RadioSavedView.ItemsSource = _radios;
            FitRadioList();
            SaveRadios();
            StatusText.Text = "Sender gemerkt";
        }

        void RadioRemove_Click(object sender, RoutedEventArgs e)
        {
            if (RadioSavedView.SelectedItem is not SavedRadio station) return;
            _radios.Remove(station);
            RadioSavedView.ItemsSource = null;
            RadioSavedView.ItemsSource = _radios;
            FitRadioList();
            SaveRadios();
        }

        double _radioListHeight = 140;

        void FitRadioList()
        {
            if (_radios.Count == 0)
            {
                RadioSavedView.Visibility = Visibility.Collapsed;
                RadioSplit.Visibility = Visibility.Collapsed;
                return;
            }
            RadioSavedView.Visibility = Visibility.Visible;
            RadioSplit.Visibility = Visibility.Visible;
            var wanted = Math.Min(_radios.Count * 36 + 8, _radioListHeight);
            RadioSavedView.Height = Math.Clamp(wanted, 44, 420);
        }

        void RadioSplit_Drag(object sender, Microsoft.UI.Xaml.Controls.Primitives.DragDeltaEventArgs e)
        {
            _radioListHeight = Math.Clamp(_radioListHeight + e.VerticalChange, 72, 420);
            FitRadioList();
        }

        async void RadioSaved_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            if (RadioSavedView.SelectedItem is not SavedRadio station) return;
            RadioNameBox.Text = station.Name;
            RadioUrlBox.Text = station.Url;
            await PlayRadioUrl(station.Name, station.Url);
        }

        async void RadioSearch_Click(object sender, RoutedEventArgs e)
        {
            if (RadioCountryBox.SelectedItem is not Library.RadioCountry country)
            {
                StatusText.Text = "Zuerst ein Land wählen";
                return;
            }
            StatusText.Text = "Sender werden gesucht…";
            try
            {
                var hits = await Library.RadioStationsAsync(country.Code, RadioQueryBox.Text);
                RadioResultView.ItemsSource = hits;
                StatusText.Text = hits.Count + " Sender";
            }
            catch (Exception ex)
            {
                StatusText.Text = "Suche fehlgeschlagen: " + ex.Message;
            }
        }

        async void RadioResult_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            if (RadioResultView.SelectedItem is not Library.RadioHit hit) return;
            RadioNameBox.Text = hit.Name;
            RadioUrlBox.Text = hit.Url;
            await PlayRadioUrl(hit.Name, hit.Url);
        }

        async Task PlayRadioUrl(string name, string url)
        {
            if (string.IsNullOrWhiteSpace(url)) return;
            StatusText.Text = "Stream wird verbunden…";
            try
            {
                var stream = await Library.ResolveStreamAsync(url);
                RadioUrlBox.Text = stream;
                _session.PlayRadio(name, stream);
                Refresh();
            }
            catch (Exception ex)
            {
                StatusText.Text = "Stream nicht erreichbar: " + ex.Message;
            }
        }

        sealed class SavedRadio
        {
            public string Name { get; set; } = "";
            public string Url { get; set; } = "";
            public string Display => Name;
        }

        void Mini_Click(object sender, RoutedEventArgs e)
        {
            _mini ??= new MiniWindow(this);
            _mini.ApplyLook(_session.Settings.Theme);
            _mini.Activate();
            _mini.Refresh();
        }

        void Exit_Click(object sender, RoutedEventArgs e)
        {
            _exit = true;
            Close();
        }
    }
}
