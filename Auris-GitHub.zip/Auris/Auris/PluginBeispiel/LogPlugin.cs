using System.IO;

namespace Auris;

// Bauen und die DLL in den Ordner Plugins neben der EXE legen.
// Enqueue("D:\\Musik\\lied.mp3") hängt einen Titel an, nicht aus einem Ereignis heraus aufrufen.
public sealed class LogPlugin : IPlayerPlugin
{
    IPlayerHost? _host;

    public string Name => "Beispiel";

    public void Attach(IPlayerHost host) => _host = host;

    public void OnTrackChanged(string path, string title) => Line("Titel: " + title);

    public void OnPlay(string path, string title) => Line("Play: " + title);

    public void OnPause() => Line("Pause: " + _host?.CurrentTitle);

    public void OnStop() => Line("Stop");

    static void Line(string text)
    {
        var dir = Path.Combine(AppContext.BaseDirectory, "data");
        Directory.CreateDirectory(dir);
        File.AppendAllText(Path.Combine(dir, "plugin-log.txt"), text + System.Environment.NewLine);
    }
}
