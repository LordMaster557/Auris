using Microsoft.UI.Xaml;
using Windows.ApplicationModel;

namespace Auris
{
    public partial class App : Application
    {
        private Window? _window;

        public App()
        {
            this.InitializeComponent();
        }

        [System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
        static extern int SetCurrentProcessExplicitAppUserModelID(string appId);

        protected override void OnLaunched(LaunchActivatedEventArgs args)
        {
            // AppUserModelID (WinRT) ist im SDK 26100 entfernt - P/Invoke statt dessen.
            SetCurrentProcessExplicitAppUserModelID("Auris.MediaPlayer");
            _window = new MainWindow();
            _window.Activate();
        }
    }
}