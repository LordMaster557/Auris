using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Auris
{
    public sealed class Track : INotifyPropertyChanged
    {
        public Track(string path)
        {
            Path = path;
            Name = System.IO.Path.GetFileName(path);
            Title = "";
            Artist = "";
            Album = "";
            Lyrics = "";
            ReplayGainDb = double.NaN;
        }

        public string Path { get; }
        public string Name { get; }
        public string Title { get; private set; }
        public string Artist { get; private set; }
        public string Album { get; private set; }
        public string Lyrics { get; private set; }
        public double ReplayGainDb { get; private set; }
        public double DurationSeconds { get; private set; }
        public string? CoverPath { get; private set; }
        bool _current;

        public bool IsCurrent
        {
            get => _current;
            set
            {
                if (_current == value) return;
                _current = value;
                OnChanged(nameof(IsCurrent));
                OnChanged(nameof(PlayMark));
                OnChanged(nameof(CurrentBar));
            }
        }

        public string PlayMark => _current ? "▶" : "";
        public double CurrentBar => _current ? 1 : 0;

        bool _offline;
        public bool IsOffline => _offline;
        public double RowOpacity => _offline ? 0.45 : 1;
        public string StateMark => _offline ? "offline" : "";

        int _rating;
        public int Rating => _rating;
        public string RatingText => _rating <= 0 ? "" : new string('★', _rating);

        public void SetRating(int value)
        {
            value = Math.Clamp(value, 0, 5);
            if (_rating == value) return;
            _rating = value;
            OnChanged(nameof(Rating));
            OnChanged(nameof(RatingText));
        }

        public void SetOffline(bool value)
        {
            if (_offline == value) return;
            _offline = value;
            OnChanged(nameof(IsOffline));
            OnChanged(nameof(RowOpacity));
            OnChanged(nameof(StateMark));
        }

        public string TitleText => string.IsNullOrWhiteSpace(Title) ? Name : Title;

        public string LengthText
        {
            get
            {
                if (DurationSeconds <= 0) return "";
                var time = TimeSpan.FromSeconds(DurationSeconds);
                return time.Hours > 0 ? time.ToString(@"h\:mm\:ss") : time.ToString(@"mm\:ss");
            }
        }

        public string Display
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(Artist) && !string.IsNullOrWhiteSpace(Title))
                    return Artist + " – " + Title;
                if (!string.IsNullOrWhiteSpace(Title))
                    return Title;
                return Name;
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        public void Apply(TrackMeta meta)
        {
            Title = meta.Title;
            Artist = meta.Artist;
            Album = meta.Album;
            Lyrics = meta.Lyrics;
            ReplayGainDb = meta.ReplayGainDb;
            DurationSeconds = meta.DurationSeconds;
            if (!string.IsNullOrWhiteSpace(meta.CoverPath))
                CoverPath = meta.CoverPath;
            OnChanged(nameof(TitleText));
            OnChanged(nameof(Artist));
            OnChanged(nameof(Album));
            OnChanged(nameof(LengthText));
            OnChanged(nameof(Display));
        }

        public void SetLyrics(string lyrics)
        {
            Lyrics = lyrics;
            OnChanged(nameof(Lyrics));
        }

        public void SetCover(string path)
        {
            CoverPath = path;
            OnChanged(nameof(CoverPath));
        }

        void OnChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public readonly record struct TrackMeta(
        string Title,
        string Artist,
        string Album,
        string Lyrics,
        double ReplayGainDb,
        double DurationSeconds,
        string? CoverPath);

    public sealed class Bookmark
    {
        public string Path { get; set; } = "";
        public double Seconds { get; set; }
        public string Label { get; set; } = "";
        public string Display => Label + "  " + TimeSpan.FromSeconds(Seconds).ToString(@"mm\:ss");
    }

    public sealed class HistoryItem
    {
        public string Path { get; set; } = "";
        public string Label { get; set; } = "";
        public string Display => Label;
    }

    public sealed class AppSettings
    {
        public float Volume { get; set; } = 0.8f;
        public double Crossfade { get; set; }
        public bool ReplayGain { get; set; } = true;
        public string Output { get; set; } = "WaveOut";
        public float[] Eq { get; set; } = new float[10];
        public Dictionary<string, float[]> EqTemplates { get; set; } = new();
        public string Theme { get; set; } = "mica";
        public string Accent { get; set; } = "cyan";
        public string Skin { get; set; } = "";
        public bool MinimizeToTray { get; set; } = true;
        public string UpdateUrl { get; set; } = "";
        public string SmartFolder { get; set; } = "";
        public string BrowserFolder { get; set; } = "";
        public string Language { get; set; } = "";
        public string Repeat { get; set; } = "off";
        public bool Shuffle { get; set; }
        public float Balance { get; set; }
        public int WindowX { get; set; }
        public int WindowY { get; set; }
        public int WindowW { get; set; }
        public int WindowH { get; set; }
        public bool WindowMax { get; set; }
        public double ColTitle { get; set; }
        public double ColArtist { get; set; }
        public double ColAlbum { get; set; }
        public double ColLength { get; set; }
        public double ColStars { get; set; }
    }

    public sealed class PlaylistColumns : INotifyPropertyChanged
    {
        double _title = 340;
        double _artist = 200;
        double _album = 240;
        double _length = 84;
        double _stars = 112;

        public double TitleWidth { get => _title; set => Set(ref _title, value, nameof(TitleWidth)); }
        public double ArtistWidth { get => _artist; set => Set(ref _artist, value, nameof(ArtistWidth)); }
        public double AlbumWidth { get => _album; set => Set(ref _album, value, nameof(AlbumWidth)); }
        public double LengthWidth { get => _length; set => Set(ref _length, value, nameof(LengthWidth)); }
        public double StarsWidth { get => _stars; set => Set(ref _stars, value, nameof(StarsWidth)); }

        void Set(ref double field, double value, string name)
        {
            if (Math.Abs(field - value) < 0.5) return;
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }

    public sealed class LyricLine : INotifyPropertyChanged
    {
        public LyricLine(double seconds, string text)
        {
            Seconds = seconds;
            Text = text.Length == 0 ? " " : text;
        }

        public double Seconds { get; }
        public string Text { get; }
        bool _current;

        public bool IsCurrent
        {
            get => _current;
            set
            {
                if (_current == value) return;
                _current = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsCurrent)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Opacity)));
            }
        }

        public double Opacity => _current ? 1 : 0.4;

        public event PropertyChangedEventHandler? PropertyChanged;
    }

    public sealed class SkinFile
    {
        public bool Light { get; set; }
        public string Backdrop { get; set; } = "mica";
        public string Accent { get; set; } = "#50DCFF";
        public string Panel { get; set; } = "#14FFFFFF";
        public string Line { get; set; } = "#20FFFFFF";
        public string Muted { get; set; } = "#B3FFFFFF";
        public string Ink { get; set; } = "#062028";
    }
}
